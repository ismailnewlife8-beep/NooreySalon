@echo off
title Noorey Salon - Appointment Booking App
cd /d "%~dp0"

echo ============================================
echo   Noorey Salon - Appointment Booking App
echo ============================================
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Node.js nahi mila.
  echo Pehle Node.js install karein: https://nodejs.org  (LTS version)
  echo Install ke baad is file ko dobara chalayein.
  echo.
  pause
  exit /b
)

echo Node.js mil gaya:
node -v
echo.

if not exist "server\node_modules" (
  echo [1/3] Dependencies install ho rahi hain... (2 se 4 minute)
  call npm install
  if errorlevel 1 (
    echo.
    echo [ERROR] Install fail ho gaya. Error upar padhein.
    echo Aksar ye tab hota hai jab build tools missing hon.
    echo Fix: README.md mein "Troubleshooting" section padhein.
    pause
    exit /b
  )
) else (
  echo [1/3] Dependencies pehle se maujood hain. Skip.
)

if not exist "server\data\booking.db" (
  echo [2/3] Demo data bana rahe hain...
  call npm run seed
  if errorlevel 1 ( echo [ERROR] Seed fail. & pause & exit /b )
) else (
  echo [2/3] Database pehle se maujood hai. Skip.
)

echo [3/3] App start ho raha hai...
echo.
echo   Customer app : http://localhost:5173
echo   Admin panel  : http://localhost:5173/admin
echo.
echo   Band karne ke liye: Ctrl+C dabayein
echo ============================================
echo.

timeout /t 6 /nobreak >nul
start "" http://localhost:5173

call npm run dev
pause
