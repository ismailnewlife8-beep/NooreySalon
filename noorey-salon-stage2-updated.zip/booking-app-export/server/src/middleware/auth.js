import { db } from '../db/index.js';
import { verifyToken } from '../lib/tokens.js';

const SAFE_FIELDS = 'id, role, name, email, phone, avatar_url, email_verified, notify_email, notify_sms, is_active, created_at';

export function optionalAuth(req, _res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (token) {
    const payload = verifyToken(token);
    if (payload?.sub) {
      const user = db.prepare(`SELECT ${SAFE_FIELDS} FROM users WHERE id = ? AND is_active = 1`).get(payload.sub);
      if (user) req.user = user;
    }
  }
  next();
}

export function requireAuth(req, res, next) {
  if (!req.user) return res.status(401).json({ error: 'Please sign in to continue' });
  next();
}

export function requireAdmin(req, res, next) {
  if (!req.user) return res.status(401).json({ error: 'Please sign in to continue' });
  if (req.user.role !== 'admin') return res.status(403).json({ error: 'Admin access required' });
  next();
}

export function requireStaffOrAdmin(req, res, next) {
  if (!req.user) return res.status(401).json({ error: 'Please sign in to continue' });
  if (!['admin', 'staff'].includes(req.user.role)) return res.status(403).json({ error: 'Staff access required' });
  next();
}
