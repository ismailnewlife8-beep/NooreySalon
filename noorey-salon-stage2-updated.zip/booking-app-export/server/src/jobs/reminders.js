import cron from 'node-cron';
import { db, getSettings } from '../db/index.js';
import { listAppointments } from '../lib/bookings.js';
import { notifyAppointment } from '../lib/notify.js';
import { todayStr, nowMinutes, dateToIndex, addDays } from '../lib/time.js';

export async function runReminders() {
  const settings = getSettings();
  if (!settings.remind_24h && !settings.remind_2h) return { sent: 0 };

  const today = todayStr();
  const nowMin = nowMinutes();
  const rows = listAppointments({
    where: "WHERE a.status IN ('pending','confirmed') AND a.date BETWEEN ? AND ?",
    params: [today, addDays(today, 2)],
    limit: 500,
  });

  let sent = 0;
  for (const appt of rows) {
    const minsAway = (dateToIndex(appt.date) - dateToIndex(today)) * 1440 + appt.start_min - nowMin;
    if (settings.remind_24h && !appt.reminded_24h && minsAway <= 1440 && minsAway > 120) {
      db.prepare('UPDATE appointments SET reminded_24h = 1 WHERE id = ?').run(appt.id);
      await notifyAppointment('reminder24', appt);
      sent += 1;
    } else if (settings.remind_2h && !appt.reminded_2h && minsAway <= 120 && minsAway > 0) {
      db.prepare('UPDATE appointments SET reminded_2h = 1 WHERE id = ?').run(appt.id);
      await notifyAppointment('reminder2', appt);
      sent += 1;
    }
  }
  return { sent };
}

export function startReminderJob() {
  // every 10 minutes
  cron.schedule('*/10 * * * *', async () => {
    try {
      const r = await runReminders();
      if (r.sent) console.log(`[reminders] sent ${r.sent} reminder(s)`);
    } catch (err) {
      console.error('[reminders] failed:', err.message);
    }
  });
}
