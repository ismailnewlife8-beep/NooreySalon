import 'dotenv/config';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import morgan from 'morgan';

process.env.APP_TIMEZONE = process.env.APP_TIMEZONE || 'Asia/Karachi';
process.env.TZ = process.env.APP_TIMEZONE;

const { db, getSettings, DEFAULT_SETTINGS, setSettings, DATA_DIR } = await import('./db/index.js');
void db;
void DEFAULT_SETTINGS;
void setSettings;

const { optionalAuth } = await import('./middleware/auth.js');
const { notFound, errorHandler } = await import('./middleware/http.js');
const { startReminderJob } = await import('./jobs/reminders.js');

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
app.set('trust proxy', 1);

if (process.env.NODE_ENV === 'production' && (!process.env.JWT_SECRET || process.env.JWT_SECRET.startsWith('change-me'))) {
  console.error('❌ Refusing to start in production without a strong JWT_SECRET in server/.env');
  process.exit(1);
}
const PORT = Number(process.env.PORT || 4000);

app.use(
  helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        imgSrc: ["'self'", 'data:', 'https:', 'blob:'],
        scriptSrc: ["'self'", "'unsafe-inline'", 'https://accounts.google.com', 'https://apis.google.com'],
        frameSrc: ["'self'", 'https://accounts.google.com'],
        connectSrc: ["'self'", 'https://accounts.google.com', 'https://api.stripe.com'],
        styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
        fontSrc: ["'self'", 'https://fonts.gstatic.com', 'data:'],
      },
    },
    crossOriginEmbedderPolicy: false,
  })
);
app.use(cors({ origin: process.env.CLIENT_ORIGIN || true, credentials: true }));
app.use(express.json({ limit: '2mb' }));
app.use(
  '/uploads',
  (_req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Cross-Origin-Resource-Policy', 'cross-origin');
    next();
  },
  express.static(path.join(DATA_DIR, 'uploads'), { maxAge: '7d', index: false, dotfiles: 'deny' })
);
app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));
app.use(optionalAuth);

// keep the configured timezone authoritative for the running process
process.env.APP_TIMEZONE = getSettings().timezone || process.env.APP_TIMEZONE;
process.env.TZ = process.env.APP_TIMEZONE;

const mount = async (prefix, file) => {
  const mod = await import(file);
  app.use(prefix, mod.default);
};

await mount('/api/auth', './routes/auth.js');
await mount('/api/meta', './routes/meta.js');
await mount('/api/services', './routes/services.js');
await mount('/api/staff', './routes/staff.js');
await mount('/api/availability', './routes/availability.js');
await mount('/api/bookings', './routes/bookings.js');
await mount('/api/reviews', './routes/reviews.js');
await mount('/api/coupons', './routes/coupons.js');
await mount('/api/profile', './routes/profile.js');
await mount('/api/admin', './routes/admin.js');

app.get('/api/health', (_req, res) => res.json({ ok: true, time: new Date().toISOString() }));

// Serve the built SPA when it exists (single-process production mode).
const dist = path.join(__dirname, '..', '..', 'client', 'dist');
if (fs.existsSync(dist)) {
  app.use(express.static(dist));
  app.get(/^\/(?!api).*/, (_req, res) => res.sendFile(path.join(dist, 'index.html')));
}

app.use('/api', notFound);
app.use(errorHandler);

startReminderJob();

app.listen(PORT, () => {
  const s = getSettings();
  console.log(`\n✅ ${s.business_name} API ready on http://localhost:${PORT}`);
  console.log(`   timezone=${process.env.TZ}  currency=${s.currency}  db=${process.env.DB_PATH || path.join(__dirname, '..', 'data', 'booking.db')}`);
  console.log(
    `   integrations → email:${getSettings() && process.env.SMTP_HOST ? 'smtp' : 'dev'} sms:${
      process.env.TWILIO_ACCOUNT_SID ? 'twilio' : 'dev'
    } card:${process.env.STRIPE_SECRET_KEY ? 'stripe' : 'mock'} google:${process.env.GOOGLE_CLIENT_ID ? 'on' : 'off'}\n`
  );
});
