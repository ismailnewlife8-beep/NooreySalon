import Database from 'better-sqlite3';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dataDir = process.env.DB_DIR || path.join(__dirname, '..', '..', 'data');
fs.mkdirSync(dataDir, { recursive: true });

export const dbPath = process.env.DB_PATH || path.join(dataDir, 'booking.db');
export const db = new Database(dbPath);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.exec(fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8'));

export const DATA_DIR = dataDir;

/** Business configuration defaults. Everything here is editable in Admin → Settings. */
export const DEFAULT_SETTINGS = {
  business_name: 'Noorey Salon',
  business_type: 'Hair · Nails · Spa · Makeup',
  tagline: 'Where every visit feels like a celebration',
  currency: 'PKR',
  currency_symbol: 'Rs',
  timezone: 'Asia/Karachi',
  phone: '0325 4066555',
  email: 'nooreynooreysms@gmail.com',
  address: 'Building 96, CCA-2, DHA Phase 6, Lahore',
  website: '',
  landline: '042-37261668',
  whatsapp: '923254066555',
  instagram: 'nooreysmakeupstudio',
  hours_text: 'Mon – Sun · 11:00 AM – 7:30 PM',
  slot_granularity_min: 30,
  default_buffer_min: 10,
  min_lead_hours: 2,
  max_advance_days: 60,
  cancellation_hours: 12,
  tax_percent: 0,
  deposit_percent: 0,
  allow_card: 0,
  allow_cash: 1,
  auto_confirm: 1,
  remind_24h: 1,
  remind_2h: 1,
  require_approval: 0,
  // branding images (set only through the admin upload endpoints)
  logo_url: '',
  hero_image_url: '',
  gallery_json: '[]',
};

const NUMERIC_KEYS = new Set([
  'slot_granularity_min', 'default_buffer_min', 'min_lead_hours', 'max_advance_days',
  'cancellation_hours', 'tax_percent', 'deposit_percent', 'allow_card', 'allow_cash',
  'auto_confirm', 'remind_24h', 'remind_2h', 'require_approval',
]);

const coerce = (key, value) => {
  if (value === null || value === undefined || value === '') return DEFAULT_SETTINGS[key] ?? '';
  if (NUMERIC_KEYS.has(key)) return Number(value);
  return String(value);
};

export function getSettings() {
  const rows = db.prepare('SELECT key, value FROM settings').all();
  const stored = Object.fromEntries(rows.map((r) => [r.key, r.value]));
  const out = {};
  for (const key of Object.keys(DEFAULT_SETTINGS)) out[key] = coerce(key, stored[key]);
  return out;
}

export function getSetting(key) {
  return getSettings()[key];
}

export function setSettings(patch) {
  const stmt = db.prepare(
    'INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value'
  );
  const tx = db.transaction((obj) => {
    for (const [k, v] of Object.entries(obj)) {
      if (!(k in DEFAULT_SETTINGS)) continue;
      stmt.run(k, String(v));
    }
  });
  tx(patch);
  return getSettings();
}

/** Capability flags surfaced to the client so UI can hide unavailable channels. */
export function capabilities() {
  return {
    email: Boolean(process.env.SMTP_HOST || process.env.SENDGRID_API_KEY),
    sms: Boolean(process.env.TWILIO_ACCOUNT_SID && process.env.TWILIO_AUTH_TOKEN),
    card: false, // online card capture is disabled until Stripe Elements is integrated
    google: Boolean(process.env.GOOGLE_CLIENT_ID),
    googleClientId: process.env.GOOGLE_CLIENT_ID || null,
    devMode: process.env.NODE_ENV !== 'production',
  };
}
