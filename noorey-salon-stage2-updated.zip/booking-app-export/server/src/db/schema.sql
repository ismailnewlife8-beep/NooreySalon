PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;

-- ---------------------------------------------------------------- users
CREATE TABLE IF NOT EXISTS users (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  role           TEXT NOT NULL DEFAULT 'customer' CHECK (role IN ('customer','admin','staff')),
  name           TEXT NOT NULL,
  email          TEXT UNIQUE,
  phone          TEXT UNIQUE,
  password_hash  TEXT,
  google_id      TEXT UNIQUE,
  avatar_url     TEXT,
  email_verified INTEGER NOT NULL DEFAULT 0,
  phone_verified INTEGER NOT NULL DEFAULT 0,
  notify_email   INTEGER NOT NULL DEFAULT 1,
  notify_sms     INTEGER NOT NULL DEFAULT 1,
  notes          TEXT,
  is_active      INTEGER NOT NULL DEFAULT 1,
  created_at     TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS otp_codes (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  destination TEXT NOT NULL,
  channel     TEXT NOT NULL DEFAULT 'sms',
  code        TEXT NOT NULL,
  purpose     TEXT NOT NULL DEFAULT 'login',
  expires_at  TEXT NOT NULL,
  consumed_at TEXT,
  attempts    INTEGER NOT NULL DEFAULT 0,
  created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_otp_dest ON otp_codes(destination, purpose);

-- ---------------------------------------------------------------- staff
CREATE TABLE IF NOT EXISTS staff (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id     INTEGER REFERENCES users(id) ON DELETE SET NULL,
  name        TEXT NOT NULL,
  title       TEXT,
  bio         TEXT,
  email       TEXT,
  phone       TEXT,
  avatar_url  TEXT,
  color       TEXT NOT NULL DEFAULT '#2563EB',
  rating      REAL NOT NULL DEFAULT 0,
  is_active   INTEGER NOT NULL DEFAULT 1,
  created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS services (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  name          TEXT NOT NULL,
  category      TEXT NOT NULL DEFAULT 'General',
  description   TEXT,
  duration_min  INTEGER NOT NULL DEFAULT 60,
  price_cents   INTEGER NOT NULL DEFAULT 0,
  buffer_min    INTEGER NOT NULL DEFAULT 0,
  deposit_cents INTEGER NOT NULL DEFAULT 0,
  color         TEXT NOT NULL DEFAULT '#2563EB',
  image_url     TEXT,
  is_active     INTEGER NOT NULL DEFAULT 1,
  sort_order    INTEGER NOT NULL DEFAULT 0,
  created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS service_staff (
  service_id INTEGER NOT NULL REFERENCES services(id) ON DELETE CASCADE,
  staff_id   INTEGER NOT NULL REFERENCES staff(id) ON DELETE CASCADE,
  PRIMARY KEY (service_id, staff_id)
);

-- schedule -------------------------------------------------------------
-- staff_id IS NULL => business-wide default rule
CREATE TABLE IF NOT EXISTS working_hours (
  id        INTEGER PRIMARY KEY AUTOINCREMENT,
  staff_id  INTEGER REFERENCES staff(id) ON DELETE CASCADE,
  weekday   INTEGER NOT NULL CHECK (weekday BETWEEN 0 AND 6),
  start_min INTEGER NOT NULL DEFAULT 540,
  end_min   INTEGER NOT NULL DEFAULT 1080,
  is_off    INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_wh ON working_hours(staff_id, weekday);

CREATE TABLE IF NOT EXISTS breaks (
  id        INTEGER PRIMARY KEY AUTOINCREMENT,
  staff_id  INTEGER REFERENCES staff(id) ON DELETE CASCADE,
  weekday   INTEGER NOT NULL CHECK (weekday BETWEEN 0 AND 6),
  start_min INTEGER NOT NULL,
  end_min   INTEGER NOT NULL,
  label     TEXT DEFAULT 'Break'
);
CREATE INDEX IF NOT EXISTS idx_breaks ON breaks(staff_id, weekday);

CREATE TABLE IF NOT EXISTS holidays (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  staff_id   INTEGER REFERENCES staff(id) ON DELETE CASCADE,
  start_date TEXT NOT NULL,
  end_date   TEXT NOT NULL,
  reason     TEXT
);

-- ---------------------------------------------------------------- bookings
CREATE TABLE IF NOT EXISTS appointments (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  code            TEXT UNIQUE NOT NULL,
  customer_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  staff_id        INTEGER REFERENCES staff(id) ON DELETE SET NULL,
  service_id      INTEGER NOT NULL REFERENCES services(id) ON DELETE CASCADE,
  date            TEXT NOT NULL,          -- YYYY-MM-DD (business timezone)
  start_min       INTEGER NOT NULL,       -- minutes from midnight
  end_min         INTEGER NOT NULL,
  status          TEXT NOT NULL DEFAULT 'confirmed'
                  CHECK (status IN ('pending','confirmed','completed','cancelled','no_show')),
  payment_status  TEXT NOT NULL DEFAULT 'unpaid'
                  CHECK (payment_status IN ('unpaid','paid','refunded')),
  payment_method  TEXT CHECK (payment_method IN ('card','cash')),
  payment_ref     TEXT,
  paid_cents      INTEGER NOT NULL DEFAULT 0,
  price_cents     INTEGER NOT NULL DEFAULT 0,
  discount_cents  INTEGER NOT NULL DEFAULT 0,
  tax_cents       INTEGER NOT NULL DEFAULT 0,
  total_cents     INTEGER NOT NULL DEFAULT 0,
  coupon_id       INTEGER REFERENCES coupons(id) ON DELETE SET NULL,
  notes           TEXT,
  cancel_reason   TEXT,
  reminded_24h    INTEGER NOT NULL DEFAULT 0,
  reminded_2h     INTEGER NOT NULL DEFAULT 0,
  created_at      TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at      TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_appt_date ON appointments(date, staff_id);
CREATE INDEX IF NOT EXISTS idx_appt_cust ON appointments(customer_id);

CREATE TABLE IF NOT EXISTS reviews (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  appointment_id INTEGER UNIQUE REFERENCES appointments(id) ON DELETE CASCADE,
  customer_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  staff_id       INTEGER REFERENCES staff(id) ON DELETE SET NULL,
  service_id     INTEGER REFERENCES services(id) ON DELETE CASCADE,
  rating         INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
  comment        TEXT,
  reply          TEXT,
  is_published   INTEGER NOT NULL DEFAULT 1,
  created_at     TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS coupons (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  code           TEXT UNIQUE NOT NULL,
  description    TEXT,
  type           TEXT NOT NULL DEFAULT 'percent' CHECK (type IN ('percent','fixed')),
  value          INTEGER NOT NULL DEFAULT 0,      -- percent (0-100) or cents
  min_spend_cents INTEGER NOT NULL DEFAULT 0,
  max_discount_cents INTEGER,
  starts_at      TEXT,
  ends_at        TEXT,
  usage_limit    INTEGER,
  used_count     INTEGER NOT NULL DEFAULT 0,
  is_active      INTEGER NOT NULL DEFAULT 1,
  created_at     TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS notifications (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id        INTEGER REFERENCES users(id) ON DELETE CASCADE,
  appointment_id INTEGER REFERENCES appointments(id) ON DELETE CASCADE,
  channel        TEXT NOT NULL DEFAULT 'inapp' CHECK (channel IN ('email','sms','inapp')),
  recipient      TEXT,
  subject        TEXT,
  body           TEXT NOT NULL,
  status         TEXT NOT NULL DEFAULT 'queued' CHECK (status IN ('queued','sent','failed')),
  provider       TEXT,
  error          TEXT,
  sent_at        TEXT,
  created_at     TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_notif_user ON notifications(user_id, created_at);

CREATE TABLE IF NOT EXISTS settings (
  key   TEXT PRIMARY KEY,
  value TEXT
);

-- ---------------------------------------------------------------- password reset / email verification
CREATE TABLE IF NOT EXISTS email_tokens (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind       TEXT NOT NULL CHECK (kind IN ('reset','verify')),
  token_hash TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  used_at    TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_email_tokens ON email_tokens(token_hash);
