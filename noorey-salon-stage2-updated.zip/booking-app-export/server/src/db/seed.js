import 'dotenv/config';
import bcrypt from 'bcryptjs';
import { db, setSettings, getSettings, DEFAULT_SETTINGS } from './index.js';
import { bookingCode } from '../lib/ids.js';
import { addDays, todayStr, weekdayOf } from '../lib/time.js';

const force = process.argv.includes('--force');

const tx = db.transaction(() => {
  if (force) {
    for (const t of ['notifications', 'reviews', 'appointments', 'coupons', 'service_staff', 'services', 'holidays', 'breaks', 'working_hours', 'staff', 'otp_codes', 'users']) {
      db.prepare(`DELETE FROM ${t}`).run();
    }
    db.prepare('DELETE FROM settings').run();
  }
  if (db.prepare('SELECT COUNT(*) c FROM users').get().c > 0 && !force) return false;

  setSettings(DEFAULT_SETTINGS);

  const pwd = (p) => bcrypt.hashSync(p, 10);
  const insUser = db.prepare(
    'INSERT INTO users (name, email, phone, password_hash, role, avatar_url, email_verified, notify_email, notify_sms) VALUES (?, ?, ?, ?, ?, ?, 1, 1, 1)'
  );

  const adminEmail = process.env.ADMIN_EMAIL || 'admin@nooreysalon.com';
  const adminPass = process.env.ADMIN_PASSWORD || 'Admin@123';
  insUser.run('Noorey Admin', adminEmail, null, pwd(adminPass), 'admin', null);

  const staffSeed = [
    { name: 'Ayesha Khan', title: 'Senior Hair Stylist', email: 'ayesha@nooreysalon.com', color: '#9C6B3F', bio: 'Precision cuts, blow-dries and signature styling with 12 years of experience.' },
    { name: 'Mahnoor Shah', title: 'Lead Makeup Artist', email: 'mahnoor@nooreysalon.com', color: '#B5651D', bio: 'Bridal, party and editorial makeup that photographs beautifully and lasts all night.' },
    { name: 'Hira Malik', title: 'Nail Artist', email: 'hira@nooreysalon.com', color: '#C98B6B', bio: 'Gel, extensions and detailed nail art, finished flawlessly.' },
    { name: 'Zainab Rauf', title: 'Skin & Spa Therapist', email: 'zainab@nooreysalon.com', color: '#8A7155', bio: 'Facials, massage and relaxation therapies tailored to your skin and mood.' },
    { name: 'Sana Qureshi', title: 'Colour Specialist', email: 'sana@nooreysalon.com', color: '#A3835A', bio: 'Balayage, global colour and keratin treatments with a hair-health-first approach.' },
  ];
  const staffIds = staffSeed.map((s) => {
    const uid = insUser.run(s.name, s.email, null, pwd('Staff@123'), 'staff', null).lastInsertRowid;
    return db
      .prepare('INSERT INTO staff (user_id, name, title, bio, email, phone, color) VALUES (?, ?, ?, ?, ?, ?, ?)')
      .run(uid, s.name, s.title, s.bio, s.email, null, s.color).lastInsertRowid;
  });
  const [ayesha, mahnoor, hira, zainab, sana] = staffIds;

  const customers = [
    { name: 'Fatima Ahmed', email: 'fatima@example.com' },
    { name: 'Hania Siddiqui', email: 'hania@example.com' },
    { name: 'Areeba Noor', email: 'areeba@example.com' },
    { name: 'Komal Raza', email: 'komal@example.com' },
    { name: 'Maryam Tariq', email: 'maryam@example.com' },
  ];
  const custIds = customers.map((c) => insUser.run(c.name, c.email, null, pwd('Customer@123'), 'customer', null).lastInsertRowid);

  // prices are PKR (stored x100). Premium positioning.
  const R = (rs) => rs * 100;
  const servicesSeed = [
    // Hair
    { name: 'Signature Haircut & Blow-dry', category: 'Hair', duration: 60, price: R(6500), buffer: 10, description: 'Consultation, wash, precision cut and a salon-finish blow-dry tailored to your face shape and texture.', color: '#9C6B3F', staff: [ayesha, sana] },
    { name: 'Global Hair Colour', category: 'Hair', duration: 150, price: R(18000), buffer: 15, description: 'Rich, even all-over colour with premium ammonia-free options and a glossing finish.', color: '#A3835A', staff: [sana] },
    { name: 'Balayage & Highlights', category: 'Hair', duration: 210, price: R(35000), buffer: 15, description: 'Hand-painted, sun-kissed dimension with bond protection, toning and styling.', color: '#B08968', staff: [sana] },
    { name: 'Keratin Smoothing Treatment', category: 'Hair', duration: 150, price: R(28000), buffer: 15, description: 'Frizz-free, glossy, manageable hair for up to three months.', color: '#8F6F4E', staff: [sana, ayesha] },
    { name: 'Deep Conditioning Hair Spa', category: 'Hair', duration: 60, price: R(8500), buffer: 10, description: 'Scalp massage, steam and a restorative mask to bring dull, dry hair back to life.', color: '#C2A383', staff: [ayesha, zainab] },
    { name: 'Party Hairstyling', category: 'Hair', duration: 60, price: R(7500), buffer: 10, description: 'Curls, waves, braids or a sleek updo, styled for the occasion.', color: '#9C6B3F', staff: [ayesha] },
    // Makeup
    { name: 'Party Makeup', category: 'Makeup', duration: 90, price: R(18000), buffer: 15, description: 'Flawless, long-wear glam with skin prep, lashes and a setting finish.', color: '#B5651D', staff: [mahnoor] },
    { name: 'Engagement & Walima Makeup', category: 'Makeup', duration: 150, price: R(40000), buffer: 15, description: 'Soft, camera-ready glamour with premium products, lashes and hair-and-dupatta setting.', color: '#A9581B', staff: [mahnoor] },
    { name: 'Bridal Makeup (Signature)', category: 'Makeup', duration: 180, price: R(65000), buffer: 20, description: 'Your complete bridal look by our lead artist: skin prep, HD makeup, lashes, hair styling and dupatta setting. Trial available on request.', color: '#8F4A12', staff: [mahnoor] },
    // Nails
    { name: 'Classic Manicure', category: 'Nails', duration: 45, price: R(3500), buffer: 5, description: 'Shaping, cuticle care, hand massage and polish.', color: '#C98B6B', staff: [hira] },
    { name: 'Gel Manicure', category: 'Nails', duration: 60, price: R(5500), buffer: 5, description: 'Long-wear, chip-free gel colour with a glossy finish.', color: '#C27C5A', staff: [hira] },
    { name: 'Luxury Pedicure', category: 'Nails', duration: 75, price: R(6500), buffer: 5, description: 'Warm soak, exfoliation, callus care, massage and polish.', color: '#B97152', staff: [hira] },
    { name: 'Nail Extensions & Art', category: 'Nails', duration: 120, price: R(9500), buffer: 10, description: 'Structured extensions with custom nail art and a flawless finish.', color: '#B16A4A', staff: [hira] },
    // Skin
    { name: 'Signature Glow Facial', category: 'Skin', duration: 60, price: R(9500), buffer: 10, description: 'Deep cleanse, exfoliation, massage and a hydrating mask for instantly radiant skin.', color: '#8A7155', staff: [zainab] },
    { name: 'Hydra Glow Facial', category: 'Skin', duration: 75, price: R(14000), buffer: 10, description: 'Multi-step hydration treatment for a dewy, plump, event-ready glow.', color: '#7E6A52', staff: [zainab] },
    { name: 'Brows & Threading', category: 'Skin', duration: 30, price: R(1500), buffer: 5, description: 'Clean, defined brows and facial threading.', color: '#6F5B45', staff: [zainab, hira] },
    // Spa
    { name: 'Aromatherapy Body Massage', category: 'Spa', duration: 60, price: R(12000), buffer: 15, description: 'Full-body massage with calming essential oils to melt away the week.', color: '#7A8F73', staff: [zainab] },
    { name: 'Hot Stone Therapy', category: 'Spa', duration: 75, price: R(15000), buffer: 15, description: 'Heated stones and deep pressure work for lasting relief from tension.', color: '#6E826A', staff: [zainab] },
  ];
  const svcIds = servicesSeed.map((s, i) => {
    const id = db
      .prepare(
        'INSERT INTO services (name, category, description, duration_min, price_cents, buffer_min, color, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
      )
      .run(s.name, s.category, s.description, s.duration, s.price, s.buffer, s.color, i).lastInsertRowid;
    const link = db.prepare('INSERT INTO service_staff (service_id, staff_id) VALUES (?, ?)');
    for (const sid of s.staff) link.run(id, sid);
    return id;
  });
  const S = Object.fromEntries(servicesSeed.map((s, i) => [s.name, svcIds[i]]));

  // business hours: Mon-Sun 11:00-19:30, open every day
  const wh = db.prepare('INSERT INTO working_hours (staff_id, weekday, start_min, end_min, is_off) VALUES (?, ?, ?, ?, ?)');
  for (let d = 0; d <= 6; d += 1) wh.run(null, d, 660, 1170, 0);
  // a couple of individual schedules that override the default
  wh.run(zainab, 1, 0, 0, 1); // Zainab off Mondays
  wh.run(hira, 3, 0, 0, 1); // Hira off Wednesdays

  const t = todayStr();
  db.prepare('INSERT INTO holidays (staff_id, start_date, end_date, reason) VALUES (?, ?, ?, ?)').run(sana, addDays(t, 9), addDays(t, 10), 'Training workshop');

  const cp = db.prepare('INSERT INTO coupons (code, description, type, value, min_spend_cents, max_discount_cents, usage_limit) VALUES (?, ?, ?, ?, ?, ?, ?)');
  cp.run('WELCOME10', '10% off your first visit', 'percent', 10, 0, R(3000), 200);
  cp.run('GLOW1500', 'Rs 1,500 off any facial or spa treatment', 'fixed', R(1500), R(9000), null, null);
  cp.run('BRIDAL5000', 'Rs 5,000 off bridal bookings', 'fixed', R(5000), R(60000), null, 30);

  // ---------------------------------------------------------- appointments
  const insertAppt = db.prepare(
    `INSERT INTO appointments (code, customer_id, staff_id, service_id, date, start_min, end_min, status,
      payment_status, payment_method, price_cents, discount_cents, tax_cents, total_cents, paid_cents, notes)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  );
  const usedSlots = new Set();
  const pick = (staffId, date, duration) => {
    for (const start of [660, 690, 720, 780, 840, 900, 960, 1020, 1080]) {
      if (start + duration > 1170) continue;
      const key = `${staffId}|${date}|${start}`;
      if (usedSlots.has(key)) continue;
      let clash = false;
      for (let m = start; m < start + duration + 30; m += 15) {
        if (usedSlots.has(`${staffId}|${date}|${m}`)) { clash = true; break; }
      }
      if (clash) continue;
      for (let m = start; m < start + duration + 30; m += 15) usedSlots.add(`${staffId}|${date}|${m}`);
      return start;
    }
    return null;
  };

  const plan = [
    // past
    { c: 0, s: S['Signature Haircut & Blow-dry'], st: ayesha, off: -21, status: 'completed', method: 'cash' },
    { c: 1, s: S['Signature Glow Facial'], st: zainab, off: -18, status: 'completed', method: 'cash' },
    { c: 2, s: S['Gel Manicure'], st: hira, off: -14, status: 'completed', method: 'cash' },
    { c: 0, s: S['Aromatherapy Body Massage'], st: zainab, off: -11, status: 'completed', method: 'cash' },
    { c: 3, s: S['Balayage & Highlights'], st: sana, off: -9, status: 'completed', method: 'cash' },
    { c: 4, s: S['Party Makeup'], st: mahnoor, off: -7, status: 'completed', method: 'cash' },
    { c: 1, s: S['Hydra Glow Facial'], st: zainab, off: -5, status: 'completed', method: 'cash' },
    { c: 2, s: S['Luxury Pedicure'], st: hira, off: -3, status: 'completed', method: 'cash' },
    { c: 3, s: S['Brows & Threading'], st: zainab, off: -2, status: 'cancelled', method: 'cash', reason: 'Customer rescheduled' },
    { c: 4, s: S['Global Hair Colour'], st: sana, off: -1, status: 'completed', method: 'cash' },
    // upcoming
    { c: 0, s: S['Keratin Smoothing Treatment'], st: sana, off: 1, status: 'confirmed', method: 'cash' },
    { c: 1, s: S['Signature Glow Facial'], st: zainab, off: 2, status: 'confirmed', method: 'cash' },
    { c: 2, s: S['Gel Manicure'], st: hira, off: 2, status: 'confirmed', method: 'cash' },
    { c: 3, s: S['Bridal Makeup (Signature)'], st: mahnoor, off: 3, status: 'confirmed', method: 'cash' },
    { c: 4, s: S['Signature Haircut & Blow-dry'], st: ayesha, off: 4, status: 'confirmed', method: 'cash' },
    { c: 0, s: S['Party Hairstyling'], st: ayesha, off: 5, status: 'confirmed', method: 'cash' },
    { c: 1, s: S['Hot Stone Therapy'], st: zainab, off: 6, status: 'confirmed', method: 'cash' },
    { c: 2, s: S['Engagement & Walima Makeup'], st: mahnoor, off: 7, status: 'confirmed', method: 'cash' },
    { c: 3, s: S['Nail Extensions & Art'], st: hira, off: 8, status: 'confirmed', method: 'cash' },
    { c: 4, s: S['Deep Conditioning Hair Spa'], st: ayesha, off: 9, status: 'confirmed', method: 'cash' },
    { c: 0, s: S['Hydra Glow Facial'], st: zainab, off: 12, status: 'confirmed', method: 'cash' },
    { c: 1, s: S['Party Makeup'], st: mahnoor, off: 14, status: 'confirmed', method: 'cash' },
  ];

  const completedIds = [];
  for (const p of plan) {
    const svc = db.prepare('SELECT * FROM services WHERE id = ?').get(p.s);
    const date = addDays(t, p.off);
    const dow = weekdayOf(date);
    if ((p.st === zainab && dow === 1) || (p.st === hira && dow === 3)) continue;
    const start = pick(p.st, date, svc.duration_min);
    if (start === null) continue;
    const paid = p.status === 'cancelled' ? 0 : p.method === 'card' ? svc.price_cents : 0;
    const info = insertAppt.run(
      bookingCode(),
      custIds[p.c],
      p.st,
      p.s,
      date,
      start,
      start + svc.duration_min,
      p.status,
      p.status === 'cancelled' ? 'unpaid' : paid >= svc.price_cents ? 'paid' : 'unpaid',
      p.method,
      svc.price_cents,
      0,
      0,
      svc.price_cents,
      paid,
      p.status === 'cancelled' ? p.reason : null
    );
    if (p.status === 'completed') completedIds.push({ id: info.lastInsertRowid, customer: custIds[p.c], staff: p.st, service: p.s });
  }

  const reviewTexts = [
    { rating: 5, comment: 'Ayesha understood exactly what I wanted. Best haircut I have had in Lahore, hands down.' },
    { rating: 5, comment: 'The glow facial was heavenly and my skin looked amazing at the wedding the next day.' },
    { rating: 5, comment: 'Gel manicure still perfect after three weeks. Beautiful, clean, relaxing space.' },
    { rating: 5, comment: 'The aromatherapy massage was exactly what I needed after a brutal month.' },
    { rating: 4, comment: 'Gorgeous balayage and Sana was so careful with my hair. Worth every rupee.' },
    { rating: 5, comment: 'Mahnoor made me feel like a million bucks. My party makeup lasted until 3 am!' },
  ];
  const insReview = db.prepare(
    'INSERT INTO reviews (appointment_id, customer_id, staff_id, service_id, rating, comment) VALUES (?, ?, ?, ?, ?, ?)'
  );
  completedIds.slice(0, reviewTexts.length).forEach((a, i) => {
    const r = reviewTexts[i];
    insReview.run(a.id, a.customer, a.staff, a.service, r.rating, r.comment);
  });
  db.prepare(
    'UPDATE staff SET rating = COALESCE((SELECT ROUND(AVG(rating), 1) FROM reviews WHERE reviews.staff_id = staff.id), 0)'
  ).run();
  return true;
});

const done = tx();
const s = getSettings();
if (!done) {
  console.log('Database already contains data — run `npm run reset` to wipe and reseed.');
} else {
  console.log(`\n🌱 Seeded ${s.business_name}`);
  console.log('   Admin      admin@nooreysalon.com / Admin@123   (change this before going live!)');
  console.log('   Staff      ayesha@nooreysalon.com / Staff@123');
  console.log('   Customer   fatima@example.com / Customer@123\n');
}
