import express from 'express';
import { db } from '../db/index.js';
import { asyncRoute, fail } from '../middleware/http.js';
import { requireAdmin } from '../middleware/auth.js';
import { removeImage } from '../lib/images.js';

const router = express.Router();

function staffServices(staffId) {
  return db
    .prepare(
      `SELECT s.id, s.name, s.duration_min, s.price_cents, s.color
       FROM services s JOIN service_staff ss ON ss.service_id = s.id
       WHERE ss.staff_id = ? AND s.is_active = 1`
    )
    .all(staffId);
}

function decorate(row) {
  return { ...row, services: staffServices(row.id) };
}

router.get('/', (req, res) => {
  const rows = db
    .prepare(`SELECT * FROM staff ${req.query.all === '1' && req.user?.role === 'admin' ? '' : 'WHERE is_active = 1'} ORDER BY name`)
    .all();
  res.json({ staff: rows.map(decorate) });
});

router.get('/:id', (req, res) => {
  const row = db.prepare('SELECT * FROM staff WHERE id = ?').get(req.params.id);
  if (!row) return fail(404, 'Staff member not found');
  res.json({ staff: decorate(row) });
});

router.post('/', requireAdmin, (req, res) => {
  const b = req.body || {};
  if (!b.name) return fail(400, 'Name is required');
  let userId = null;
  if (b.email) {
    const u = db.prepare('SELECT id FROM users WHERE email = ?').get(b.email);
    if (u) userId = u.id;
    else {
      const info = db.prepare("INSERT INTO users (name, email, phone, role, password_hash) VALUES (?, ?, ?, 'staff', ?)").run(
        b.name,
        b.email,
        b.phone || null,
        null
      );
      userId = info.lastInsertRowid;
    }
  }
  const info = db
    .prepare('INSERT INTO staff (user_id, name, title, bio, email, phone, avatar_url, color, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)')
    .run(userId, b.name, b.title || null, b.bio || null, b.email || null, b.phone || null, null, b.color || '#b8935a', b.is_active === false ? 0 : 1);
  res.status(201).json({ staff: decorate(db.prepare('SELECT * FROM staff WHERE id = ?').get(info.lastInsertRowid)) });
});

router.put('/:id', requireAdmin, (req, res) => {
  const b = req.body || {};
  const row = db.prepare('SELECT * FROM staff WHERE id = ?').get(req.params.id);
  if (!row) return fail(404, 'Staff member not found');
  db.prepare(
    `UPDATE staff SET name = ?, title = ?, bio = ?, email = ?, phone = ?, avatar_url = ?, color = ?, is_active = ? WHERE id = ?`
  ).run(
    b.name ?? row.name,
    b.title ?? row.title,
    b.bio ?? row.bio,
    b.email ?? row.email,
    b.phone ?? row.phone,
    row.avatar_url,
    b.color ?? row.color,
    b.is_active === undefined ? row.is_active : b.is_active ? 1 : 0,
    row.id
  );
  if (Array.isArray(b.serviceIds)) {
    db.prepare('DELETE FROM service_staff WHERE staff_id = ?').run(row.id);
    const link = db.prepare('INSERT OR IGNORE INTO service_staff (service_id, staff_id) VALUES (?, ?)');
    for (const sid of b.serviceIds) link.run(Number(sid), row.id);
  }
  res.json({ staff: decorate(db.prepare('SELECT * FROM staff WHERE id = ?').get(row.id)) });
});

router.delete('/:id', requireAdmin, (req, res) => {
  const old = db.prepare('SELECT avatar_url FROM staff WHERE id = ?').get(req.params.id);
  db.prepare('DELETE FROM staff WHERE id = ?').run(req.params.id);
  removeImage(old?.avatar_url);
  res.json({ ok: true });
});

// Staff photo upload is intentionally disabled (staff show initials only).

// ---------------------------------------------------------------- business-wide defaults
// declared before /:id/* so "business" is not captured as a staff id
router.get('/business/schedule', requireAdmin, (_req, res) => {
  res.json({
    working_hours: db.prepare('SELECT * FROM working_hours WHERE staff_id IS NULL ORDER BY weekday').all(),
    breaks: db.prepare('SELECT * FROM breaks WHERE staff_id IS NULL ORDER BY weekday, start_min').all(),
    holidays: db.prepare('SELECT * FROM holidays WHERE staff_id IS NULL ORDER BY start_date').all(),
  });
});

router.put('/business/schedule', requireAdmin, (req, res) => {
  const { working_hours = [], breaks = [], holidays = [] } = req.body || {};
  const tx = db.transaction(() => {
    db.prepare('DELETE FROM working_hours WHERE staff_id IS NULL').run();
    db.prepare('DELETE FROM breaks WHERE staff_id IS NULL').run();
    db.prepare('DELETE FROM holidays WHERE staff_id IS NULL').run();
    const wh = db.prepare('INSERT INTO working_hours (staff_id, weekday, start_min, end_min, is_off) VALUES (NULL, ?, ?, ?, ?)');
    for (const h of working_hours) wh.run(Number(h.weekday), Number(h.start_min), Number(h.end_min), h.is_off ? 1 : 0);
    const br = db.prepare('INSERT INTO breaks (staff_id, weekday, start_min, end_min, label) VALUES (NULL, ?, ?, ?, ?)');
    for (const b of breaks) br.run(Number(b.weekday), Number(b.start_min), Number(b.end_min), b.label || 'Break');
    const ho = db.prepare('INSERT INTO holidays (staff_id, start_date, end_date, reason) VALUES (NULL, ?, ?, ?)');
    for (const h of holidays) ho.run(h.start_date, h.end_date, h.reason || null);
  });
  tx();
  res.json({ ok: true });
});

// ---------------------------------------------------------------- schedule
router.get('/:id/schedule', requireAdmin, (req, res) => {
  const id = Number(req.params.id);
  res.json({
    working_hours: db.prepare('SELECT * FROM working_hours WHERE staff_id = ? ORDER BY weekday').all(id),
    breaks: db.prepare('SELECT * FROM breaks WHERE staff_id = ? ORDER BY weekday, start_min').all(id),
    holidays: db.prepare('SELECT * FROM holidays WHERE staff_id = ? ORDER BY start_date').all(id),
  });
});

router.put('/:id/schedule', requireAdmin, (req, res) => {
  const id = Number(req.params.id);
  const { working_hours = [], breaks = [], holidays = [] } = req.body || {};
  const tx = db.transaction(() => {
    db.prepare('DELETE FROM working_hours WHERE staff_id = ?').run(id);
    db.prepare('DELETE FROM breaks WHERE staff_id = ?').run(id);
    db.prepare('DELETE FROM holidays WHERE staff_id = ?').run(id);
    const wh = db.prepare('INSERT INTO working_hours (staff_id, weekday, start_min, end_min, is_off) VALUES (?, ?, ?, ?, ?)');
    for (const h of working_hours) wh.run(id, Number(h.weekday), Number(h.start_min), Number(h.end_min), h.is_off ? 1 : 0);
    const br = db.prepare('INSERT INTO breaks (staff_id, weekday, start_min, end_min, label) VALUES (?, ?, ?, ?, ?)');
    for (const b of breaks) br.run(id, Number(b.weekday), Number(b.start_min), Number(b.end_min), b.label || 'Break');
    const ho = db.prepare('INSERT INTO holidays (staff_id, start_date, end_date, reason) VALUES (?, ?, ?, ?)');
    for (const h of holidays) ho.run(id, h.start_date, h.end_date, h.reason || null);
  });
  tx();
  res.json({ ok: true });
});

export default router;
