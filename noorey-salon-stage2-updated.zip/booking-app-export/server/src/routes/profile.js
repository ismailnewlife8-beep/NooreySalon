import express from 'express';
import bcrypt from 'bcryptjs';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { db, DATA_DIR } from '../db/index.js';
import { asyncRoute, fail } from '../middleware/http.js';
import { requireAuth } from '../middleware/auth.js';
import { todayStr, nowMinutes } from '../lib/time.js';

const router = express.Router();
router.use(requireAuth);

const USER_COLS = 'id, role, name, email, phone, avatar_url, email_verified, notify_email, notify_sms, is_active, created_at';
export const UPLOAD_DIR = path.join(DATA_DIR, 'uploads');
const AVATAR_DIR = path.join(UPLOAD_DIR, 'avatars');
fs.mkdirSync(AVATAR_DIR, { recursive: true });

const normPhone = (phone) => {
  const raw = String(phone || '').trim();
  if (!raw) return null;
  let d = raw.replace(/[^\d+]/g, '');
  if (d.startsWith('00')) d = `+${d.slice(2)}`;
  if (/^03\d{9}$/.test(d)) d = `+92${d.slice(1)}`;
  else if (/^92\d{10}$/.test(d)) d = `+${d}`;
  return d;
};

/** Identify the real image type from its first bytes (never trust the declared MIME type). */
function sniffImage(buf) {
  if (buf.length > 3 && buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return 'jpg';
  if (buf.length > 8 && buf.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return 'png';
  if (buf.length > 12 && buf.subarray(0, 4).toString() === 'RIFF' && buf.subarray(8, 12).toString() === 'WEBP') return 'webp';
  return null;
}

function removeOldAvatar(url) {
  if (!url || !url.startsWith('/uploads/avatars/')) return;
  const file = path.join(AVATAR_DIR, path.basename(url));
  fs.rm(file, { force: true }, () => {});
}

router.post('/me/avatar', (req, res) => {
  const data = String(req.body?.image || '');
  const m = data.match(/^data:image\/(?:jpeg|png|webp);base64,([A-Za-z0-9+/=]+)$/);
  if (!m) return fail(400, 'Please choose a JPG, PNG or WebP image');
  const buf = Buffer.from(m[1], 'base64');
  if (buf.length > 800 * 1024) return fail(413, 'That photo is too large. Please pick a smaller one.');
  const ext = sniffImage(buf);
  if (!ext) return fail(400, 'That file is not a valid image');
  const name = `${req.user.id}-${crypto.randomBytes(6).toString('hex')}.${ext}`;
  fs.writeFileSync(path.join(AVATAR_DIR, name), buf);
  const prev = db.prepare('SELECT avatar_url FROM users WHERE id = ?').get(req.user.id)?.avatar_url;
  const url = `/uploads/avatars/${name}`;
  db.prepare('UPDATE users SET avatar_url = ? WHERE id = ?').run(url, req.user.id);
  removeOldAvatar(prev);
  res.json({ user: db.prepare(`SELECT ${USER_COLS} FROM users WHERE id = ?`).get(req.user.id) });
});

router.delete('/me/avatar', (req, res) => {
  const prev = db.prepare('SELECT avatar_url FROM users WHERE id = ?').get(req.user.id)?.avatar_url;
  db.prepare('UPDATE users SET avatar_url = NULL WHERE id = ?').run(req.user.id);
  removeOldAvatar(prev);
  res.json({ user: db.prepare(`SELECT ${USER_COLS} FROM users WHERE id = ?`).get(req.user.id) });
});

router.put('/me', (req, res) => {
  const b = req.body || {};
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);

  if (b.email && String(b.email).toLowerCase() !== String(user.email || '').toLowerCase()) {
    const clash = db.prepare('SELECT id FROM users WHERE email = ? AND id != ?').get(String(b.email).toLowerCase(), user.id);
    if (clash) return fail(409, 'That email is already in use');
  }
  const newPhone = b.phone === undefined ? user.phone : normPhone(b.phone);
  if (newPhone && newPhone !== user.phone) {
    const clash = db.prepare('SELECT id FROM users WHERE phone = ? AND id != ?').get(newPhone, user.id);
    if (clash) return fail(409, 'That phone number is already in use');
  }
  const newEmail = b.email ? String(b.email).toLowerCase().trim() : user.email;
  const emailChanged = newEmail !== user.email;
  let passwordHash = user.password_hash;
  if (b.newPassword) {
    if (user.password_hash && !b.currentPassword) return fail(400, 'Current password is required');
    if (user.password_hash && !bcrypt.compareSync(String(b.currentPassword), user.password_hash)) {
      return fail(400, 'Current password is incorrect');
    }
    if (String(b.newPassword).length < 8) return fail(400, 'New password must be at least 8 characters');
    passwordHash = bcrypt.hashSync(String(b.newPassword), 10);
  }

  db.prepare(
    'UPDATE users SET name = ?, email = ?, phone = ?, email_verified = ?, notify_email = ?, notify_sms = ?, password_hash = ? WHERE id = ?'
  ).run(
    b.name ? String(b.name).trim() : user.name,
    newEmail,
    newPhone,
    emailChanged ? 0 : user.email_verified,
    b.notify_email === undefined ? user.notify_email : b.notify_email ? 1 : 0,
    b.notify_sms === undefined ? user.notify_sms : b.notify_sms ? 1 : 0,
    passwordHash,
    user.id
  );

  res.json({
    user: db
      .prepare(`SELECT ${USER_COLS} FROM users WHERE id = ?`)
      .get(user.id),
  });
});

router.get('/me/summary', (req, res) => {
  const id = req.user.id;
  const totals = db
    .prepare("SELECT COUNT(*) total, SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) completed, SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) cancelled FROM appointments WHERE customer_id = ?")
    .get(id);
  const spend = db
    .prepare("SELECT COALESCE(SUM(paid_cents), 0) paid, COALESCE(SUM(total_cents), 0) total FROM appointments WHERE customer_id = ? AND status != 'cancelled'")
    .get(id);
  const upcoming = db
    .prepare("SELECT COUNT(*) c FROM appointments WHERE customer_id = ? AND status IN ('pending','confirmed') AND (date > ? OR (date = ? AND end_min >= ?))")
    .get(id, todayStr(), todayStr(), nowMinutes());
  const favourite = db
    .prepare(
      `SELECT s.name, COUNT(*) c FROM appointments a JOIN services s ON s.id = a.service_id
       WHERE a.customer_id = ? GROUP BY a.service_id ORDER BY c DESC LIMIT 1`
    )
    .get(id);
  res.json({
    total: totals.total || 0,
    completed: totals.completed || 0,
    cancelled: totals.cancelled || 0,
    upcoming: upcoming.c || 0,
    paid_cents: spend.paid || 0,
    lifetime_cents: spend.total || 0,
    favourite_service: favourite?.name || null,
  });
});

export default router;
