import express from 'express';
import bcrypt from 'bcryptjs';
import { db, getSettings } from '../db/index.js';
import { signToken } from '../lib/tokens.js';
import { numericCode } from '../lib/ids.js';
import { sendSms } from '../lib/sms.js';
import { sendEmail } from '../lib/email.js';
import { verifyGoogleToken } from '../lib/google.js';
import { asyncRoute, fail } from '../middleware/http.js';
import { requireAuth } from '../middleware/auth.js';
import { rateLimit } from '../lib/rateLimit.js';
import { createToken, consumeToken } from '../lib/emailTokens.js';

const router = express.Router();
const SAFE = 'id, role, name, email, phone, avatar_url, email_verified, notify_email, notify_sms, is_active, created_at';

function userById(id) {
  return db.prepare(`SELECT ${SAFE} FROM users WHERE id = ?`).get(id);
}

function issue(res, user) {
  return res.json({ token: signToken(user), user });
}

/** Normalise to a canonical form so 0300-1234567, 03001234567 and +923001234567 are the same number. */
function normalizePhone(phone) {
  const raw = String(phone || '').trim();
  if (!raw) return null;
  if (raw.includes('@')) return raw.toLowerCase();
  let d = raw.replace(/[^\d+]/g, '');
  if (d.startsWith('00')) d = `+${d.slice(2)}`;
  if (/^03\d{9}$/.test(d)) d = `+92${d.slice(1)}`;
  else if (/^92\d{10}$/.test(d)) d = `+${d}`;
  return d;
}

const isEmail = (v) => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(String(v || ''));
const loginLimit = rateLimit({ key: 'login', windowMs: 15 * 60_000, max: 12 });
const registerLimit = rateLimit({ key: 'register', windowMs: 60 * 60_000, max: 10 });
const otpLimit = rateLimit({ key: 'otp', windowMs: 10 * 60_000, max: 8 });
const resetLimit = rateLimit({ key: 'reset', windowMs: 60 * 60_000, max: 6 });

function clientOrigin(req) {
  return process.env.PUBLIC_URL || process.env.CLIENT_ORIGIN || `${req.protocol}://${req.get('host')}`;
}

async function sendVerifyEmail(req, user) {
  if (!user?.email) return;
  const token = createToken(user.id, 'verify', 3 * 24 * 3600_000);
  const biz = getSettings().business_name;
  await sendEmail({
    to: user.email,
    subject: `Confirm your email — ${biz}`,
    text: `Hi ${user.name},\n\nWelcome to ${biz}! Please confirm your email:\n${clientOrigin(req)}/verify-email?token=${token}\n\nThis link is valid for 3 days.\n\n— ${biz}`,
  });
}

router.post(
  '/register',
  registerLimit,
  asyncRoute(async (req, res) => {
    const { name, email, phone, password } = req.body || {};
    if (!name || !email || !password) return fail(400, 'Name, email and password are required');
    if (!isEmail(email)) return fail(400, 'Please enter a valid email address');
    if (String(password).length < 8) return fail(400, 'Password must be at least 8 characters');

    const exists = db.prepare('SELECT id FROM users WHERE email = ?').get(String(email).toLowerCase().trim());
    if (exists) return fail(409, 'An account with this email already exists. Please sign in instead.');
    const phoneNorm = normalizePhone(phone);
    if (phoneNorm) {
      const phoneTaken = db.prepare('SELECT id FROM users WHERE phone = ?').get(phoneNorm);
      if (phoneTaken) return fail(409, 'An account with this phone number already exists. Please sign in instead.');
    }

    const info = db
      .prepare('INSERT INTO users (name, email, phone, password_hash) VALUES (?, ?, ?, ?)')
      .run(String(name).trim(), String(email).toLowerCase().trim(), phoneNorm, bcrypt.hashSync(password, 10));
    const user = userById(info.lastInsertRowid);
    if (user?.email) {
      await sendEmail({
        to: user.email,
        subject: `Welcome to ${getSettings().business_name}`,
        text: `Hi ${user.name},\n\nYour account is ready. You can now book appointments, manage them and leave reviews.\n\n— ${getSettings().business_name}`,
      });
      await sendVerifyEmail(req, user);
    }
    return issue(res, user);
  })
);

router.post(
  '/login',
  loginLimit,
  asyncRoute(async (req, res) => {
    const { email, password } = req.body || {};
    const id = String(email || '').trim();
    const user = db.prepare('SELECT * FROM users WHERE email = ? OR phone = ?').get(id.toLowerCase(), normalizePhone(id) || id);
    if (!user || !user.password_hash || !bcrypt.compareSync(String(password || ''), user.password_hash)) {
      return fail(401, 'Incorrect email or password');
    }
    if (!user.is_active) return fail(403, 'This account has been disabled');
    return issue(res, userById(user.id));
  })
);

// ---------------------------------------------------------------- phone / email OTP
router.post(
  '/otp/request',
  otpLimit,
  asyncRoute(async (req, res) => {
    const { phone, purpose = 'login' } = req.body || {};
    const dest = normalizePhone(phone);
    if (!dest) return fail(400, 'Phone number is required');

    const recent = db
      .prepare('SELECT COUNT(*) c FROM otp_codes WHERE destination = ? AND created_at > datetime(\'now\', \'-1 minute\')')
      .get(dest).c;
    if (recent >= 3) return fail(429, 'Too many codes requested. Please wait a minute.');

    const code = numericCode(6);
    db.prepare('DELETE FROM otp_codes WHERE destination = ? AND purpose = ? AND consumed_at IS NULL').run(dest, purpose);
    db.prepare('INSERT INTO otp_codes (destination, channel, code, purpose, expires_at) VALUES (?, ?, ?, ?, ?)').run(
      dest,
      dest.includes('@') ? 'email' : 'sms',
      code,
      purpose,
      String(Date.now() + 10 * 60 * 1000)
    );

    const message = `${code} is your ${getSettings().business_name} verification code (valid 10 minutes).`;
    const result = dest.includes('@')
      ? await sendEmail({ to: dest, subject: 'Your verification code', text: message })
      : await sendSms({ to: dest, body: message });

    const isDev = process.env.NODE_ENV !== 'production' && result?.simulated;
    return res.json({
      ok: true,
      channel: dest.includes('@') ? 'email' : 'sms',
      delivered: Boolean(result?.ok),
      provider: result?.provider || 'dev',
      // Surfaced only when no SMS/email provider is configured, so you can still test the flow.
      devCode: isDev ? code : undefined,
      hint: isDev ? 'No SMS/email provider configured — code shown here and in server logs.' : undefined,
    });
  })
);

router.post(
  '/otp/verify',
  otpLimit,
  asyncRoute(async (req, res) => {
    const { phone, code, name } = req.body || {};
    const dest = normalizePhone(phone);
    const latest = db.prepare('SELECT * FROM otp_codes WHERE destination = ? AND consumed_at IS NULL ORDER BY id DESC LIMIT 1').get(dest);
    if (!latest) return fail(400, 'Invalid or expired code');
    if (latest.attempts >= 5) return fail(429, 'Too many wrong attempts. Please request a new code.');
    if (latest.code !== String(code || '').trim()) {
      db.prepare('UPDATE otp_codes SET attempts = attempts + 1 WHERE id = ?').run(latest.id);
      return fail(400, 'Invalid or expired code');
    }
    const record = latest;
    if (Number(record.expires_at) < Date.now()) return fail(400, 'That code has expired. Request a new one.');

    db.prepare('UPDATE otp_codes SET consumed_at = datetime(\'now\') WHERE id = ?').run(record.id);

    let user = db.prepare('SELECT * FROM users WHERE phone = ?').get(dest);
    if (!user) {
      const email = dest.includes('@') ? dest : null;
      const info = db
        .prepare('INSERT INTO users (name, phone, email, phone_verified) VALUES (?, ?, ?, 1)')
        .run(name || (email ? email.split('@')[0] : `Guest ${dest.slice(-4)}`), dest, email);
      user = userById(info.lastInsertRowid);
    } else {
      db.prepare('UPDATE users SET phone_verified = 1 WHERE id = ?').run(user.id);
      user = userById(user.id);
    }
    if (!user.is_active) return fail(403, 'This account has been disabled');
    return issue(res, user);
  })
);

// ---------------------------------------------------------------- Google
router.post(
  '/google',
  asyncRoute(async (req, res) => {
    const { credential } = req.body || {};
    if (!credential) return fail(400, 'Missing Google credential');
    const profile = await verifyGoogleToken(credential);
    if (!profile) return fail(401, 'Google sign-in is not configured or the token was rejected');

    let user = db.prepare('SELECT * FROM users WHERE google_id = ? OR email = ?').get(profile.googleId, profile.email);
    if (!user) {
      const info = db
        .prepare('INSERT INTO users (name, email, google_id, avatar_url, email_verified) VALUES (?, ?, ?, ?, 1)')
        .run(profile.name, profile.email, profile.googleId, profile.avatarUrl);
      user = userById(info.lastInsertRowid);
    } else {
      db.prepare('UPDATE users SET google_id = COALESCE(google_id, ?), avatar_url = COALESCE(avatar_url, ?) WHERE id = ?').run(
        profile.googleId,
        profile.avatarUrl,
        user.id
      );
      user = userById(user.id);
    }
    return issue(res, user);
  })
);

// ---------------------------------------------------------------- forgot / reset password, email verification
router.post(
  '/forgot-password',
  resetLimit,
  asyncRoute(async (req, res) => {
    const email = String(req.body?.email || '').toLowerCase().trim();
    // Always answer the same way so the form cannot be used to discover which emails have accounts.
    const user = isEmail(email) ? db.prepare('SELECT * FROM users WHERE email = ? AND is_active = 1').get(email) : null;
    let devLink;
    if (user) {
      const token = createToken(user.id, 'reset', 3600_000);
      const link = `${clientOrigin(req)}/reset-password?token=${token}`;
      const result = await sendEmail({
        to: user.email,
        subject: `Reset your password — ${getSettings().business_name}`,
        text: `Hi ${user.name},\n\nUse this link to choose a new password (valid for 1 hour):\n${link}\n\nIf you did not ask for this, you can ignore this email.\n\n— ${getSettings().business_name}`,
      });
      if (result?.simulated && process.env.NODE_ENV !== 'production') devLink = link;
    }
    res.json({ ok: true, message: 'If an account exists for that email, a reset link is on its way.', devLink });
  })
);

router.post(
  '/reset-password',
  resetLimit,
  asyncRoute(async (req, res) => {
    const { token, password } = req.body || {};
    if (String(password || '').length < 8) return fail(400, 'Password must be at least 8 characters');
    const userId = consumeToken(token, 'reset');
    if (!userId) return fail(400, 'This reset link is invalid or has expired. Please request a new one.');
    db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(bcrypt.hashSync(String(password), 10), userId);
    res.json({ ok: true });
  })
);

router.post(
  '/verify-email',
  asyncRoute(async (req, res) => {
    const userId = consumeToken(req.body?.token, 'verify');
    if (!userId) return fail(400, 'This confirmation link is invalid or has expired.');
    db.prepare('UPDATE users SET email_verified = 1 WHERE id = ?').run(userId);
    res.json({ ok: true });
  })
);

router.post(
  '/resend-verification',
  requireAuth,
  resetLimit,
  asyncRoute(async (req, res) => {
    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);
    if (!user?.email) return fail(400, 'Add an email address to your profile first');
    if (user.email_verified) return res.json({ ok: true, already: true });
    await sendVerifyEmail(req, user);
    res.json({ ok: true });
  })
);

router.get('/me', requireAuth, (req, res) => res.json({ user: req.user }));

export default router;
