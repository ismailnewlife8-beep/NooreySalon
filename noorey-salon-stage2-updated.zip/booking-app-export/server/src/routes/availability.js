import express from 'express';
import { getAvailability, staffForService } from '../lib/availability.js';
import { asyncRoute } from '../middleware/http.js';
import { addDays } from '../lib/time.js';

const router = express.Router();

router.get(
  '/',
  asyncRoute(async (req, res) => {
    const { serviceId, date, staffId, ignoreAppointmentId } = req.query;
    if (!serviceId || !date) return res.status(400).json({ error: 'serviceId and date are required' });
    res.json(
      getAvailability({
        date: String(date),
        serviceId: Number(serviceId),
        staffId: staffId ? Number(staffId) : null,
        ignoreAppointmentId: ignoreAppointmentId ? Number(ignoreAppointmentId) : null,
      })
    );
  })
);

/** Lightweight per-day availability summary so the date picker can show dot indicators. */
router.get(
  '/range',
  asyncRoute(async (req, res) => {
    const { serviceId, from, to, staffId } = req.query;
    if (!serviceId || !from || !to) return res.status(400).json({ error: 'serviceId, from and to are required' });
    const days = [];
    let cursor = String(from);
    let guard = 0;
    while (cursor <= String(to) && guard < 90) {
      const a = getAvailability({
        date: cursor,
        serviceId: Number(serviceId),
        staffId: staffId ? Number(staffId) : null,
      });
      days.push({ date: cursor, count: a.slots?.filter((s) => s.available).length || 0, closed: Boolean(a.closed) });
      cursor = addDays(cursor, 1);
      guard += 1;
    }
    res.json({ days });
  })
);

/** Which staff members can deliver a service (used by the booking stepper). */
router.get('/staff/:serviceId', (req, res) => {
  res.json({ staff: staffForService(Number(req.params.serviceId)) });
});

export default router;
