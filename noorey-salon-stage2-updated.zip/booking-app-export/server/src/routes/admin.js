import express from 'express';
import { db, getSettings, setSettings, capabilities } from '../db/index.js';
import { asyncRoute, fail } from '../middleware/http.js';
import { requireAdmin } from '../middleware/auth.js';
import { listAppointments, getAppointment, createAppointment, cancelAppointment, rescheduleAppointment } from '../lib/bookings.js';
import { notifyAppointment, broadcast } from '../lib/notify.js';
import { workingHoursFor } from '../lib/availability.js';
import { todayStr, nowMinutes, addDays, weekdayOf, indexToDate, dateToIndex } from '../lib/time.js';
import { couponCode } from '../lib/ids.js';
import { saveImage, removeImage, parseGallery } from '../lib/images.js';

const router = express.Router();
router.use(requireAdmin);

const money = (cents) => (Number(cents) || 0) / 100;

// ---------------------------------------------------------------- dashboard
router.get('/dashboard', (_req, res) => {
  const today = todayStr();
  const from = addDays(today, -13);
  const monthStart = `${today.slice(0, 7)}-01`;

  const todayRows = listAppointments({ where: "WHERE a.date = ? AND a.status != 'cancelled'", params: [today], order: 'a.start_min ASC' });
  const upcoming = listAppointments({
    where: "WHERE a.date > ? AND a.status IN ('pending','confirmed')",
    params: [today],
    order: 'a.date ASC, a.start_min ASC',
    limit: 8,
  });
  const pending = db.prepare("SELECT COUNT(*) c FROM appointments WHERE status = 'pending'").get().c;

  const todayRevenue = db
    .prepare("SELECT COALESCE(SUM(paid_cents), 0) v FROM appointments WHERE date = ? AND status != 'cancelled'")
    .get(today).v;
  const weekBookings = db
    .prepare('SELECT COUNT(*) c FROM appointments WHERE date BETWEEN ? AND ? AND status != ?')
    .get(today, addDays(today, 6), 'cancelled').c;
  const monthRevenue = db
    .prepare("SELECT COALESCE(SUM(paid_cents), 0) v FROM appointments WHERE date >= ? AND status != 'cancelled'")
    .get(monthStart).v;
  const monthRevenueTotal = db
    .prepare("SELECT COALESCE(SUM(total_cents), 0) v FROM appointments WHERE date >= ? AND status != 'cancelled'")
    .get(monthStart).v;
  const newCustomers = db
    .prepare("SELECT COUNT(*) c FROM users WHERE role = 'customer' AND created_at >= ?")
    .get(monthStart).c;
  const avgTicket = db
    .prepare("SELECT COALESCE(AVG(total_cents), 0) v FROM appointments WHERE status != 'cancelled'")
    .get().v;

  // occupancy for today: booked minutes vs staff working minutes
  const staff = db.prepare('SELECT * FROM staff WHERE is_active = 1').all();
  const wd = weekdayOf(today);
  let capacityMin = 0;
  for (const s of staff) {
    for (const h of workingHoursFor(s.id, wd)) {
      if (!h.is_off) capacityMin += Math.max(0, h.end_min - h.start_min);
    }
  }
  const bookedMin = db
    .prepare("SELECT COALESCE(SUM(end_min - start_min), 0) v FROM appointments WHERE date = ? AND status != 'cancelled'")
    .get(today).v;

  const chartRows = db
    .prepare(
      `SELECT date,
              COUNT(*) bookings,
              COALESCE(SUM(CASE WHEN status != 'cancelled' THEN paid_cents ELSE 0 END), 0) revenue
       FROM appointments WHERE date BETWEEN ? AND ? GROUP BY date ORDER BY date`
    )
    .all(from, today);
  const chart = [];
  for (let i = 0; i < 14; i += 1) {
    const d = addDays(from, i);
    const row = chartRows.find((r) => r.date === d);
    chart.push({ date: d, bookings: row?.bookings || 0, revenue: money(row?.revenue || 0) });
  }

  const topServices = db
    .prepare(
      `SELECT s.name, COUNT(*) count, COALESCE(SUM(a.total_cents), 0) revenue
       FROM appointments a JOIN services s ON s.id = a.service_id
       WHERE a.status != 'cancelled' GROUP BY a.service_id ORDER BY count DESC LIMIT 5`
    )
    .all()
    .map((r) => ({ ...r, revenue: money(r.revenue) }));

  const topStaff = db
    .prepare(
      `SELECT st.name, st.color, COUNT(*) count, COALESCE(SUM(a.total_cents), 0) revenue
       FROM appointments a JOIN staff st ON st.id = a.staff_id
       WHERE a.status != 'cancelled' GROUP BY a.staff_id ORDER BY count DESC LIMIT 5`
    )
    .all()
    .map((r) => ({ ...r, revenue: money(r.revenue) }));

  const recentCustomers = db
    .prepare("SELECT id, name, email, phone, avatar_url, created_at FROM users WHERE role = 'customer' ORDER BY id DESC LIMIT 5")
    .all();

  res.json({
    stats: {
      today_bookings: todayRows.length,
      today_revenue: money(todayRevenue),
      week_bookings: weekBookings,
      month_revenue: money(monthRevenue),
      month_pipeline: money(monthRevenueTotal),
      new_customers: newCustomers,
      pending,
      avg_ticket: money(avgTicket),
      occupancy: capacityMin ? Math.round((bookedMin / capacityMin) * 100) : 0,
    },
    today: todayRows,
    upcoming,
    chart,
    topServices,
    topStaff,
    recentCustomers,
  });
});

// ---------------------------------------------------------------- calendar
router.get('/calendar', (req, res) => {
  const { from, to } = req.query;
  const start = from || todayStr();
  const end = to || addDays(start, 30);
  const rows = listAppointments({ where: 'WHERE a.date BETWEEN ? AND ?', params: [start, end], limit: 1000 });
  const byDate = {};
  for (const r of rows) {
    byDate[r.date] = byDate[r.date] || [];
    byDate[r.date].push(r);
  }
  const holidays = db.prepare('SELECT * FROM holidays ORDER BY start_date').all();
  res.json({ appointments: rows, byDate, holidays });
});

// ---------------------------------------------------------------- bookings
router.get('/bookings', (req, res) => {
  const { date, status, q, staffId } = req.query;
  const clauses = [];
  const params = [];
  if (date) { clauses.push('a.date = ?'); params.push(date); }
  if (status && status !== 'all') { clauses.push('a.status = ?'); params.push(status); }
  if (staffId) { clauses.push('a.staff_id = ?'); params.push(Number(staffId)); }
  if (q) {
    clauses.push('(c.name LIKE ? OR c.email LIKE ? OR c.phone LIKE ? OR a.code LIKE ? OR s.name LIKE ?)');
    const like = `%${q}%`;
    params.push(like, like, like, like, like);
  }
  const where = clauses.length ? `WHERE ${clauses.join(' AND ')}` : '';
  res.json({ bookings: listAppointments({ where, params, order: 'a.date DESC, a.start_min DESC', limit: 500 }) });
});

/** Walk-in / phone booking created by staff. */
router.post(
  '/bookings',
  asyncRoute(async (req, res) => {
    const b = req.body || {};
    let customerId = b.customerId ? Number(b.customerId) : null;
    if (!customerId) {
      if (!b.name) return fail(400, 'Customer name is required');
      const existing = b.phone
        ? db.prepare('SELECT id FROM users WHERE phone = ?').get(b.phone)
        : db.prepare('SELECT id FROM users WHERE email = ?').get(b.email || '__none__');
      if (existing) customerId = existing.id;
      else {
        const info = db
          .prepare("INSERT INTO users (name, email, phone, role) VALUES (?, ?, ?, 'customer')")
          .run(b.name, b.email || null, b.phone || null);
        customerId = info.lastInsertRowid;
      }
    }
    const appt = await createAppointment({
      customerId,
      serviceId: Number(b.serviceId),
      staffId: b.staffId ? Number(b.staffId) : null,
      date: String(b.date),
      startMin: Number(b.startMin),
      paymentMethod: b.paymentMethod === 'card' ? 'card' : 'cash',
      couponCode: b.couponCode || null,
      notes: b.notes || null,
      isAdmin: true,
    });
    res.status(201).json({ booking: appt });
  })
);

router.patch('/bookings/:id/status', (req, res) => {
  const appt = getAppointment(req.params.id);
  if (!appt) return fail(404, 'Booking not found');
  const status = req.body?.status;
  if (!['pending', 'confirmed', 'completed', 'cancelled', 'no_show'].includes(status)) return fail(400, 'Invalid status');
  if (status === 'cancelled') return cancelAppointment(appt.id, { reason: req.body?.reason }).then((b) => res.json({ booking: b }));
  db.prepare("UPDATE appointments SET status = ?, updated_at = datetime('now') WHERE id = ?").run(status, appt.id);
  const updated = getAppointment(appt.id);
  if (status === 'completed') notifyAppointment('completed', updated);
  res.json({ booking: updated });
});

router.post(
  '/bookings/:id/reschedule',
  asyncRoute(async (req, res) => {
    const { date, startMin, staffId } = req.body || {};
    const updated = await rescheduleAppointment(req.params.id, {
      date: String(date),
      startMin: Number(startMin),
      staffId: staffId ? Number(staffId) : null,
      isAdmin: true,
    });
    res.json({ booking: updated });
  })
);

// ---------------------------------------------------------------- customers
router.get('/customers', (req, res) => {
  const q = req.query.q ? `%${req.query.q}%` : null;
  const rows = db
    .prepare(
      `SELECT u.id, u.name, u.email, u.phone, u.avatar_url, u.created_at, u.is_active, u.notes,
              COUNT(a.id) visits,
              COALESCE(SUM(CASE WHEN a.status != 'cancelled' THEN a.total_cents ELSE 0 END), 0) spend,
              MAX(a.date) last_visit
       FROM users u LEFT JOIN appointments a ON a.customer_id = u.id
       WHERE u.role = 'customer' ${q ? 'AND (u.name LIKE ? OR u.email LIKE ? OR u.phone LIKE ?)' : ''}
       GROUP BY u.id ORDER BY visits DESC, u.id DESC LIMIT 300`
    )
    .all(...(q ? [q, q, q] : []));
  res.json({ customers: rows.map((r) => ({ ...r, spend: money(r.spend) })) });
});

router.get('/customers/:id', (req, res) => {
  const customer = db
    .prepare('SELECT id, name, email, phone, avatar_url, notes, is_active, created_at, notify_email, notify_sms FROM users WHERE id = ? AND role = \'customer\'')
    .get(req.params.id);
  if (!customer) return fail(404, 'Customer not found');
  const bookings = listAppointments({ where: 'WHERE a.customer_id = ?', params: [customer.id], limit: 100 });
  const reviews = db.prepare('SELECT * FROM reviews WHERE customer_id = ? ORDER BY created_at DESC').all(customer.id);
  res.json({ customer, bookings, reviews });
});

router.put('/customers/:id', (req, res) => {
  const b = req.body || {};
  const row = db.prepare('SELECT * FROM users WHERE id = ?').get(req.params.id);
  if (!row) return fail(404, 'Customer not found');
  db.prepare('UPDATE users SET name = ?, email = ?, phone = ?, notes = ?, is_active = ? WHERE id = ?').run(
    b.name ?? row.name,
    b.email ?? row.email,
    b.phone ?? row.phone,
    b.notes ?? row.notes,
    b.is_active === undefined ? row.is_active : b.is_active ? 1 : 0,
    row.id
  );
  res.json({ ok: true });
});

// ---------------------------------------------------------------- coupons
router.get('/coupons', (_req, res) => {
  res.json({ coupons: db.prepare('SELECT * FROM coupons ORDER BY created_at DESC').all() });
});

router.post('/coupons', (req, res) => {
  const b = req.body || {};
  const code = String(b.code || '').trim().toUpperCase() || couponCode(8);
  if (db.prepare('SELECT id FROM coupons WHERE code = ?').get(code)) return fail(409, 'That code already exists');
  const info = db
    .prepare(
      `INSERT INTO coupons (code, description, type, value, min_spend_cents, max_discount_cents, starts_at, ends_at, usage_limit, is_active)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    )
    .run(
      code,
      b.description || null,
      b.type === 'fixed' ? 'fixed' : 'percent',
      Number(b.value) || 0,
      Number(b.min_spend_cents) || 0,
      b.max_discount_cents ? Number(b.max_discount_cents) : null,
      b.starts_at || null,
      b.ends_at || null,
      b.usage_limit ? Number(b.usage_limit) : null,
      b.is_active === false ? 0 : 1
    );
  res.status(201).json({ coupon: db.prepare('SELECT * FROM coupons WHERE id = ?').get(info.lastInsertRowid) });
});

router.put('/coupons/:id', (req, res) => {
  const b = req.body || {};
  const row = db.prepare('SELECT * FROM coupons WHERE id = ?').get(req.params.id);
  if (!row) return fail(404, 'Coupon not found');
  db.prepare(
    `UPDATE coupons SET code = ?, description = ?, type = ?, value = ?, min_spend_cents = ?, max_discount_cents = ?,
     starts_at = ?, ends_at = ?, usage_limit = ?, is_active = ? WHERE id = ?`
  ).run(
    String(b.code ?? row.code).toUpperCase(),
    b.description ?? row.description,
    b.type ?? row.type,
    Number(b.value ?? row.value),
    Number(b.min_spend_cents ?? row.min_spend_cents),
    b.max_discount_cents === undefined ? row.max_discount_cents : Number(b.max_discount_cents) || null,
    b.starts_at ?? row.starts_at,
    b.ends_at ?? row.ends_at,
    b.usage_limit === undefined ? row.usage_limit : Number(b.usage_limit) || null,
    b.is_active === undefined ? row.is_active : b.is_active ? 1 : 0,
    row.id
  );
  res.json({ coupon: db.prepare('SELECT * FROM coupons WHERE id = ?').get(row.id) });
});

router.delete('/coupons/:id', (req, res) => {
  db.prepare('DELETE FROM coupons WHERE id = ?').run(req.params.id);
  res.json({ ok: true });
});

// ---------------------------------------------------------------- notifications
router.get('/notifications', (req, res) => {
  const limit = Number(req.query.limit) || 50;
  res.json({
    notifications: db
      .prepare(
        `SELECT n.*, u.name user_name FROM notifications n LEFT JOIN users u ON u.id = n.user_id
         ORDER BY n.id DESC LIMIT ?`
      )
      .all(limit),
  });
});

router.post(
  '/notifications',
  asyncRoute(async (req, res) => {
    const { segment = 'all', userIds = [], channel = 'email', subject, body } = req.body || {};
    if (!body) return fail(400, 'Message is required');
    let ids = userIds.map(Number).filter(Boolean);
    if (!ids.length) {
      if (segment === 'upcoming') {
        ids = db
          .prepare("SELECT DISTINCT customer_id id FROM appointments WHERE date >= ? AND status IN ('pending','confirmed')")
          .all(todayStr())
          .map((r) => r.id);
      } else if (segment === 'vip') {
        ids = db
          .prepare("SELECT customer_id id FROM appointments WHERE status != 'cancelled' GROUP BY customer_id HAVING SUM(total_cents) > 0 ORDER BY SUM(total_cents) DESC LIMIT 50")
          .all()
          .map((r) => r.id);
      } else if (segment === 'new') {
        ids = db
          .prepare("SELECT id FROM users WHERE role = 'customer' AND created_at >= ?")
          .all(addDays(todayStr(), -30))
          .map((r) => r.id);
      } else {
        ids = db.prepare("SELECT id FROM users WHERE role = 'customer' AND is_active = 1").all().map((r) => r.id);
      }
    }
    if (!ids.length) return fail(400, 'No recipients in that segment');
    const results = await broadcast({
      userIds: ids,
      channel: channel === 'sms' ? 'sms' : 'email',
      subject: subject || getSettings().business_name,
      body,
    });
    res.json({ ok: true, sent: results.filter((r) => r.ok).length, failed: results.filter((r) => !r.ok).length, total: results.length });
  })
);

// ---------------------------------------------------------------- reports
router.get('/reports', (req, res) => {
  const today = todayStr();
  const from = req.query.from || addDays(today, -29);
  const to = req.query.to || today;

  const byDay = db
    .prepare(
      `SELECT date, COUNT(*) bookings,
              COALESCE(SUM(CASE WHEN status != 'cancelled' THEN total_cents ELSE 0 END), 0) revenue,
              SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) cancelled
       FROM appointments WHERE date BETWEEN ? AND ? GROUP BY date ORDER BY date`
    )
    .all(from, to)
    .map((r) => ({ ...r, revenue: money(r.revenue) }));

  const totals = db
    .prepare(
      `SELECT COUNT(*) bookings,
              COALESCE(SUM(CASE WHEN status != 'cancelled' THEN total_cents ELSE 0 END), 0) revenue,
              COALESCE(SUM(CASE WHEN status != 'cancelled' THEN paid_cents ELSE 0 END), 0) collected,
              COALESCE(SUM(discount_cents), 0) discounts,
              SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) cancelled,
              SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) completed,
              SUM(CASE WHEN status = 'no_show' THEN 1 ELSE 0 END) no_shows
       FROM appointments WHERE date BETWEEN ? AND ?`
    )
    .get(from, to);

  const byService = db
    .prepare(
      `SELECT s.name, COUNT(*) bookings, COALESCE(SUM(a.total_cents), 0) revenue
       FROM appointments a JOIN services s ON s.id = a.service_id
       WHERE a.date BETWEEN ? AND ? AND a.status != 'cancelled'
       GROUP BY a.service_id ORDER BY revenue DESC`
    )
    .all(from, to)
    .map((r) => ({ ...r, revenue: money(r.revenue) }));

  const byStaff = db
    .prepare(
      `SELECT st.name, st.color, COUNT(*) bookings, COALESCE(SUM(a.total_cents), 0) revenue,
              COALESCE(SUM(a.end_min - a.start_min), 0) minutes
       FROM appointments a JOIN staff st ON st.id = a.staff_id
       WHERE a.date BETWEEN ? AND ? AND a.status != 'cancelled'
       GROUP BY a.staff_id ORDER BY revenue DESC`
    )
    .all(from, to)
    .map((r) => ({ ...r, revenue: money(r.revenue) }));

  const byPayment = db
    .prepare(
      `SELECT COALESCE(payment_method, 'unset') method, COUNT(*) bookings, COALESCE(SUM(paid_cents), 0) revenue
       FROM appointments WHERE date BETWEEN ? AND ? AND status != 'cancelled' GROUP BY payment_method`
    )
    .all(from, to)
    .map((r) => ({ ...r, revenue: money(r.revenue) }));

  const byHour = db
    .prepare(
      `SELECT CAST(start_min / 60 AS INTEGER) hour, COUNT(*) bookings
       FROM appointments WHERE date BETWEEN ? AND ? AND status != 'cancelled' GROUP BY hour ORDER BY hour`
    )
    .all(from, to);

  const newVsReturning = db
    .prepare(
      `SELECT CASE WHEN (SELECT COUNT(*) FROM appointments x WHERE x.customer_id = a.customer_id AND x.id < a.id) = 0
                   THEN 'new' ELSE 'returning' END type,
              COUNT(*) bookings,
              COALESCE(SUM(a.total_cents), 0) revenue
       FROM appointments a WHERE a.date BETWEEN ? AND ? AND a.status != 'cancelled' GROUP BY type`
    )
    .all(from, to)
    .map((r) => ({ ...r, revenue: money(r.revenue) }));

  const couponUsage = db
    .prepare(
      `SELECT cp.code, COUNT(*) uses, COALESCE(SUM(a.discount_cents), 0) discount
       FROM appointments a JOIN coupons cp ON cp.id = a.coupon_id
       WHERE a.date BETWEEN ? AND ? GROUP BY cp.id ORDER BY uses DESC`
    )
    .all(from, to)
    .map((r) => ({ ...r, discount: money(r.discount) }));

  res.json({
    range: { from, to },
    totals: {
      bookings: totals.bookings || 0,
      revenue: money(totals.revenue),
      collected: money(totals.collected),
      discounts: money(totals.discounts),
      cancelled: totals.cancelled || 0,
      completed: totals.completed || 0,
      no_shows: totals.no_shows || 0,
      cancellation_rate: totals.bookings ? Math.round((totals.cancelled / totals.bookings) * 100) : 0,
      avg_ticket: totals.bookings ? money(Math.round(totals.revenue / totals.bookings)) : 0,
    },
    byDay,
    byService,
    byStaff,
    byPayment,
    byHour,
    newVsReturning,
    couponUsage,
  });
});

// ---------------------------------------------------------------- settings
router.get('/settings', (_req, res) => {
  res.json({ settings: getSettings(), capabilities: capabilities() });
});

// Branding image keys are managed only by the upload endpoints below, so a stale
// settings form can never overwrite them (or point them at an arbitrary URL).
const ASSET_KEYS = ['logo_url', 'hero_image_url', 'gallery_json'];

router.put('/settings', (req, res) => {
  const patch = { ...(req.body || {}) };
  for (const k of ASSET_KEYS) delete patch[k];
  // Online card payment stays off until a real gateway is integrated (Stage 3).
  patch.allow_card = 0;
  res.json({ settings: setSettings(patch) });
});

const GALLERY_MAX = 8;
const readGallery = () => parseGallery(getSettings().gallery_json);

/** Upload a site image. slot = logo | hero | gallery. */
router.post('/site-image', (req, res) => {
  const slot = String(req.body?.slot || '');
  if (!['logo', 'hero', 'gallery'].includes(slot)) return fail(400, 'Unknown image slot');
  if (slot === 'gallery' && readGallery().length >= GALLERY_MAX) return fail(400, `Gallery is full (max ${GALLERY_MAX} photos)`);
  const url = saveImage({
    folder: 'site',
    prefix: slot,
    dataUrl: req.body?.image,
    maxBytes: slot === 'logo' ? 500 * 1024 : 1200 * 1024,
  });
  if (slot === 'gallery') {
    setSettings({ gallery_json: JSON.stringify([...readGallery(), url]) });
  } else {
    const key = slot === 'logo' ? 'logo_url' : 'hero_image_url';
    removeImage(getSettings()[key]);
    setSettings({ [key]: url });
  }
  res.json({ settings: getSettings() });
});

/** Remove a site image. For gallery pass the url to remove. */
router.delete('/site-image', (req, res) => {
  const slot = String(req.body?.slot || req.query.slot || '');
  if (slot === 'gallery') {
    const url = String(req.body?.url || req.query.url || '');
    const list = readGallery();
    if (list.includes(url)) {
      setSettings({ gallery_json: JSON.stringify(list.filter((u) => u !== url)) });
      removeImage(url);
    }
  } else if (slot === 'logo' || slot === 'hero') {
    const key = slot === 'logo' ? 'logo_url' : 'hero_image_url';
    removeImage(getSettings()[key]);
    setSettings({ [key]: '' });
  } else {
    return fail(400, 'Unknown image slot');
  }
  res.json({ settings: getSettings() });
});

export default router;
