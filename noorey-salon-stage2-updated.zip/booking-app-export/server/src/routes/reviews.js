import express from 'express';
import { db } from '../db/index.js';
import { asyncRoute, fail } from '../middleware/http.js';
import { requireAuth, requireAdmin } from '../middleware/auth.js';

const router = express.Router();

function refreshStaffRating(staffId) {
  if (!staffId) return;
  const row = db.prepare('SELECT AVG(rating) avg FROM reviews WHERE staff_id = ? AND is_published = 1').get(staffId);
  db.prepare('UPDATE staff SET rating = ? WHERE id = ?').run(row.avg ? Math.round(row.avg * 10) / 10 : 0, staffId);
}

const SELECT_REVIEWS = `
  SELECT r.*, u.name customer_name, u.avatar_url customer_avatar, s.name service_name
  FROM reviews r
  JOIN users u ON u.id = r.customer_id
  JOIN services s ON s.id = r.service_id
`;

router.get('/', (req, res) => {
  const { serviceId, staffId, all } = req.query;
  const clauses = [];
  const params = [];
  if (serviceId) { clauses.push('r.service_id = ?'); params.push(Number(serviceId)); }
  if (staffId) { clauses.push('r.staff_id = ?'); params.push(Number(staffId)); }
  if (all !== '1' || req.user?.role !== 'admin') clauses.push('r.is_published = 1');
  const where = clauses.length ? `WHERE ${clauses.join(' AND ')}` : '';
  res.json({ reviews: db.prepare(`${SELECT_REVIEWS} ${where} ORDER BY r.created_at DESC LIMIT 100`).all(...params) });
});

router.get('/mine', requireAuth, (req, res) => {
  res.json({
    reviews: db
      .prepare(`${SELECT_REVIEWS} WHERE r.customer_id = ? ORDER BY r.created_at DESC`)
      .all(req.user.id),
  });
});

router.post(
  '/',
  requireAuth,
  asyncRoute(async (req, res) => {
    const { appointmentId, rating, comment } = req.body || {};
    const appt = db
      .prepare("SELECT * FROM appointments WHERE id = ? AND customer_id = ? AND status IN ('completed','confirmed')")
      .get(appointmentId, req.user.id);
    if (!appt) return fail(404, 'You can only review your own finished appointments');
    const existing = db.prepare('SELECT id FROM reviews WHERE appointment_id = ?').get(appointmentId);
    if (existing) return fail(409, 'You already reviewed this appointment');
    const r = Number(rating);
    if (!r || r < 1 || r > 5) return fail(400, 'Rating must be between 1 and 5');

    const info = db
      .prepare('INSERT INTO reviews (appointment_id, customer_id, staff_id, service_id, rating, comment) VALUES (?, ?, ?, ?, ?, ?)')
      .run(appt.id, req.user.id, appt.staff_id, appt.service_id, r, comment || null);
    refreshStaffRating(appt.staff_id);
    res.status(201).json({ review: db.prepare(`${SELECT_REVIEWS} WHERE r.id = ?`).get(info.lastInsertRowid) });
  })
);

router.put('/:id/reply', requireAdmin, (req, res) => {
  const row = db.prepare('SELECT * FROM reviews WHERE id = ?').get(req.params.id);
  if (!row) return fail(404, 'Review not found');
  db.prepare('UPDATE reviews SET reply = ? WHERE id = ?').run(req.body?.reply || null, row.id);
  res.json({ review: db.prepare(`${SELECT_REVIEWS} WHERE r.id = ?`).get(row.id) });
});

router.patch('/:id/publish', requireAdmin, (req, res) => {
  db.prepare('UPDATE reviews SET is_published = ? WHERE id = ?').run(req.body?.is_published ? 1 : 0, req.params.id);
  const row = db.prepare('SELECT * FROM reviews WHERE id = ?').get(req.params.id);
  refreshStaffRating(row?.staff_id);
  res.json({ ok: true });
});

router.delete('/:id', requireAdmin, (req, res) => {
  const row = db.prepare('SELECT * FROM reviews WHERE id = ?').get(req.params.id);
  db.prepare('DELETE FROM reviews WHERE id = ?').run(req.params.id);
  refreshStaffRating(row?.staff_id);
  res.json({ ok: true });
});

export default router;
