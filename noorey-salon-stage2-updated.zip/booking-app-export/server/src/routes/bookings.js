import express from 'express';
import { db } from '../db/index.js';
import { asyncRoute, fail, HttpError } from '../middleware/http.js';
import { requireAuth } from '../middleware/auth.js';
import {
  createAppointment,
  rescheduleAppointment,
  cancelAppointment,
  getAppointment,
  listAppointments,
} from '../lib/bookings.js';
import { chargeCard } from '../lib/payments.js';
import { priceBooking, evaluateCoupon } from '../lib/pricing.js';
import { getSettings } from '../db/index.js';
import { todayStr, nowMinutes, dateToIndex } from '../lib/time.js';
import { notifyAppointment } from '../lib/notify.js';

const router = express.Router();
router.use(requireAuth);

const ownsOrAdmin = (req, appt) => req.user.role === 'admin' || appt?.customer_id === req.user.id;

router.get('/mine', (req, res) => {
  const scope = req.query.scope || 'upcoming';
  const today = todayStr();
  const now = nowMinutes();
  let where = 'WHERE a.customer_id = ?';
  const params = [req.user.id];
  if (scope === 'upcoming') {
    where += " AND a.status IN ('pending','confirmed') AND (a.date > ? OR (a.date = ? AND a.end_min >= ?))";
    params.push(today, today, now);
  } else if (scope === 'past') {
    where += " AND (a.status IN ('completed','cancelled','no_show') OR a.date < ? OR (a.date = ? AND a.end_min < ?))";
    params.push(today, today, now);
  }
  res.json({ bookings: listAppointments({ where, params, order: scope === 'past' ? 'a.date DESC, a.start_min DESC' : 'a.date ASC, a.start_min ASC' }) });
});

router.get('/:id', (req, res) => {
  const appt = getAppointment(req.params.id);
  if (!appt) return fail(404, 'Booking not found');
  if (!ownsOrAdmin(req, appt)) return fail(403, 'Not your booking');
  res.json({ booking: appt });
});

/** Price preview including coupon, before the customer commits. */
router.post('/quote', (req, res) => {
  const { serviceId, couponCode } = req.body || {};
  const service = db.prepare('SELECT * FROM services WHERE id = ?').get(serviceId);
  if (!service) return fail(404, 'Service not found');
  const settings = getSettings();
  const pricing = priceBooking({ service, couponCode, settings });
  const coupon = couponCode
    ? evaluateCoupon(couponCode, { serviceId, amountCents: pricing.price_cents })
    : null;
  res.json({
    ...pricing,
    coupon: coupon?.ok ? { code: coupon.coupon.code, discount_cents: coupon.discount_cents } : null,
    coupon_error: coupon && !coupon.ok ? coupon.error : null,
    deposit_percent: Number(settings.deposit_percent || 0),
    currency: settings.currency,
    currency_symbol: settings.currency_symbol,
  });
});

router.post(
  '/',
  asyncRoute(async (req, res) => {
    const b = req.body || {};
    if (!b.serviceId || !b.date || b.startMin === undefined) return fail(400, 'Service, date and time are required');
    const appt = await createAppointment({
      customerId: req.user.id,
      serviceId: Number(b.serviceId),
      staffId: b.staffId ? Number(b.staffId) : null,
      date: String(b.date),
      startMin: Number(b.startMin),
      paymentMethod: b.paymentMethod === 'card' ? 'card' : 'cash',
      couponCode: b.couponCode || null,
      notes: b.notes || null,
    });
    res.status(201).json({ booking: appt });
  })
);

router.post(
  '/:id/reschedule',
  asyncRoute(async (req, res) => {
    const appt = getAppointment(req.params.id);
    if (!appt) return fail(404, 'Booking not found');
    if (!ownsOrAdmin(req, appt)) return fail(403, 'Not your booking');
    const { date, startMin, staffId } = req.body || {};
    if (!date || startMin === undefined) return fail(400, 'Pick a new date and time');
    const updated = await rescheduleAppointment(appt.id, {
      date: String(date),
      startMin: Number(startMin),
      staffId: staffId ? Number(staffId) : null,
      isAdmin: req.user.role === 'admin',
    });
    res.json({ booking: updated });
  })
);

router.post(
  '/:id/cancel',
  asyncRoute(async (req, res) => {
    const appt = getAppointment(req.params.id);
    if (!appt) return fail(404, 'Booking not found');
    if (!ownsOrAdmin(req, appt)) return fail(403, 'Not your booking');
    const settings = getSettings();
    const minsAway = (dateToIndex(appt.date) - dateToIndex(todayStr())) * 1440 + appt.start_min - nowMinutes();
    if (req.user.role !== 'admin' && minsAway < Number(settings.cancellation_hours) * 60) {
      return fail(400, `Bookings can only be cancelled at least ${settings.cancellation_hours}h in advance. Please contact us.`);
    }
    const updated = await cancelAppointment(appt.id, {
      reason: req.body?.reason || null,
      refundPayment: req.body?.refund !== false,
    });
    res.json({ booking: updated });
  })
);

/** Pay a remaining balance (or switch from cash to card) for an existing booking. */
router.post(
  '/:id/pay',
  asyncRoute(async (req, res) => {
    const appt = getAppointment(req.params.id);
    if (!appt) return fail(404, 'Booking not found');
    if (!ownsOrAdmin(req, appt)) return fail(403, 'Not your booking');
    const { method = 'card' } = req.body || {};
    const remaining = Math.max(0, appt.total_cents - appt.paid_cents);

    if (method === 'cash') {
      db.prepare("UPDATE appointments SET payment_method = 'cash', updated_at = datetime('now') WHERE id = ?").run(appt.id);
      return res.json({ booking: getAppointment(appt.id) });
    }
    if (remaining <= 0) return fail(400, 'Nothing left to pay');

    const settings = getSettings();
    const charge = await chargeCard({
      amountCents: remaining,
      currency: settings.currency,
      description: `${appt.service_name} · ${appt.code}`,
      metadata: { appointment_id: String(appt.id) },
    });
    if (!charge.ok) return fail(402, charge.error || 'Payment failed');

    const paid = appt.paid_cents + remaining;
    db.prepare('UPDATE appointments SET paid_cents = ?, payment_ref = ?, payment_method = ?, payment_status = ?, updated_at = datetime(\'now\') WHERE id = ?')
      .run(paid, charge.id, 'card', paid >= appt.total_cents ? 'paid' : 'unpaid', appt.id);
    const updated = getAppointment(appt.id);
    await notifyAppointment('payment', updated);
    res.json({ booking: updated });
  })
);

export default router;
