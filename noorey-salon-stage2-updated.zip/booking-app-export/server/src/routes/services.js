import express from 'express';
import { db } from '../db/index.js';
import { asyncRoute, fail } from '../middleware/http.js';
import { requireAdmin } from '../middleware/auth.js';
import { staffForService } from '../lib/availability.js';
import { saveImage, removeImage } from '../lib/images.js';

const router = express.Router();

const withExtras = (rows) =>
  rows.map((s) => {
    const staff = staffForService(s.id, false).map((st) => ({ id: st.id, name: st.name, color: st.color, title: st.title, avatar_url: st.avatar_url }));
    const agg = db
      .prepare('SELECT COUNT(*) count, AVG(rating) avg FROM reviews WHERE service_id = ? AND is_published = 1')
      .get(s.id);
    return {
      ...s,
      staff,
      review_count: agg.count || 0,
      rating: agg.avg ? Math.round(agg.avg * 10) / 10 : 0,
    };
  });

router.get('/', (req, res) => {
  const includeInactive = req.user?.role === 'admin' && req.query.all === '1';
  const rows = db
    .prepare(`SELECT * FROM services ${includeInactive ? '' : 'WHERE is_active = 1'} ORDER BY sort_order, category, name`)
    .all();
  res.json({ services: withExtras(rows) });
});

router.get('/:id', (req, res) => {
  const row = db.prepare('SELECT * FROM services WHERE id = ?').get(req.params.id);
  if (!row) return fail(404, 'Service not found');
  const [service] = withExtras([row]);
  const reviews = db
    .prepare(
      `SELECT r.*, u.name customer_name, u.avatar_url customer_avatar
       FROM reviews r JOIN users u ON u.id = r.customer_id
       WHERE r.service_id = ? AND r.is_published = 1 ORDER BY r.created_at DESC LIMIT 20`
    )
    .all(row.id);
  res.json({ service, reviews });
});

router.post('/', requireAdmin, (req, res) => {
  const b = req.body || {};
  if (!b.name) return fail(400, 'Service name is required');
  const info = db
    .prepare(
      `INSERT INTO services (name, category, description, duration_min, price_cents, buffer_min, deposit_cents, color, image_url, is_active, sort_order)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    )
    .run(
      b.name,
      b.category || 'General',
      b.description || '',
      Number(b.duration_min) || 60,
      Number(b.price_cents) || 0,
      Number(b.buffer_min) || 0,
      Number(b.deposit_cents) || 0,
      b.color || '#b8935a',
      null,
      b.is_active === false ? 0 : 1,
      Number(b.sort_order) || 0
    );
  res.status(201).json({ service: db.prepare('SELECT * FROM services WHERE id = ?').get(info.lastInsertRowid) });
});

router.put('/:id', requireAdmin, (req, res) => {
  const b = req.body || {};
  const existing = db.prepare('SELECT * FROM services WHERE id = ?').get(req.params.id);
  if (!existing) return fail(404, 'Service not found');
  db.prepare(
    `UPDATE services SET name = ?, category = ?, description = ?, duration_min = ?, price_cents = ?,
     buffer_min = ?, deposit_cents = ?, color = ?, image_url = ?, is_active = ?, sort_order = ?
     WHERE id = ?`
  ).run(
    b.name ?? existing.name,
    b.category ?? existing.category,
    b.description ?? existing.description,
    Number(b.duration_min ?? existing.duration_min),
    Number(b.price_cents ?? existing.price_cents),
    Number(b.buffer_min ?? existing.buffer_min),
    Number(b.deposit_cents ?? existing.deposit_cents),
    b.color ?? existing.color,
    existing.image_url,
    b.is_active === undefined ? existing.is_active : b.is_active ? 1 : 0,
    Number(b.sort_order ?? existing.sort_order),
    existing.id
  );
  if (Array.isArray(b.staffIds)) {
    db.prepare('DELETE FROM service_staff WHERE service_id = ?').run(existing.id);
    const link = db.prepare('INSERT OR IGNORE INTO service_staff (service_id, staff_id) VALUES (?, ?)');
    for (const sid of b.staffIds) link.run(existing.id, Number(sid));
  }
  res.json({ service: db.prepare('SELECT * FROM services WHERE id = ?').get(existing.id) });
});

router.delete('/:id', requireAdmin, (req, res) => {
  const row = db.prepare('SELECT * FROM services WHERE id = ?').get(req.params.id);
  if (!row) return fail(404, 'Service not found');
  db.prepare('DELETE FROM services WHERE id = ?').run(row.id);
  removeImage(row.image_url);
  res.json({ ok: true });
});

/** Admin-only: upload / replace the service photo. */
router.post('/:id/image', requireAdmin, (req, res) => {
  const row = db.prepare('SELECT * FROM services WHERE id = ?').get(req.params.id);
  if (!row) return fail(404, 'Service not found');
  const url = saveImage({ folder: 'services', prefix: `s${row.id}`, dataUrl: req.body?.image, maxBytes: 900 * 1024 });
  db.prepare('UPDATE services SET image_url = ? WHERE id = ?').run(url, row.id);
  removeImage(row.image_url);
  res.json({ service: db.prepare('SELECT * FROM services WHERE id = ?').get(row.id) });
});

router.delete('/:id/image', requireAdmin, (req, res) => {
  const row = db.prepare('SELECT * FROM services WHERE id = ?').get(req.params.id);
  if (!row) return fail(404, 'Service not found');
  db.prepare('UPDATE services SET image_url = NULL WHERE id = ?').run(row.id);
  removeImage(row.image_url);
  res.json({ service: db.prepare('SELECT * FROM services WHERE id = ?').get(row.id) });
});

export default router;
