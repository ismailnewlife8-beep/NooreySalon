import express from 'express';
import { getSettings, capabilities } from '../db/index.js';
import { parseGallery } from '../lib/images.js';

const router = express.Router();

/** Public bootstrap: brand + which integrations are live. */
router.get('/', (_req, res) => {
  const s = getSettings();
  res.json({
    business: {
      business_name: s.business_name,
      business_type: s.business_type,
      tagline: s.tagline,
      currency: s.currency,
      currency_symbol: s.currency_symbol,
      timezone: s.timezone,
      phone: s.phone,
      email: s.email,
      address: s.address,
      website: s.website,
      landline: s.landline,
      whatsapp: s.whatsapp,
      instagram: s.instagram,
      hours_text: s.hours_text,
      logo_url: s.logo_url,
      hero_image_url: s.hero_image_url,
      gallery: parseGallery(s.gallery_json),
    },
    policy: {
      min_lead_hours: s.min_lead_hours,
      max_advance_days: s.max_advance_days,
      cancellation_hours: s.cancellation_hours,
      deposit_percent: s.deposit_percent,
      tax_percent: s.tax_percent,
      allow_card: 0, // online card payment is disabled until a real gateway is integrated
      allow_cash: s.allow_cash,
      slot_granularity_min: s.slot_granularity_min,
      require_approval: s.require_approval,
    },
    capabilities: capabilities(),
  });
});

export default router;
