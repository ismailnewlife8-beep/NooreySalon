import express from 'express';
import { db } from '../db/index.js';
import { asyncRoute, fail } from '../middleware/http.js';
import { evaluateCoupon } from '../lib/pricing.js';
import { getSettings } from '../db/index.js';

const router = express.Router();

router.post('/validate', (req, res) => {
  const { code, serviceId, amountCents } = req.body || {};
  const res2 = evaluateCoupon(code, { serviceId, amountCents });
  if (!res2.ok) return fail(400, res2.error);
  res.json({
    ok: true,
    code: res2.coupon.code,
    type: res2.coupon.type,
    value: res2.coupon.value,
    description: res2.coupon.description,
    discount_cents: res2.discount_cents,
    currency_symbol: getSettings().currency_symbol,
  });
});

export default router;
