#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"

echo "============================================"
echo "  Noorey Salon - Appointment Booking App"
echo "============================================"
echo

if ! command -v node >/dev/null 2>&1; then
  echo "[ERROR] Node.js nahi mila."
  echo "Pehle Node.js install karein: https://nodejs.org  (LTS version)"
  exit 1
fi

echo "Node.js mil gaya: $(node -v)"
echo

if [ ! -d "server/node_modules" ]; then
  echo "[1/3] Dependencies install ho rahi hain... (2 se 4 minute)"
  npm install
else
  echo "[1/3] Dependencies pehle se maujood hain. Skip."
fi

if [ ! -f "server/data/booking.db" ]; then
  echo "[2/3] Demo data bana rahe hain..."
  npm run seed
else
  echo "[2/3] Database pehle se maujood hai. Skip."
fi

echo "[3/3] App start ho raha hai..."
echo
echo "  Customer app : http://localhost:5173"
echo "  Admin panel  : http://localhost:5173/admin"
echo
echo "  Band karne ke liye: Ctrl+C dabayein"
echo "============================================"
echo

(sleep 6; (command -v open >/dev/null && open http://localhost:5173) || (command -v xdg-open >/dev/null && xdg-open http://localhost:5173) || true) &

npm run dev
