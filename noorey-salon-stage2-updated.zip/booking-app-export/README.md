# Appointment Booking App

A full-stack appointment booking system with a customer site, a powerful admin
panel, real-time availability, payments, coupons, reminders and reports.
Designed for a single business with multiple staff and a global timezone.

> Tech: **React 18 + Vite** (frontend), **Node + Express + SQLite** (backend),
> **Tailwind-style design tokens** with hand-written CSS, **Inter** typography,
> **Recharts** for analytics, full **dark mode**, fully responsive.

---

## ✨ Features

### Customer
- Sign up & sign in by **email + password**, **phone OTP**, or **Google**
- Browse services with price, duration, description and rating
- Pick date and time from **real-time availability** (per staff, per slot)
- Apply coupon codes at checkout
- Pay by **card** (Stripe) or **cash on arrival**
- View upcoming and past bookings; reschedule, cancel, pay balance
- Leave 5-star reviews on completed visits
- Edit profile, notification preferences and password
- Email + SMS reminders (24h and 2h before each visit)

### Admin / Provider
- Dashboard with today's and upcoming bookings, 14-day revenue chart,
  utilisation, top services, top specialists, new customers
- **Day / Week / Month** calendar with drag-free time grid
- Walk-in / phone bookings with auto-fill customer
- Full **service CRUD** with prices, durations, buffers, colours, specialists
- **Staff CRUD** with individual working hours, breaks and time-off
- **Customer management** with history, notes, internal messaging
- **Coupons** (percent / fixed, min spend, max discount, usage limits, dates)
- **Reports**: revenue by day, service, specialist, hour, payment mix,
  new vs returning, coupon usage, cancellation rate, **CSV export**
- **Notifications**: send emails / SMS to segments (all / upcoming / VIP / new)
- **Settings**: business profile, currency, tax, deposit, booking rules,
  reminders, integration status

---

## 🧱 Tech

- **Frontend:** React 18, react-router-dom, Vite, recharts, lucide-react,
  date-fns, vanilla CSS with design tokens (no framework runtime cost)
- **Backend:** Node 22, Express 4, better-sqlite3, jsonwebtoken, bcryptjs,
  zod, node-cron, Stripe, Twilio, Nodemailer, Google Auth Library
- **DB:** single-file SQLite at `server/data/booking.db` (WAL mode)

---

## 🚀 Quick start

```bash
# install everything (root + server + client)
npm install
npm --prefix server install
npm --prefix client install

# load demo data (admin + 5 staff + 5 customers + 10 services + bookings)
npm --prefix server run seed      # or `reset` to wipe and reseed

# run server + client together
npm run dev
# → API:    http://localhost:4000
# → Web:    http://localhost:5173
```

The Vite dev server proxies `/api/*` to the Express API. The Express server
also serves the built SPA on port 4000 for production.

### Build for production

```bash
npm run build           # builds the client into client/dist
npm start               # starts the API which also serves /dist
```

---

## 🔑 Demo accounts

| Role     | Email                 | Password       |
| -------- | --------------------- | -------------- |
| Admin    | admin@nooreysalon.com       | Admin@123      |
| Staff    | ayesha@nooreysalon.com      | Staff@123      |
| Customer | fatima@example.com      | Customer@123   |

> Phone OTP works in **dev mode** even without a provider: the code is
> shown on the login screen and in the server console. Add Twilio keys to
> `server/.env` to send real SMS.

---

## ⚙️ Real integrations (drop your keys into `server/.env`)

| Concern      | Env var(s)                                | What happens without it |
| ------------ | ----------------------------------------- | ----------------------- |
| Email        | `SMTP_HOST` / `SENDGRID_API_KEY`          | Logs to `server/data/outbox.log` and console |
| SMS / OTP    | `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, `TWILIO_FROM` | Same — dev console outbox |
| Card payments| `STRIPE_SECRET_KEY`                        | Test gateway: any card works, `…0002` declines |
| Google sign-in| `GOOGLE_CLIENT_ID`                        | Sign-in button is hidden |
| Time zone    | `APP_TIMEZONE` (default `Asia/Karachi`)  | Used for all dates/reminders |

The full env file is documented in [`server/.env.example`](server/.env.example).

---

## 🧭 How it works

### Real-time availability
For every service the engine asks: "for each qualified staff member, when
are they free on that day?" — taking into account:
1. **Business default hours** (overridden by individual staff hours)
2. **Breaks** (per staff or business default)
3. **Holidays / time off** (per staff or business)
4. **Existing appointments** (status pending / confirmed / completed)
5. **Buffer** between bookings (per service or default)
6. **Lead time** and **booking window**

When a customer picks "Any available" the server auto-assigns the least-loaded
free specialist. The `/api/availability/range` endpoint powers the dot
indicators on the date calendar.

### Reminders
A `node-cron` job runs every 10 minutes and dispatches 24h and 2h reminders
for bookings that haven't been notified yet (flags `reminded_24h`, `reminded_2h`).

### Coupons
`percent` (e.g. 15% off) or `fixed` (e.g. $20 off) with optional min spend,
max discount, usage limits, valid date range. Validated live during checkout
and re-validated server-side before persisting.

### Money
All amounts are stored as integer cents (`price_cents`, `paid_cents`…).
Currency, symbol, tax % and deposit % are set in **Settings**.

---

## 📁 Project structure

```
booking-app/
├── server/
│   ├── .env.example
│   ├── data/               # SQLite db + outbox log
│   └── src/
│       ├── db/             # schema, connection, seed
│       ├── lib/            # availability, bookings, pricing, notify, etc.
│       ├── middleware/     # auth, http helpers
│       ├── routes/         # auth, services, staff, bookings, admin…
│       ├── jobs/           # reminders cron
│       └── index.js
└── client/
    ├── index.html
    ├── vite.config.js
    └── src/
        ├── components/     # Layout, AdminLayout, ui kit, charts…
        ├── context/        # AppContext (auth, meta, theme, toasts)
        ├── lib/            # api, format
        ├── pages/
        │   ├── customer/   # Home, Services, Book, MyBookings…
        │   └── admin/      # Dashboard, Calendar, Bookings, Services…
        └── styles/global.css
```

---

## 🛠 Useful scripts

| Command                     | What it does |
| --------------------------- | ------------ |
| `npm run dev`               | Start API (`:4000`) and Vite (`:5173`) concurrently |
| `npm run build`             | Build the React client into `client/dist` |
| `npm start`                 | Run the API in production mode (serves the built SPA) |
| `npm --prefix server run seed`   | Insert demo data (idempotent — skip if not empty) |
| `npm --prefix server run reset`  | Wipe everything and reseed demo data |

---

## 🔐 Security notes

- Passwords are hashed with **bcrypt** (cost 10)
- All write endpoints are protected with **JWT** (`Authorization: Bearer …`)
- Admin endpoints additionally check `role === 'admin'`
- Booking mutations verify the caller owns the booking (or is admin)
- CORS defaults to the Vite origin, set `CLIENT_ORIGIN` in production
- CSP is configured to allow Google Identity Services and Stripe.js only

---

## License

MIT — built as a reference product. Replace the seed business identity
("Noorey Salon") via **Admin → Settings**.
