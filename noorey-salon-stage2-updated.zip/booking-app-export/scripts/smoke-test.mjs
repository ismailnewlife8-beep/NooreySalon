// API smoke test. Start the server first (npm start or npm run dev), then run:
//   node scripts/smoke-test.mjs            (default http://localhost:4000)
//   API=http://localhost:4000 node scripts/smoke-test.mjs
// Needs Node 18+ (built-in fetch). It creates one test booking and cancels it again.
const API = process.env.API || 'http://localhost:4000';
// 1x1 PNG
const PNG = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==';
const FAKE = `data:image/png;base64,${Buffer.from('<html><script>alert(1)</script></html>').toString('base64')}`;

let failed = 0;
const check = (name, ok, extra = '') => {
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${extra ? `  (${extra})` : ''}`);
  if (!ok) failed += 1;
};
const call = async (path, { method = 'GET', body, token } = {}) => {
  const res = await fetch(`${API}${path}`, {
    method,
    headers: { ...(body ? { 'Content-Type': 'application/json' } : {}), ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  const text = await res.text();
  let json = null;
  try { json = JSON.parse(text); } catch { /* not json */ }
  return { status: res.status, json, res };
};
const login = async (email, password) => (await call('/api/auth/login', { method: 'POST', body: { email, password } })).json?.token;

const health = await call('/api/health');
check('health', health.status === 200);

const meta = await call('/api/meta');
check('meta has business + gallery array', meta.status === 200 && Array.isArray(meta.json?.business?.gallery));
check('card payment reported off', meta.json?.policy?.allow_card === 0 && meta.json?.capabilities?.card === false);

const admin = await login('admin@nooreysalon.com', 'Admin@123');
const customer = await login('fatima@example.com', 'Customer@123');
check('admin login', !!admin);
check('customer login', !!customer);

const services = (await call('/api/services')).json?.services || [];
const staff = (await call('/api/staff')).json?.staff || [];
check('18 services seeded', services.length === 18, `found ${services.length}`);
const svc = services[0];
const member = staff[0];

// ---- service photo upload
check('customer cannot upload service photo', (await call(`/api/services/${svc.id}/image`, { method: 'POST', token: customer, body: { image: PNG } })).status === 403);
check('anonymous cannot upload service photo', (await call(`/api/services/${svc.id}/image`, { method: 'POST', body: { image: PNG } })).status === 401);
check('fake image rejected', (await call(`/api/services/${svc.id}/image`, { method: 'POST', token: admin, body: { image: FAKE } })).status === 400);
const up = await call(`/api/services/${svc.id}/image`, { method: 'POST', token: admin, body: { image: PNG } });
check('admin uploads service photo', up.status === 200 && /^\/uploads\/services\//.test(up.json?.service?.image_url || ''), up.json?.service?.image_url);
if (up.json?.service?.image_url) {
  const img = await fetch(`${API}${up.json.service.image_url}`);
  check('uploaded photo is served as an image', img.status === 200 && /^image\//.test(img.headers.get('content-type') || ''));
}
const afterEdit = await call(`/api/services/${svc.id}`, { method: 'PUT', token: admin, body: { name: svc.name, image_url: 'http://evil.example/x.png' } });
check('PUT cannot set an arbitrary image_url', afterEdit.json?.service?.image_url === up.json?.service?.image_url);
check('admin removes service photo', (await call(`/api/services/${svc.id}/image`, { method: 'DELETE', token: admin })).json?.service?.image_url === null);

// (staff photo upload is disabled)
check('staff photo upload endpoint is off', (await call(`/api/staff/${member.id}/image`, { method: 'POST', token: admin, body: { image: PNG } })).status === 404);

// ---- site images
const logo = await call('/api/admin/site-image', { method: 'POST', token: admin, body: { slot: 'logo', image: PNG } });
check('admin uploads logo', logo.status === 200 && /^\/uploads\/site\//.test(logo.json?.settings?.logo_url || ''));
const gal = await call('/api/admin/site-image', { method: 'POST', token: admin, body: { slot: 'gallery', image: PNG } });
const galUrl = JSON.parse(gal.json?.settings?.gallery_json || '[]')[0];
check('admin adds gallery photo', !!galUrl);
const meta2 = await call('/api/meta');
check('meta exposes logo + gallery', !!meta2.json?.business?.logo_url && meta2.json?.business?.gallery?.length >= 1);
const keep = await call('/api/admin/settings', { method: 'PUT', token: admin, body: { business_name: 'Noorey Salon', logo_url: '/uploads/site/hacked.png', allow_card: 1 } });
check('settings PUT cannot overwrite image keys or enable card', keep.json?.settings?.logo_url === logo.json?.settings?.logo_url && keep.json?.settings?.allow_card === 0);
check('customer cannot manage site images', (await call('/api/admin/site-image', { method: 'POST', token: customer, body: { slot: 'logo', image: PNG } })).status === 403);
await call('/api/admin/site-image', { method: 'DELETE', token: admin, body: { slot: 'logo' } });
await call('/api/admin/site-image', { method: 'DELETE', token: admin, body: { slot: 'gallery', url: galUrl } });

// ---- booking: card refused, pay-at-salon works
const addDays = (n) => new Date(Date.now() + n * 86400000).toISOString().slice(0, 10);
let slot = null;
let date = null;
for (let i = 1; i <= 14 && !slot; i += 1) {
  const av = (await call(`/api/availability?serviceId=${svc.id}&date=${addDays(i)}`)).json;
  const s = av?.slots?.find((x) => x.available);
  if (s) { slot = s; date = addDays(i); }
}
check('found a free slot', !!slot);
if (slot) {
  const card = await call('/api/bookings', { method: 'POST', token: customer, body: { serviceId: svc.id, date, startMin: slot.start, paymentMethod: 'card', card: { number: '4242424242424242' } } });
  check('card booking refused', card.status === 400, card.json?.error);
  const ok = await call('/api/bookings', { method: 'POST', token: customer, body: { serviceId: svc.id, date, startMin: slot.start, paymentMethod: 'cash' } });
  check('pay-at-salon booking created', ok.status === 201 && ok.json?.booking?.payment_status === 'unpaid', ok.json?.booking?.code);
  if (ok.json?.booking?.id) {
    const mine = await call('/api/bookings/mine', { token: customer });
    check('booking listed in My Bookings', mine.json?.bookings?.some((b) => b.id === ok.json.booking.id));
    await call(`/api/bookings/${ok.json.booking.id}/cancel`, { method: 'POST', token: admin, body: { reason: 'smoke test' } });
  }
}

console.log(failed ? `\n${failed} check(s) FAILED` : '\nAll checks passed');
process.exit(failed ? 1 : 0);
