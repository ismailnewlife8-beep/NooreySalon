// Takes desktop (1280px) and mobile (390px) screenshots of the main pages.
// Setup once:   npm install --no-save playwright && npx playwright install chromium
// Then (with the app running on http://localhost:5173 or :4000):
//   node scripts/screenshots.mjs
//   BASE=http://localhost:4000 node scripts/screenshots.mjs
// Output goes to ./screenshots/
import { chromium } from 'playwright';
import fs from 'node:fs';

const BASE = process.env.BASE || 'http://localhost:5173';
const OUT = 'screenshots';
fs.mkdirSync(OUT, { recursive: true });

const VIEWPORTS = [
  { name: 'desktop', width: 1280, height: 800 },
  { name: 'mobile', width: 390, height: 844, isMobile: true, deviceScaleFactor: 2 },
];

async function login(page, email, password) {
  await page.goto(`${BASE}/login`);
  await page.fill('input[type="email"]', email);
  await page.fill('input[type="password"]', password);
  await page.keyboard.press('Enter');
  await page.waitForURL((u) => !u.pathname.startsWith('/login'), { timeout: 15000 });
}

const browser = await chromium.launch();
for (const vp of VIEWPORTS) {
  const ctx = await browser.newContext({ viewport: { width: vp.width, height: vp.height }, isMobile: vp.isMobile, deviceScaleFactor: vp.deviceScaleFactor || 1 });
  const page = await ctx.newPage();
  const shot = async (name) => {
    await page.waitForTimeout(700);
    await page.screenshot({ path: `${OUT}/${vp.name}-${name}.png`, fullPage: true });
    console.log('saved', `${OUT}/${vp.name}-${name}.png`);
  };

  // public pages
  for (const [name, path] of [['home', '/'], ['services', '/services'], ['service-detail', '/services/1'], ['book-service', '/book'], ['book-time', '/book/1'], ['login', '/login']]) {
    await page.goto(`${BASE}${path}`);
    await page.waitForLoadState('networkidle');
    await shot(name);
  }

  // customer pages
  await login(page, 'fatima@example.com', 'Customer@123');
  for (const [name, path] of [['my-bookings', '/bookings'], ['profile', '/profile']]) {
    await page.goto(`${BASE}${path}`);
    await page.waitForLoadState('networkidle');
    await shot(name);
  }
  // booking confirm step (pick the first free time, then screenshot the confirmation)
  await page.goto(`${BASE}/book/1`);
  await page.waitForSelector('.slot:not([disabled])', { timeout: 15000 }).catch(() => {});
  const slot = page.locator('.slot:not([disabled])').first();
  if (await slot.count()) {
    await slot.click();
    await shot('book-confirm');
  }

  // admin pages
  await page.evaluate(() => localStorage.removeItem('booking_token'));
  await login(page, 'admin@nooreysalon.com', 'Admin@123');
  for (const name of ['', 'calendar', 'bookings', 'services', 'staff', 'customers', 'settings']) {
    await page.goto(`${BASE}/admin${name ? `/${name}` : ''}`);
    await page.waitForLoadState('networkidle');
    await shot(`admin-${name || 'dashboard'}`);
  }
  await ctx.close();
}
await browser.close();
