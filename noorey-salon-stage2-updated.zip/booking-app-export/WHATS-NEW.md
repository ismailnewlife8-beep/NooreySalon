# Stage 2 changes

**Latest:** home hero is now an auto-sliding banner (designs 1, 2 and 4 from your mockup, 6.5 s per slide, swipe/arrows/dots, pauses on hover). Header logo is the NOOREY wordmark (client/public/brand/noorey-logo.png). Default slide photos (client/public/hero/) are small crops from your mockup; once you upload a hero photo / gallery photos in Admin > Settings > Branding they replace them in order.

**Update:** theme is now beige-first (chocolate only for text/small accents), mobile layout polished, and staff photo upload is switched OFF (staff show initials).

## Added
- **Photo upload (admin only):** Admin > Services now has a photo picker in the edit window
  (save a new service/person first, then edit to add the photo). Server checks the real file type from the bytes
  (JPG/PNG/WebP only), limits size to ~900 KB (the browser resizes big photos automatically), and old files are deleted on replace.
- **Branding (Admin > Settings > Branding & photos):** logo, home-page hero photo and a gallery of up to 8 photos.
  Until a logo is uploaded the site shows an "NS" monogram next to "Noorey Salon".
  Until gallery photos are added the home page shows elegant placeholder tiles.
- Services, staff and the booking flow show photos, with a gold-framed fallback when there is no photo.
- **Booking flow is shorter:** 3 steps (Service > Date & time > Confirm). Coming from a service page skips step 1.
  The first day with free slots opens automatically, specialist is a one-tap chip row ("Any available" by default),
  tapping a time goes straight to the confirmation. Notes and promo code are tucked away. One-tap bar on mobile.
- Theme polish on all pages (beige / espresso / gold, serif headings), responsive layouts for service detail and booking.
- `scripts/smoke-test.mjs` (API checks) and `scripts/screenshots.mjs` (Playwright, 1280px and 390px).

## Changed / fixed
- Online card payment is now blocked on the server and the card form, test-card code and card number fields were removed from the client.
  Bookings are always "pay at the salon". (Re-enable only with a real gateway in Stage 3.)
- Booking page had a hidden bug: it defaulted to "card" while the card option was hidden. Fixed.
- `image_url` / `avatar_url` can no longer be set from the edit forms or settings (only through the upload endpoints).
- Removed the "guest rating" claim from the home hero and the "verified reviews" wording. Demo reviews still come from seed data only.
- Chart colours and modal overlay now match the theme.

## Not done yet
- Logo monogram image (you are preparing it): upload it in Admin > Settings > Branding.
- Real photos of the salon (placeholders for now).
- Stage 3: real payments, real email/SMS. Stage 4: Urdu/English, hosting + domain, final testing.

---

# Noorey Salon - Stage 1 (about 30%)

Done in this version
- Rebranded: Noorey Salon, PKR (Rs), Asia/Karachi, DHA Phase 6 address, phone/email/hours, WhatsApp button, Instagram link
- 18 services in Hair / Makeup / Nails / Skin / Spa at premium PKR prices; 5 Pakistani staff; demo customers/reviews
- Beige + espresso + gold theme, serif headings, new premium home page, new footer, Privacy + Terms pages
- Profile picture upload, Forgot/Reset password, email confirmation link, duplicate email AND phone check
- Login rate limiting, OTP attempt limit, 8-character passwords, secure JWT secret
- Online card payment switched OFF (cash at salon only) because the old code never collected real money

How to run: unzip to a NEW folder, double-click start.bat (it installs and seeds). Admin: admin@nooreysalon.com / Admin@123
Staff: ayesha@nooreysalon.com / Staff@123   Customer: fatima@example.com / Customer@123

Next stages: real photos/logo, real online payment (JazzCash/Easypaisa/Stripe), real email/SMS provider,
admin photo upload for services/staff, Urdu text, hosting + domain, final polish and testing.
