# Shuru Kaise Karein (Roman Urdu Guide)

Ye app aapke laptop par locally chalegi. Internet sirf pehli baar (dependencies download karne ke liye) chahiye, uske baad offline bhi chalegi.

---

## Step 1 — Node.js install karein (ek hi baar)

1. Browser mein jayein: **https://nodejs.org**
2. Bada wala green button **"LTS"** wala download karein (version 20 ya usse upar)
3. Download hua `.msi` / `.pkg` file par double-click karein
4. **Next → Next → Next → Install** (sab default rehne dein)
5. Install complete hone ke baad **laptop restart** kar lein (safe side)

**Check kaise karein:** Terminal / Command Prompt kholein aur likhein:

```
node -v
```

Agar `v20.x.x` ya usse bada number aaye → Node.js theek se install ho gaya. ✅

> Windows: Start menu mein likhein `cmd` ya `PowerShell`
> Mac: `Cmd + Space` dabayein, likhein `Terminal`

---

## Step 2 — Project files laptop par rakhein

1. `booking-app.zip` download kar lein
2. Us par right-click → **Extract All** (Windows) ya double-click (Mac)
3. Ek folder banega: **`booking-app`** — isse **Desktop** par rakh dein (aasan rahega)

Folder kholne par aapko ye dikhega:

```
booking-app/
├── start.bat        ← Windows ke liye
├── start.sh         ← Mac / Linux ke liye
├── package.json
├── README.md
├── client/          ← frontend (React)
└── server/          ← backend (Node + SQLite)
```

---

## Step 3 — App chalayein (sabse aasan tareeqa)

### Windows users

`booking-app` folder kholein → **`start.bat`** par **double-click** karein.

Ek black window khulegi aur khud-ba-khud ye kaam karega:
1. Dependencies download karega (pehli baar 2–4 minute)
2. Demo data (services, staff, bookings) banayega
3. App start karega aur browser mein khol dega

### Mac / Linux users

Terminal kholein aur ye likhein:

```bash
cd Desktop/booking-app
chmod +x start.sh
./start.sh
```

---

## Step 4 — Browser mein khulega

| Kya | Link |
|---|---|
| Customer app (booking wala) | **http://localhost:5173** |
| Admin panel (dashboard wala) | **http://localhost:5173/admin** |

### Demo accounts (login ke liye)

| Role | Email | Password |
|---|---|---|
| Admin | `admin@nooreysalon.com` | `Admin@123` |
| Staff | `ayesha@nooreysalon.com` | `Staff@123` |
| Customer | `fatima@example.com` | `Customer@123` |

---

## Step 5 — App ko band aur dobara chalana

**Band karna:** black terminal window mein **Ctrl + C** dabayein.

**Dobara chalana:** bas `start.bat` (ya `./start.sh`) phir double-click karein — dobara install nahi hoga, 5 second mein start ho jayega.

---

## Agar koi error aaye (Troubleshooting)

### ❌ `npm install` fail ho jaye (better-sqlite3 build error)

Ye tab hota hai jab laptop mein C++ build tools nahi hote. Fix:

**Windows:** PowerShell ko **Run as Administrator** se kholein, ye chalayein, phir laptop restart:
```
npm install --global windows-build-tools
```
Ya phir Visual Studio ka **"Desktop development with C++"** install karein.

**Mac:** Terminal mein:
```
xcode-select --install
```

Phir `start.bat` dobara chalayein.

### ❌ `node -v` command nahi chala

Node.js install ke baad laptop restart kiya? Nahi kiya to restart karein. Phir bhi na chale to Node.js dobara install karein.

### ❌ Port 5173 / 4000 already in use

Koi aur app us port par chal rahi hai. Us app ko band kar dein, phir dobara try karein.

### ❌ Data galti se kharaab ho jaye

Fresh demo data wapas lane ke liye:
```
npm run reset
```

### ❌ Kuch aur kharaab ho jaye

Sab kuch zero se shuru karne ka tareeqa:
1. `booking-app` folder se `server/data` folder delete kar dein
2. `start.bat` dobara chalayein

---

## Zaroori baatein

- **Payment, SMS, Email, Google login abhi "demo mode" mein hain.** Koi bhi card number chal jayega (test ke liye). Card ka last 4 digit `0002` ho to payment fail dikhega (ye jaan-bujh kar banaya gaya hai testing ke liye).
- **Asli payment/SMS/email chahiye?** `server/.env` file kholein aur apni keys daalein (Stripe, Twilio, Gmail/SendGrid, Google). File mein har key ke saath comment likha hai. Key daalne ke baad server restart karein — code mein kuch badalne ki zaroorat nahi.
- **Data kahan save hota hai?** `server/data/booking.db` (ek hi SQLite file). Isse copy karke kahin bhi le ja sakte hain — pura backup.
- **Store ka naam, currency, services sab badal sakte hain** Admin panel → **Settings** se. Coding ki zaroorat nahi.
