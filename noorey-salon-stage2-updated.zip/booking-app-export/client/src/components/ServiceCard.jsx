import { Link } from 'react-router-dom';
import { Clock, ArrowRight, Users } from 'lucide-react';
import { money, duration } from '../lib/format';
import { Card, Badge, Media } from './ui';

export default function ServiceCard({ service, currency = 'Rs' }) {
  return (
    <Card className="service-card card-hover">
      <Link to={`/services/${service.id}`} aria-label={service.name} style={{ display: 'block' }}>
        <Media url={service.image_url} name={service.name} category={service.category} className="service-media" />
      </Link>
      <div className="service-body">
        <div className="row-between">
          <Badge tone="blue">{service.category}</Badge>
          <span className="row gap-4 text-xs text-muted">
            <Clock size={13} /> {duration(service.duration_min)}
          </span>
        </div>
        <div>
          <h4 className="service-title">
            <Link to={`/services/${service.id}`}>{service.name}</Link>
          </h4>
          <p className="text-sm text-muted mt-4 clamp-2">{service.description}</p>
        </div>
        {service.staff?.length ? (
          <span className="row gap-4 text-xs text-muted">
            <Users size={13} /> {service.staff.length} specialist{service.staff.length > 1 ? 's' : ''}
          </span>
        ) : null}
        <div className="row-between mt-4" style={{ marginTop: 'auto', paddingTop: 6 }}>
          <span className="price">{money(service.price_cents, currency)}</span>
          <Link to={`/book/${service.id}`} className="btn btn-primary btn-sm">
            Book <ArrowRight size={14} />
          </Link>
        </div>
      </div>
    </Card>
  );
}
