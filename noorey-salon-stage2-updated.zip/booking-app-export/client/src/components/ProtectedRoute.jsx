import { Navigate, useLocation } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { Card, Empty, Button } from './ui';
import { ShieldAlert } from 'lucide-react';

export default function ProtectedRoute({ children, admin = false }) {
  const { user, booting } = useApp();
  const location = useLocation();

  if (booting) return null;
  if (!user) return <Navigate to="/login" state={{ from: location.pathname }} replace />;
  if (admin && user.role !== 'admin') {
    return (
      <div className="page page-narrow">
        <Card className="card-pad">
          <Empty
            icon={ShieldAlert}
            title="Admin access required"
            hint="This area is for business owners and managers. Ask an administrator to upgrade your account."
            action={<Button onClick={() => (window.location.href = '/')}>Back to site</Button>}
          />
        </Card>
      </div>
    );
  }
  return children;
}
