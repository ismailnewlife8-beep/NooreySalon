import { useCallback, useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, CalendarCheck, Clock, MapPin, ChevronLeft, ChevronRight, Leaf, Sparkles, Flower2, Heart } from 'lucide-react';

const DEFAULT_PHOTOS = ['/hero/slide-1.jpg', '/hero/slide-2.jpg', '/hero/slide-3.jpg'];
const INTERVAL_MS = 6500;

const FEATURES = [
  { icon: Leaf, title: 'Hair & Makeup', text: 'Look your best' },
  { icon: Sparkles, title: 'Nails', text: 'Small details, big impact' },
  { icon: Flower2, title: 'Skin & Spa', text: 'Refresh & rejuvenate' },
  { icon: Heart, title: 'Expert Team', text: 'Trained professionals' },
];

const SLIDES = [
  { key: 'elegant', variant: 'arch', title: ['Look Good', 'Feel Better'], italicLast: false, text: 'Where every visit feels like a celebration. Hair, makeup, nails, skin and spa by a team of specialists, booked in under a minute.' },
  { key: 'minimal', variant: 'portrait', title: ['Your Beauty', 'Our Priority'], italicLast: true, text: 'Hair, makeup, nails, skin and spa by a team of specialists, booked in under a minute.' },
  { key: 'soft', variant: 'circle', title: ['Pamper Yourself', 'You Deserve It —'], italicLast: true, text: 'Hair, makeup, nails, skin and spa by a team of specialists, booked in under a minute.' },
];

/**
 * Home hero: three auto-sliding designs (elegant / minimal / soft).
 * Photos default to the built-in ones; salon photos uploaded in Admin > Settings > Branding
 * (hero photo, then gallery) replace them in order.
 */
export default function HeroSlider({ business }) {
  const [index, setIndex] = useState(0);
  const [paused, setPaused] = useState(false);
  const touchX = useRef(null);

  const gallery = business?.gallery || [];
  const photos = [business?.hero_image_url || gallery[0] || DEFAULT_PHOTOS[0], gallery[1] || DEFAULT_PHOTOS[1], gallery[2] || DEFAULT_PHOTOS[2]];

  const go = useCallback((i) => setIndex((i + SLIDES.length) % SLIDES.length), []);

  useEffect(() => {
    if (paused) return undefined;
    if (typeof window !== 'undefined' && window.matchMedia?.('(prefers-reduced-motion: reduce)').matches) return undefined;
    const t = setInterval(() => setIndex((i) => (i + 1) % SLIDES.length), INTERVAL_MS);
    return () => clearInterval(t);
  }, [paused, index]);

  const onTouchStart = (e) => {
    touchX.current = e.touches[0].clientX;
    setPaused(true);
  };
  const onTouchEnd = (e) => {
    if (touchX.current !== null) {
      const dx = e.changedTouches[0].clientX - touchX.current;
      if (Math.abs(dx) > 50) go(index + (dx < 0 ? 1 : -1));
    }
    touchX.current = null;
    setPaused(false);
  };

  return (
    <section className="hs" aria-roledescription="carousel" aria-label="Welcome" onMouseEnter={() => setPaused(true)} onMouseLeave={() => setPaused(false)}>
      <div className="hs-track" onTouchStart={onTouchStart} onTouchEnd={onTouchEnd}>
        {SLIDES.map((s, i) => (
          <article key={s.key} className={`hs-slide hs-${s.variant}${i === index ? ' active' : ''}`} aria-hidden={i !== index}>
            <div className="hs-copy">
              <span className="hs-eyebrow">DHA Phase 6 · Lahore</span>
              <h1 className="hs-title">
                {s.title[0]}
                <br />
                {s.italicLast ? <em>{s.title[1]}</em> : s.title[1]}
              </h1>
              <p className="hs-text">{s.text}</p>
              <div className="hs-actions">
                <Link to="/book" className="hs-btn" tabIndex={i === index ? 0 : -1}>
                  <CalendarCheck size={16} /> Book an appointment <ArrowRight size={15} />
                </Link>
                <Link to="/services" className="hs-btn hs-btn-ghost" tabIndex={i === index ? 0 : -1}>
                  View services
                </Link>
              </div>
              <div className="hs-meta">
                <span><Clock size={16} /> {business?.hours_text || 'Open daily'}</span>
                <span className="hs-sep" />
                <span><MapPin size={16} /> {business?.address || 'Building 96, CCA-2, DHA Phase 6, Lahore'}</span>
              </div>
            </div>
            <div className="hs-photo">
              <img src={photos[i]} alt="" loading={i === 0 ? 'eager' : 'lazy'} />
            </div>
          </article>
        ))}
      </div>

      <div className="hs-controls">
        <button type="button" className="hs-arrow" onClick={() => go(index - 1)} aria-label="Previous slide"><ChevronLeft size={18} /></button>
        <div className="hs-dots">
          {SLIDES.map((s, i) => (
            <button key={s.key} type="button" className={i === index ? 'on' : ''} onClick={() => go(i)} aria-label={`Show slide ${i + 1}`} />
          ))}
        </div>
        <button type="button" className="hs-arrow" onClick={() => go(index + 1)} aria-label="Next slide"><ChevronRight size={18} /></button>
      </div>

      <div className="hs-features">
        {FEATURES.map((f) => (
          <div key={f.title} className="hs-feature">
            <f.icon size={26} strokeWidth={1.4} />
            <div>
              <div className="hs-feature-title">{f.title}</div>
              <div className="hs-feature-text">{f.text}</div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
