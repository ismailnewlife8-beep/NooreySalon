import { useEffect, useRef, useState } from 'react';
import { X, Inbox, Star, CheckCircle2, AlertCircle, Info, ImagePlus, Trash2, Scissors, Palette, Hand, Sparkles, Flower2 } from 'lucide-react';
import { initials } from '../lib/format';
import { fileToDataUrl } from '../lib/image';

export function cx(...parts) {
  return parts.filter(Boolean).join(' ');
}

export function Button({ variant = 'default', size, className, loading, children, ...rest }) {
  return (
    <button
      className={cx('btn', variant !== 'default' && `btn-${variant}`, size && `btn-${size}`, className)}
      disabled={loading || rest.disabled}
      {...rest}
    >
      {loading && <span className="spinner" />}
      {children}
    </button>
  );
}

export function Card({ className, children, ...rest }) {
  return (
    <div className={cx('card', className)} {...rest}>
      {children}
    </div>
  );
}

export function Badge({ tone, children, className }) {
  return <span className={cx('badge', tone && `badge-${tone}`, className)}>{children}</span>;
}

export function Avatar({ name, url, size, color }) {
  const sizeClass = size === 'lg' ? 'avatar-lg' : size === 'sm' ? 'avatar-sm' : '';
  const style = color && !url ? { background: `${color}1f`, color, borderColor: `${color}55` } : undefined;
  return (
    <span className={cx('avatar', sizeClass)} style={style}>
      {url ? <img src={url} alt={name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : initials(name)}
    </span>
  );
}

export function Stars({ value = 0, size = 14 }) {
  const v = Math.round(Number(value) || 0);
  return (
    <span className="rating" title={`${value} out of 5`}>
      {[1, 2, 3, 4, 5].map((i) => (
        <Star key={i} size={size} fill={i <= v ? 'currentColor' : 'none'} strokeWidth={i <= v ? 0 : 2} opacity={i <= v ? 1 : 0.45} />
      ))}
    </span>
  );
}

export function StarInput({ value, onChange }) {
  return (
    <span className="stars-input">
      {[1, 2, 3, 4, 5].map((i) => (
        <button
          key={i}
          type="button"
          className={cx('star-btn', i <= value && 'on')}
          onClick={() => onChange(i)}
          aria-label={`${i} star${i > 1 ? 's' : ''}`}
        >
          <Star size={22} fill={i <= value ? 'currentColor' : 'none'} />
        </button>
      ))}
    </span>
  );
}

export function Field({ label, hint, error, children, className }) {
  return (
    <div className={cx('field', className)}>
      {label && <label className="label">{label}</label>}
      {children}
      {error ? <span className="field-error">{error}</span> : hint ? <span className="text-xs text-muted">{hint}</span> : null}
    </div>
  );
}

export const Input = (props) => <input className="input" {...props} />;
export const Select = (props) => <select className="select" {...props} />;
export const Textarea = (props) => <textarea className="textarea" {...props} />;

export function Switch({ checked, onChange, id }) {
  return (
    <button type="button" id={id} className={cx('switch', checked && 'on')} onClick={() => onChange(!checked)} aria-pressed={checked} />
  );
}

export function Modal({ title, subtitle, onClose, children, footer, wide, noPad }) {
  useEffect(() => {
    const onKey = (e) => e.key === 'Escape' && onClose?.();
    document.addEventListener('keydown', onKey);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = '';
    };
  }, [onClose]);

  return (
    <div className="overlay" onMouseDown={(e) => e.target === e.currentTarget && onClose?.()}>
      <div className={cx('modal', wide && 'modal-wide')}>
        <div className="modal-head">
          <div>
            <h3>{title}</h3>
            {subtitle && <p className="text-sm text-muted">{subtitle}</p>}
          </div>
          <button className="icon-btn" onClick={onClose} aria-label="Close">
            <X size={18} />
          </button>
        </div>
        <div className={noPad ? '' : 'modal-body'}>{children}</div>
        {footer && <div className="modal-foot">{footer}</div>}
      </div>
    </div>
  );
}

export function Confirm({ open, title, message, confirmLabel = 'Confirm', danger, onConfirm, onCancel, loading }) {
  if (!open) return null;
  return (
    <Modal
      title={title}
      onClose={onCancel}
      footer={
        <>
          <Button variant="outline" onClick={onCancel}>
            Cancel
          </Button>
          <Button variant={danger ? 'danger' : 'primary'} onClick={onConfirm} loading={loading}>
            {confirmLabel}
          </Button>
        </>
      }
    >
      <p className="text-sm" style={{ color: 'var(--text-2)' }}>
        {message}
      </p>
    </Modal>
  );
}

export function Empty({ icon: Icon = Inbox, title = 'Nothing here yet', hint, action }) {
  return (
    <div className="empty">
      <Icon size={34} strokeWidth={1.6} />
      <h4>{title}</h4>
      {hint && <p className="text-sm mt-4">{hint}</p>}
      {action && <div className="mt-12">{action}</div>}
    </div>
  );
}

export function Stat({ label, value, hint, icon: Icon, tone }) {
  return (
    <div className="stat">
      <div className="row-between">
        <span className="stat-label">{label}</span>
        {Icon && (
          <span
            className="brand-mark"
            style={{
              width: 30,
              height: 30,
              borderRadius: 9,
              background: tone === 'green' ? 'var(--green-bg)' : tone === 'amber' ? 'var(--amber-bg)' : 'var(--brand-50)',
              color: tone === 'green' ? 'var(--green)' : tone === 'amber' ? 'var(--amber)' : 'var(--brand)',
            }}
          >
            <Icon size={16} />
          </span>
        )}
      </div>
      <div className="stat-value">{value}</div>
      {hint && <div className="stat-hint">{hint}</div>}
    </div>
  );
}

export function Tabs({ items, value, onChange }) {
  return (
    <div className="tabs">
      {items.map((it) => (
        <button key={it.value} className={cx('tab', value === it.value && 'active')} onClick={() => onChange(it.value)} type="button">
          {it.label}
        </button>
      ))}
    </div>
  );
}

export function Spinner({ size = 22 }) {
  return <span className="spinner spinner-dark" style={{ width: size, height: size }} />;
}

export function Loading({ label = 'Loading…' }) {
  return (
    <div className="center" style={{ padding: '48px 0' }}>
      <Spinner size={26} />
      <p className="text-sm text-muted mt-8">{label}</p>
    </div>
  );
}

export function PageHead({ title, subtitle, actions }) {
  return (
    <div className="section-head">
      <div>
        <h2>{title}</h2>
        {subtitle && <p className="text-sm text-muted mt-4">{subtitle}</p>}
      </div>
      {actions && <div className="row gap-8 wrap">{actions}</div>}
    </div>
  );
}

export function Toasts({ toasts, dismiss }) {
  const icons = { success: CheckCircle2, error: AlertCircle, info: Info };
  return (
    <div className="toasts">
      {toasts.map((t) => {
        const Icon = icons[t.type] || Info;
        return (
          <div key={t.id} className={cx('toast', t.type)}>
            <Icon size={17} style={{ color: t.type === 'error' ? 'var(--red)' : t.type === 'success' ? 'var(--green)' : 'var(--brand)', marginTop: 2 }} />
            <div className="grow">{t.message}</div>
            <button className="icon-btn" style={{ width: 26, height: 26 }} onClick={() => dismiss(t.id)} aria-label="Dismiss">
              <X size={14} />
            </button>
          </div>
        );
      })}
    </div>
  );
}

export function useLocalState(key, initial) {
  const [v, setV] = useState(() => {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : initial;
  });
  useEffect(() => localStorage.setItem(key, JSON.stringify(v)), [key, v]);
  return [v, setV];
}

/* ------------------------------------------------------------------ photos */

const CATEGORY_ICONS = { hair: Scissors, makeup: Palette, nails: Hand, skin: Sparkles, spa: Flower2 };
export const categoryIcon = (category = '') => CATEGORY_ICONS[String(category).toLowerCase()] || Sparkles;

/**
 * Photo with an elegant fallback (gold hairline frame, category icon and name)
 * for services/staff that have no picture yet. Size comes from the parent / className.
 */
export function Media({ url, name = '', category, className, style, children }) {
  const Icon = categoryIcon(category);
  return (
    <div className={cx('media', !url && 'media-fallback', className)} style={style}>
      {url ? (
        <img src={url} alt={name} loading="lazy" />
      ) : (
        <div className="media-fallback-inner">
          <Icon size={26} strokeWidth={1.4} />
          {category ? <span className="eyebrow">{category}</span> : <span className="serif media-initials">{initials(name)}</span>}
        </div>
      )}
      {children}
    </div>
  );
}

/**
 * Admin photo picker: shows the current image, lets the admin choose a file (resized in the
 * browser), and calls onUpload(dataUrl) / onRemove(). Parent decides which endpoint to hit.
 */
export function ImageUploader({ label = 'Photo', hint, url, name, category, onUpload, onRemove, aspect = '4 / 3', round, maxSide = 1400, type = 'image/jpeg', maxBytes = 800 * 1024, disabled, disabledHint }) {
  const inputRef = useRef(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const pick = async (e) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    setError('');
    setBusy(true);
    try {
      const dataUrl = await fileToDataUrl(file, { maxSide, type, maxBytes });
      await onUpload(dataUrl);
    } catch (err) {
      setError(err.message || 'Upload failed');
    } finally {
      setBusy(false);
    }
  };

  const remove = async () => {
    setError('');
    setBusy(true);
    try {
      await onRemove();
    } catch (err) {
      setError(err.message || 'Could not remove the photo');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="field">
      <span className="label">{label}</span>
      <div className="uploader row gap-16 wrap">
        <Media
          url={url}
          name={name}
          category={category}
          className={cx('uploader-preview', round && 'round')}
          style={{ aspectRatio: aspect }}
        />
        <div className="stack gap-8 grow" style={{ minWidth: 160 }}>
          <input ref={inputRef} type="file" accept="image/jpeg,image/png,image/webp" onChange={pick} hidden />
          <div className="row gap-8 wrap">
            <button type="button" className="btn btn-outline btn-sm" disabled={busy || disabled} onClick={() => inputRef.current?.click()}>
              <ImagePlus size={14} /> {busy ? 'Working…' : url ? 'Replace photo' : 'Upload photo'}
            </button>
            {url && (
              <button type="button" className="btn btn-ghost btn-sm" disabled={busy || disabled} onClick={remove}>
                <Trash2 size={14} /> Remove
              </button>
            )}
          </div>
          <span className="text-xs text-muted">{disabled ? disabledHint : hint || 'JPG, PNG or WebP. Large photos are resized automatically.'}</span>
          {error && <span className="field-error">{error}</span>}
        </div>
      </div>
    </div>
  );
}
