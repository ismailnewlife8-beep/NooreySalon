import { Link } from 'react-router-dom';
import { useApp } from '../context/AppContext';

/**
 * Brand lockup: the uploaded logo (Admin > Settings > Branding) or the built-in NOOREY
 * wordmark, followed by the business name.
 */
export function BrandMark({ size = 40 }) {
  const { business } = useApp();
  // Uploaded logo (Admin > Settings > Branding) wins; otherwise the built-in NOOREY wordmark.
  return (
    <img
      className="brand-logo"
      src={business?.logo_url || '/brand/noorey-logo.png'}
      alt=""
      style={{ height: size, width: 'auto', maxWidth: size * 3.2 }}
    />
  );
}

export default function Brand({ to = '/', size = 40, className = 'brand grow' }) {
  const content = (
    <>
      <BrandMark size={size} />
    </>
  );
  return to ? (
    <Link to={to} className={className}>
      {content}
    </Link>
  ) : (
    <div className={className}>{content}</div>
  );
}
