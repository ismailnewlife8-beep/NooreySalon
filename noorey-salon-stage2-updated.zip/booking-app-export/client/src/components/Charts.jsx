import {
  ResponsiveContainer, ComposedChart, Bar, Line, XAxis, YAxis, CartesianGrid, Tooltip,
  PieChart, Pie, Cell, BarChart,
} from 'recharts';

const axisStyle = { fontSize: 11, fill: 'currentColor', opacity: 0.6 };

function ChartTooltip({ active, payload, label, currency = '$', suffix = '' }) {
  if (!active || !payload?.length) return null;
  return (
    <div
      style={{
        background: 'var(--surface)',
        border: '1px solid var(--border)',
        borderRadius: 10,
        padding: '8px 12px',
        boxShadow: 'var(--shadow)',
        fontSize: 12.5,
      }}
    >
      <div className="semibold">{label}</div>
      {payload.map((p) => (
        <div key={p.name} style={{ color: p.color }}>
          {p.name}: {p.name.toLowerCase().includes('revenue') || p.name === 'Revenue' ? currency : ''}
          {typeof p.value === 'number' ? p.value.toLocaleString(undefined, { maximumFractionDigits: 2 }) : p.value}
          {suffix}
        </div>
      ))}
    </div>
  );
}

export function RevenueChart({ data = [], currency = '$', height = 260 }) {
  return (
    <div style={{ width: '100%', height, color: 'var(--muted)' }}>
      <ResponsiveContainer>
        <ComposedChart data={data} margin={{ top: 8, right: 8, bottom: 0, left: -18 }}>
          <defs>
            <linearGradient id="revBar" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#9C6B3F" stopOpacity={0.95} />
              <stop offset="100%" stopColor="#9C6B3F" stopOpacity={0.35} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="currentColor" strokeOpacity={0.12} vertical={false} />
          <XAxis dataKey="date" tick={axisStyle} tickFormatter={(d) => String(d).slice(5)} axisLine={false} tickLine={false} />
          <YAxis tick={axisStyle} axisLine={false} tickLine={false} width={44} />
          <Tooltip content={<ChartTooltip currency={currency} />} />
          <Bar dataKey="revenue" name="Revenue" fill="url(#revBar)" radius={[6, 6, 0, 0]} maxBarSize={26} />
          <Line type="monotone" dataKey="bookings" name="Bookings" stroke="#f59e0b" strokeWidth={2} dot={false} />
        </ComposedChart>
      </ResponsiveContainer>
    </div>
  );
}

export function BarChartSimple({ data = [], dataKey = 'count', labelKey = 'name', currency = '', height = 220, color = '#9C6B3F' }) {
  return (
    <div style={{ width: '100%', height, color: 'var(--muted)' }}>
      <ResponsiveContainer>
        <BarChart data={data} layout="vertical" margin={{ top: 4, right: 12, bottom: 0, left: 8 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="currentColor" strokeOpacity={0.12} horizontal={false} />
          <XAxis type="number" tick={axisStyle} axisLine={false} tickLine={false} />
          <YAxis type="category" dataKey={labelKey} tick={axisStyle} axisLine={false} tickLine={false} width={110} />
          <Tooltip content={<ChartTooltip currency={currency} />} />
          <Bar dataKey={dataKey} fill={color} radius={[0, 6, 6, 0]} maxBarSize={22} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

export function Donut({ data = [], height = 220, colors = ['#5B3F2E', '#B8935A', '#9C6B3F', '#C98B6B', '#8A7155'] }) {
  return (
    <div style={{ width: '100%', height, color: 'var(--muted)' }}>
      <ResponsiveContainer>
        <PieChart>
          <Pie data={data} dataKey="value" nameKey="name" innerRadius="58%" outerRadius="82%" paddingAngle={2} stroke="none">
            {data.map((_, i) => (
              <Cell key={i} fill={colors[i % colors.length]} />
            ))}
          </Pie>
          <Tooltip content={<ChartTooltip />} />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
}

/** Lightweight CSS bars — no chart library needed. */
export function BarList({ items = [], currency = '' }) {
  const max = Math.max(1, ...items.map((i) => i.value));
  return (
    <div className="stack gap-8">
      {items.map((i) => (
        <div key={i.label}>
          <div className="row-between text-sm">
            <span>{i.label}</span>
            <span className="semibold">
              {currency}
              {typeof i.value === 'number' ? i.value.toLocaleString(undefined, { maximumFractionDigits: 2 }) : i.value}
            </span>
          </div>
          <div className="bar-track mt-4">
            <div className="bar-fill" style={{ width: `${Math.round((i.value / max) * 100)}%`, background: i.color || 'var(--brand)' }} />
          </div>
        </div>
      ))}
    </div>
  );
}
