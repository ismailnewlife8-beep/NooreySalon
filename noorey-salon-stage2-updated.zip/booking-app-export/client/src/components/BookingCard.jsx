import { Clock, MapPin, User, CreditCard, Star } from 'lucide-react';
import { Badge, Avatar, Button, cx } from './ui';
import { money, minutesToTime, duration, prettyDate, shortDay, shortMonth, STATUS_LABEL, STATUS_TONE } from '../lib/format';

export default function BookingCard({ booking, currency = '$', onOpen, children, compact }) {
  const past = booking.status === 'completed' || booking.status === 'cancelled' || booking.status === 'no_show';
  return (
    <div className={cx('booking-row', past && 'soft')}>
      <div className="booking-date" style={past ? { background: 'var(--surface-2)', color: 'var(--muted)' } : undefined}>
        <div className="d">{shortDay(booking.date)}</div>
        <div className="m">{shortMonth(booking.date)}</div>
      </div>
      <div className="grow" style={{ minWidth: 0 }}>
        <div className="row gap-8 wrap">
          <span className="semibold truncate">{booking.service_name}</span>
          <Badge tone={STATUS_TONE[booking.status]}>{STATUS_LABEL[booking.status]}</Badge>
          {booking.payment_status === 'paid' ? (
            <Badge tone="green">Paid</Badge>
          ) : booking.payment_status === 'refunded' ? (
            <Badge tone="purple">Refunded</Badge>
          ) : (
            <Badge tone="amber">{booking.payment_method === 'cash' ? 'Pay on arrival' : 'Unpaid'}</Badge>
          )}
        </div>
        <div className="text-sm text-muted row gap-12 wrap mt-4">
          <span className="row gap-4">
            <Clock size={13} /> {prettyDate(booking.date)} · {minutesToTime(booking.start_min)}
          </span>
          {booking.staff_name && (
            <span className="row gap-4">
              <User size={13} /> {booking.staff_name}
            </span>
          )}
          <span className="row gap-4">
            <CreditCard size={13} /> {money(booking.total_cents, currency)}
          </span>
        </div>
        {!compact && booking.notes && (
          <div className="text-xs text-muted mt-4" style={{ fontStyle: 'italic' }}>
            “{booking.notes}”
          </div>
        )}
        {!compact && booking.cancel_reason && (
          <div className="text-xs mt-4" style={{ color: 'var(--red)' }}>
            Cancelled: {booking.cancel_reason}
          </div>
        )}
      </div>
      {booking.staff_name && <Avatar name={booking.staff_name} url={booking.staff_avatar} color={booking.staff_color} />}
      <div className="row gap-6 wrap">
        {children}
        {onOpen && (
          <Button variant="outline" size="sm" onClick={onOpen}>
            Details
          </Button>
        )}
      </div>
    </div>
  );
}
