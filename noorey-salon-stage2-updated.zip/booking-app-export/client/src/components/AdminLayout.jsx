import { useState } from 'react';
import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard, CalendarDays, ClipboardList, Scissors, Users, TicketPercent,
  BarChart3, Bell, Settings, Menu, Moon, Sun, LogOut, ChevronRight, UserCog,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Avatar, cx } from './ui';
import Brand from './Brand';

const NAV = [
  { group: 'Overview' },
  { to: '/admin', label: 'Dashboard', icon: LayoutDashboard, end: true },
  { to: '/admin/calendar', label: 'Calendar', icon: CalendarDays },
  { to: '/admin/bookings', label: 'Bookings', icon: ClipboardList },
  { group: 'Manage' },
  { to: '/admin/services', label: 'Services', icon: Scissors },
  { to: '/admin/staff', label: 'Staff & schedule', icon: UserCog },
  { to: '/admin/customers', label: 'Customers', icon: Users },
  { to: '/admin/coupons', label: 'Coupons', icon: TicketPercent },
  { group: 'Insights' },
  { to: '/admin/reports', label: 'Reports', icon: BarChart3 },
  { to: '/admin/notifications', label: 'Notifications', icon: Bell },
  { to: '/admin/settings', label: 'Settings', icon: Settings },
];

export default function AdminLayout() {
  const { user, business, signOut, theme, toggleTheme } = useApp();
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();

  const links = (
    <>
      {NAV.map((item, i) =>
        item.group ? (
          <div key={`g${i}`} className="side-group">
            {item.group}
          </div>
        ) : (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.end}
            className={({ isActive }) => cx('side-link', isActive && 'active')}
            onClick={() => setOpen(false)}
          >
            <item.icon size={17} strokeWidth={2} />
            <span>{item.label}</span>
          </NavLink>
        )
      )}
    </>
  );

  return (
    <div className="shell">
      {open && <div className="sidebar-backdrop" onClick={() => setOpen(false)} />}
      <aside className={cx('sidebar', open && 'open')}>
        <div className="sidebar-head">
          <Brand to="/" size={36} />
        </div>
        <nav className="sidebar-nav">{links}</nav>
        <div className="sidebar-foot">
          <div className="row gap-8">
            <Avatar name={user?.name} url={user?.avatar_url} size="sm" />
            <div className="grow" style={{ minWidth: 0 }}>
              <div className="text-sm semibold truncate">{user?.name}</div>
              <div className="text-xs text-muted">Administrator</div>
            </div>
            <button className="icon-btn" onClick={toggleTheme} aria-label="Toggle theme">
              {theme === 'dark' ? <Sun size={17} /> : <Moon size={17} />}
            </button>
          </div>
          <button
            className="btn btn-outline btn-sm btn-block mt-8"
            onClick={() => {
              signOut();
              navigate('/');
            }}
          >
            <LogOut size={14} /> Sign out
          </button>
        </div>
      </aside>

      <div className="main">
        <div className="topbar">
          <div className="row gap-8">
            <button className="icon-btn menu-btn" onClick={() => setOpen(true)} aria-label="Open menu">
              <Menu size={20} />
            </button>
            <div className="text-sm text-muted row gap-4">
              <span>Admin</span>
              <ChevronRight size={14} />
              <span className="semibold" style={{ color: 'var(--text)' }}>
                {business?.business_name}
              </span>
            </div>
          </div>
          <div className="row gap-8">
            <button className="btn btn-outline btn-sm" onClick={() => navigate('/')}>
              View site
            </button>
            <button className="icon-btn" onClick={toggleTheme} aria-label="Toggle theme">
              {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
            </button>
            <Avatar name={user?.name} url={user?.avatar_url} />
          </div>
        </div>
        <div className="admin-page">
          <Outlet />
        </div>
      </div>
    </div>
  );
}
