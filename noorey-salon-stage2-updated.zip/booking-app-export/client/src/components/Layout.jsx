import { useEffect, useRef, useState } from 'react';
import { NavLink, Outlet, useNavigate, Link } from 'react-router-dom';
import { LogOut, Menu, Moon, Sun, User, LayoutDashboard, CalendarCheck, MessageCircle, Instagram, Phone, MapPin, Clock } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Avatar, cx } from './ui';
import Brand, { BrandMark } from './Brand';

export default function CustomerLayout() {
  const { user, business, signOut, theme, toggleTheme } = useApp();
  const [menuOpen, setMenuOpen] = useState(false);
  const [accountOpen, setAccountOpen] = useState(false);
  const accountRef = useRef(null);
  const navigate = useNavigate();

  useEffect(() => {
    const onClick = (e) => {
      if (accountRef.current && !accountRef.current.contains(e.target)) setAccountOpen(false);
    };
    document.addEventListener('mousedown', onClick);
    return () => document.removeEventListener('mousedown', onClick);
  }, []);

  const navItems = [
    { to: '/', label: 'Home', end: true },
    { to: '/services', label: 'Services' },
    { to: '/bookings', label: 'My bookings' },
  ];

  const go = (path) => {
    setMenuOpen(false);
    setAccountOpen(false);
    navigate(path);
  };

  return (
    <div className="app">
      <header className="navbar">
        <div className="navbar-inner">
          <button className="icon-btn menu-btn" onClick={() => setMenuOpen((v) => !v)} aria-label="Menu">
            <Menu size={20} />
          </button>
          <Brand to="/" size={42} />

          <nav className="nav-links">
            {navItems.map((it) => (
              <NavLink key={it.to} to={it.to} end={it.end} className={({ isActive }) => cx('nav-link', isActive && 'active')}>
                {it.label}
              </NavLink>
            ))}
          </nav>

          <div className="row gap-4">
            <button className="icon-btn" onClick={toggleTheme} aria-label="Toggle theme" title="Toggle dark mode">
              {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
            </button>

            {user ? (
              <div ref={accountRef} style={{ position: 'relative' }}>
                <button className="icon-btn" onClick={() => setAccountOpen((v) => !v)} aria-label="Account">
                  <Avatar name={user.name} url={user.avatar_url} size="sm" />
                </button>
                {accountOpen && (
                  <div
                    className="card"
                    style={{
                      position: 'absolute',
                      right: 0,
                      top: 'calc(100% + 8px)',
                      width: 216,
                      padding: 8,
                      zIndex: 80,
                      boxShadow: 'var(--shadow-lg)',
                    }}
                  >
                    <div className="row gap-8" style={{ padding: '8px 10px 10px' }}>
                      <Avatar name={user.name} url={user.avatar_url} />
                      <div className="grow" style={{ minWidth: 0 }}>
                        <div className="semibold truncate">{user.name}</div>
                        <div className="text-xs text-muted truncate">{user.email || user.phone}</div>
                      </div>
                    </div>
                    <div className="divider" style={{ margin: '0 0 6px' }} />
                    <button className="nav-link" style={{ width: '100%', textAlign: 'left', display: 'flex', gap: 8 }} onClick={() => go('/profile')}>
                      <User size={16} /> Profile
                    </button>
                    <button className="nav-link" style={{ width: '100%', textAlign: 'left', display: 'flex', gap: 8 }} onClick={() => go('/bookings')}>
                      <CalendarCheck size={16} /> My bookings
                    </button>
                    {user.role === 'admin' && (
                      <button className="nav-link" style={{ width: '100%', textAlign: 'left', display: 'flex', gap: 8 }} onClick={() => go('/admin')}>
                        <LayoutDashboard size={16} /> Admin panel
                      </button>
                    )}
                    <div className="divider" style={{ margin: '6px 0' }} />
                    <button
                      className="nav-link"
                      style={{ width: '100%', textAlign: 'left', display: 'flex', gap: 8, color: 'var(--red)' }}
                      onClick={() => {
                        signOut();
                        setAccountOpen(false);
                        navigate('/');
                      }}
                    >
                      <LogOut size={16} /> Sign out
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <button className="btn btn-primary btn-sm" onClick={() => go('/login')}>
                Sign in
              </button>
            )}
          </div>
        </div>

        {menuOpen && (
          <div className="drawer">
            {navItems.map((it) => (
              <NavLink key={it.to} to={it.to} end={it.end} className={({ isActive }) => cx('nav-link', isActive && 'active')} onClick={() => setMenuOpen(false)}>
                {it.label}
              </NavLink>
            ))}
            {user?.role === 'admin' && (
              <NavLink to="/admin" className="nav-link" onClick={() => setMenuOpen(false)}>
                Admin panel
              </NavLink>
            )}
            {user ? (
              <>
                <NavLink to="/profile" className="nav-link" onClick={() => setMenuOpen(false)}>
                  Profile
                </NavLink>
                <button
                  className="nav-link"
                  style={{ textAlign: 'left' }}
                  onClick={() => {
                    signOut();
                    setMenuOpen(false);
                    navigate('/');
                  }}
                >
                  Sign out
                </button>
              </>
            ) : (
              <NavLink to="/login" className="nav-link" onClick={() => setMenuOpen(false)}>
                Sign in
              </NavLink>
            )}
          </div>
        )}
      </header>

      <main className="grow">
        <Outlet />
      </main>

      <footer className="footer">
        <div className="footer-inner">
          <div className="stack gap-4">
            <div className="row gap-12" style={{ marginBottom: 4 }}>
              <BrandMark size={44} />
              <div className="serif" style={{ color: 'var(--text)', fontSize: 28 }}>{business?.business_name || 'Noorey Salon'}</div>
            </div>
            <div>{business?.tagline}</div>
            <div className="row gap-6" style={{ marginTop: 6 }}><MapPin size={14} /> {business?.address}</div>
            <div className="row gap-6"><Clock size={14} /> {business?.hours_text}</div>
          </div>
          <div className="stack gap-4">
            <div className="semibold" style={{ color: 'var(--text)' }}>Contact</div>
            {business?.phone && <a className="row gap-6" href={`tel:${business.phone.replace(/\s/g, '')}`}><Phone size={14} /> {business.phone}</a>}
            {business?.landline && <a className="row gap-6" href={`tel:${business.landline}`}><Phone size={14} /> {business.landline}</a>}
            {business?.email && <a href={`mailto:${business.email}`}>{business.email}</a>}
            {business?.instagram && (
              <a className="row gap-6" href={`https://instagram.com/${business.instagram}`} target="_blank" rel="noreferrer">
                <Instagram size={14} /> @{business.instagram}
              </a>
            )}
          </div>
          <div className="stack gap-4">
            <div className="semibold" style={{ color: 'var(--text)' }}>Good to know</div>
            <Link to="/services">Services &amp; prices</Link>
            <Link to="/book">Book an appointment</Link>
            <Link to="/privacy">Privacy policy</Link>
            <Link to="/terms">Terms &amp; cancellation</Link>
          </div>
        </div>
        <div className="footer-inner" style={{ marginTop: 18, paddingTop: 14, borderTop: '1px solid var(--border)' }}>
          <span>© {new Date().getFullYear()} {business?.business_name || 'Noorey Salon'}. All rights reserved.</span>
        </div>
      </footer>

      {business?.whatsapp && (
        <a
          className="wa-fab"
          href={`https://wa.me/${business.whatsapp}?text=${encodeURIComponent(`Hi ${business.business_name || 'Noorey Salon'}, I would like to book an appointment.`)}`}
          target="_blank"
          rel="noreferrer"
          aria-label="Chat on WhatsApp"
          title="Chat on WhatsApp"
        >
          <MessageCircle size={26} />
        </a>
      )}
    </div>
  );
}
