import { useEffect, useState } from 'react';
import { Plus, Pencil, Trash2, TicketPercent } from 'lucide-react';
import { api } from '../../lib/api';
import { useApp } from '../../context/AppContext';
import { Card, Button, Modal, Field, Input, Select, Badge, Loading, Empty, Switch } from '../../components/ui';
import { money, todayISO } from '../../lib/format';

const empty = {
  code: '', description: '', type: 'percent', value: 10, min_spend_cents: 0,
  max_discount_cents: '', starts_at: todayISO(), ends_at: '', usage_limit: '', is_active: true,
};

export default function AdminCoupons() {
  const { currency, toast } = useApp();
  const [coupons, setCoupons] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(null);

  const load = () => {
    setLoading(true);
    api('/admin/coupons')
      .then((d) => setCoupons(d.coupons))
      .finally(() => setLoading(false));
  };
  useEffect(load, []);

  const remove = async (c) => {
    if (!window.confirm(`Delete coupon ${c.code}?`)) return;
    await api(`/admin/coupons/${c.id}`, { method: 'DELETE' });
    toast('Coupon deleted', 'success');
    load();
  };

  return (
    <div>
      <div className="row-between wrap gap-12 mb-16">
        <div>
          <h2>Coupons</h2>
          <p className="text-sm text-muted mt-4">Discount codes customers can apply at checkout.</p>
        </div>
        <Button variant="primary" onClick={() => setEditing({ ...empty })}>
          <Plus size={15} /> New coupon
        </Button>
      </div>

      {loading ? (
        <Loading />
      ) : coupons.length ? (
        <div className="grid grid-auto">
          {coupons.map((c) => (
            <Card key={c.id} className="card-pad" style={{ opacity: c.is_active ? 1 : 0.6 }}>
              <div className="row-between">
                <span className="semibold" style={{ letterSpacing: 1 }}>{c.code}</span>
                <Badge tone={c.is_active ? 'green' : 'amber'}>{c.is_active ? 'Active' : 'Paused'}</Badge>
              </div>
              <div className="text-sm mt-8">
                {c.type === 'percent' ? `${c.value}% off` : `${money(c.value, currency)} off`}
              </div>
              <div className="text-xs text-muted mt-4">{c.description}</div>
              <div className="text-xs text-muted mt-12">
                Used {c.used_count}
                {c.usage_limit ? ` / ${c.usage_limit}` : ''} · {c.starts_at || 'anytime'} → {c.ends_at || 'no end'}
              </div>
              <div className="row gap-6 mt-12">
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() =>
                    setEditing({
                      ...c,
                      min_spend_cents: c.min_spend_cents / 100,
                      max_discount_cents: c.max_discount_cents ? c.max_discount_cents / 100 : '',
                    })
                  }
                >
                  <Pencil size={13} />
                </Button>
                <Button size="sm" variant="ghost" onClick={() => remove(c)}>
                  <Trash2 size={13} />
                </Button>
              </div>
            </Card>
          ))}
        </div>
      ) : (
        <Empty icon={TicketPercent} title="No coupons yet" hint="Create a welcome offer to convert first-time visitors." />
      )}

      {editing && <CouponModal initial={editing} onClose={() => setEditing(null)} onSaved={() => { setEditing(null); load(); }} />}
    </div>
  );
}

function CouponModal({ initial, onClose, onSaved }) {
  const { toast } = useApp();
  const [form, setForm] = useState(initial);
  const [saving, setSaving] = useState(false);
  const isNew = !initial.id;

  const submit = async () => {
    setSaving(true);
    try {
      const payload = {
        ...form,
        value: Number(form.value),
        min_spend_cents: Math.round(Number(form.min_spend_cents || 0) * 100),
        max_discount_cents: form.max_discount_cents === '' ? null : Math.round(Number(form.max_discount_cents) * 100),
        usage_limit: form.usage_limit === '' ? null : Number(form.usage_limit),
        ends_at: form.ends_at || null,
      };
      if (isNew) await api('/admin/coupons', { method: 'POST', body: payload });
      else await api(`/admin/coupons/${form.id}`, { method: 'PUT', body: payload });
      toast(isNew ? 'Coupon created' : 'Coupon updated', 'success');
      onSaved();
    } catch (err) {
      toast(err.message, 'error');
    } finally {
      setSaving(false);
    }
  };

  return (
    <Modal
      title={isNew ? 'New coupon' : 'Edit coupon'}
      onClose={onClose}
      footer={
        <>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button variant="primary" loading={saving} onClick={submit}>
            {isNew ? 'Create' : 'Save'}
          </Button>
        </>
      }
    >
      <div className="stack gap-12">
        <div className="grid grid-2">
          <Field label="Code">
            <Input value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value.toUpperCase() })} placeholder="WELCOME15" />
          </Field>
          <Field label="Type">
            <Select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}>
              <option value="percent">Percentage</option>
              <option value="fixed">Fixed amount</option>
            </Select>
          </Field>
          <Field label={form.type === 'percent' ? 'Percent off' : 'Amount off'}>
            <Input type="number" value={form.value} onChange={(e) => setForm({ ...form, value: e.target.value })} />
          </Field>
          <Field label="Minimum spend">
            <Input type="number" step="0.01" value={form.min_spend_cents} onChange={(e) => setForm({ ...form, min_spend_cents: e.target.value })} />
          </Field>
          <Field label="Max discount (optional)">
            <Input type="number" step="0.01" value={form.max_discount_cents} onChange={(e) => setForm({ ...form, max_discount_cents: e.target.value })} />
          </Field>
          <Field label="Usage limit (optional)">
            <Input type="number" value={form.usage_limit} onChange={(e) => setForm({ ...form, usage_limit: e.target.value })} />
          </Field>
          <Field label="Starts">
            <Input type="date" value={form.starts_at || ''} onChange={(e) => setForm({ ...form, starts_at: e.target.value })} />
          </Field>
          <Field label="Ends">
            <Input type="date" value={form.ends_at || ''} onChange={(e) => setForm({ ...form, ends_at: e.target.value })} />
          </Field>
        </div>
        <Field label="Description">
          <Input value={form.description || ''} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="15% off your first visit" />
        </Field>
        <label className="row-between">
          <span className="text-sm">Active</span>
          <Switch checked={!!form.is_active} onChange={(v) => setForm({ ...form, is_active: v })} />
        </label>
      </div>
    </Modal>
  );
}
