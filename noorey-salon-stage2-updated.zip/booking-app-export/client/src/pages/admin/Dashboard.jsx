import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  CalendarClock, DollarSign, Users, TrendingUp, Clock, AlertCircle, ArrowRight, CheckCircle2,
} from 'lucide-react';
import { api } from '../../lib/api';
import { useApp } from '../../context/AppContext';
import { Card, Stat, Loading, Badge, Button, Avatar, Empty, PageHead, Tabs } from '../../components/ui';
import { RevenueChart, BarList, Donut } from '../../components/Charts';
import { money, minutesToTime, prettyDate, duration, STATUS_TONE, STATUS_LABEL } from '../../lib/format';

const RANGES = [
  { value: 14, label: '14 days' },
  { value: 30, label: '30 days' },
];

export default function Dashboard() {
  const { currency, user } = useApp();
  const navigate = useNavigate();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [range, setRange] = useState(14);

  useEffect(() => {
    api('/admin/dashboard')
      .then(setData)
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <Loading label="Loading dashboard…" />;
  if (!data) return <Empty title="Could not load dashboard" />;

  const { stats, today, upcoming, chart, topServices, topStaff, recentCustomers } = data;
  const visible = chart.slice(-range);

  return (
    <div>
      <PageHead
        title={`Good day, ${user?.name?.split(' ')[0] || 'there'}`}
        subtitle={`${prettyDate(new Date().toISOString().slice(0, 10))} · here is what's happening today`}
        actions={
          <>
            <Button variant="outline" onClick={() => navigate('/admin/calendar')}>
              Open calendar
            </Button>
            <Button variant="primary" onClick={() => navigate('/admin/bookings?new=1')}>
              New booking
            </Button>
          </>
        }
      />

      <div className="grid grid-4 mb-24">
        <Stat label="Today's bookings" value={stats.today_bookings} hint={`${stats.pending} awaiting approval`} icon={CalendarClock} />
        <Stat label="Revenue today" value={money(stats.today_revenue, currency)} hint="Collected payments" icon={DollarSign} tone="green" />
        <Stat label="This month" value={money(stats.month_revenue, currency)} hint={`${money(stats.month_pipeline, currency)} booked`} icon={TrendingUp} />
        <Stat label="Utilisation today" value={`${stats.occupancy}%`} hint={`Avg ticket ${money(stats.avg_ticket, currency)}`} icon={Clock} tone="amber" />
      </div>

      <div className="grid" style={{ gridTemplateColumns: 'minmax(0, 1.7fr) minmax(260px, 1fr)' }}>
        <div className="stack gap-16">
          <Card className="card-pad">
            <div className="row-between mb-12">
              <div>
                <h3>Revenue & bookings</h3>
                <p className="text-xs text-muted">Last {range} days</p>
              </div>
              <Tabs items={RANGES} value={range} onChange={setRange} />
            </div>
            <RevenueChart data={visible} currency={currency} />
          </Card>

          <Card className="card-pad">
            <div className="row-between mb-12">
              <h3>Today's schedule</h3>
              <Button variant="ghost" size="sm" onClick={() => navigate('/admin/calendar')}>
                Full calendar <ArrowRight size={13} />
              </Button>
            </div>
            {today.length ? (
              <div className="stack gap-8">
                {today.map((b) => (
                  <div key={b.id} className="row-between" style={{ padding: '10px 12px', border: '1px solid var(--border)', borderRadius: 12 }}>
                    <div className="row gap-12" style={{ minWidth: 0 }}>
                      <span className="semibold" style={{ minWidth: 46 }}>{minutesToTime(b.start_min)}</span>
                      <span style={{ width: 3, alignSelf: 'stretch', background: b.service_color || 'var(--brand)', borderRadius: 3 }} />
                      <div style={{ minWidth: 0 }}>
                        <div className="semibold truncate">{b.service_name}</div>
                        <div className="text-xs text-muted truncate">
                          {b.customer_name} · {b.staff_name || 'Unassigned'} · {duration(b.duration_min)}
                        </div>
                      </div>
                    </div>
                    <div className="row gap-8">
                      <Badge tone={STATUS_TONE[b.status]}>{STATUS_LABEL[b.status]}</Badge>
                      <span className="text-sm semibold">{money(b.total_cents, currency)}</span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <Empty icon={CheckCircle2} title="Nothing booked today" hint="Enjoy the quiet, or send a campaign to fill the gaps." />
            )}
          </Card>

          <div className="grid grid-2">
            <Card className="card-pad">
              <h3 className="mb-12">Top services</h3>
              <BarList items={topServices.map((s) => ({ label: s.name, value: s.count }))} />
            </Card>
            <Card className="card-pad">
              <h3 className="mb-12">Revenue by specialist</h3>
              <BarList
                items={topStaff.map((s) => ({ label: s.name, value: s.revenue, color: s.color }))}
                currency={currency}
              />
            </Card>
          </div>
        </div>

        <div className="stack gap-16">
          <Card className="card-pad">
            <div className="row-between mb-12">
              <h3>Next up</h3>
              <Button variant="ghost" size="sm" onClick={() => navigate('/admin/bookings')}>
                All
              </Button>
            </div>
            {upcoming.length ? (
              <div className="stack gap-12">
                {upcoming.slice(0, 6).map((b) => (
                  <div key={b.id} className="row gap-12">
                    <Avatar name={b.customer_name} url={b.customer_avatar} size="sm" />
                    <div className="grow" style={{ minWidth: 0 }}>
                      <div className="text-sm semibold truncate">{b.customer_name}</div>
                      <div className="text-xs text-muted truncate">
                        {prettyDate(b.date)} · {minutesToTime(b.start_min)} · {b.service_name}
                      </div>
                    </div>
                    {b.status === 'pending' && <AlertCircle size={15} color="var(--amber)" />}
                  </div>
                ))}
              </div>
            ) : (
              <Empty title="No upcoming bookings" />
            )}
          </Card>

          <Card className="card-pad">
            <h3 className="mb-12">New customers</h3>
            <div className="stack gap-12">
              {recentCustomers.map((c) => (
                <div key={c.id} className="row gap-12">
                  <Avatar name={c.name} size="sm" />
                  <div className="grow" style={{ minWidth: 0 }}>
                    <div className="text-sm semibold truncate">{c.name}</div>
                    <div className="text-xs text-muted truncate">{c.email || c.phone}</div>
                  </div>
                </div>
              ))}
            </div>
            <Button variant="outline" size="sm" className="btn-block mt-16" onClick={() => navigate('/admin/customers')}>
              <Users size={14} /> Customer list
            </Button>
          </Card>

          <Card className="card-pad">
            <h3 className="mb-12">This week</h3>
            <div className="kv">
              <span>Bookings</span>
              <span className="semibold">{stats.week_bookings}</span>
            </div>
            <div className="kv">
              <span>New customers</span>
              <span className="semibold">{stats.new_customers}</span>
            </div>
            <div className="kv">
              <span>Awaiting approval</span>
              <span className="semibold">{stats.pending}</span>
            </div>
            <div className="kv">
              <span>Avg ticket</span>
              <span className="semibold">{money(stats.avg_ticket, currency)}</span>
            </div>
            <Donut
              data={[
                { name: 'Confirmed', value: Math.max(1, stats.week_bookings) },
                { name: 'Pending', value: Math.max(1, stats.pending) },
              ]}
              height={170}
            />
          </Card>
        </div>
      </div>
    </div>
  );
}
