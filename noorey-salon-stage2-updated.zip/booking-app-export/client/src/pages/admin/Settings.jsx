import { useEffect, useRef, useState } from 'react';
import { fileToDataUrl } from '../../lib/image';
import { Save, Plug, Building2, Clock, CreditCard, BellRing, Image as ImageIcon, ImagePlus, Trash2 } from 'lucide-react';
import { api } from '../../lib/api';
import { useApp } from '../../context/AppContext';
import { Card, Button, Field, Input, Switch, Badge, Loading, Select, Media, ImageUploader } from '../../components/ui';

const CURRENCIES = [
  { code: 'PKR', symbol: 'Rs' },
  { code: 'USD', symbol: '$' },
  { code: 'EUR', symbol: '€' },
  { code: 'GBP', symbol: '£' },
  { code: 'CNY', symbol: '¥' },
  { code: 'SGD', symbol: 'S$' },
  { code: 'AUD', symbol: 'A$' },
  { code: 'INR', symbol: '₹' },
  { code: 'JPY', symbol: '¥' },
];

export default function AdminSettings() {
  const { capabilities, toast, refreshMeta } = useApp();
  const [settings, setSettings] = useState(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    api('/admin/settings').then((d) => setSettings(d.settings));
  }, []);

  const set = (k, v) => setSettings((s) => ({ ...s, [k]: v }));
  const galleryInput = useRef(null);
  const [galleryBusy, setGalleryBusy] = useState(false);

  // Branding images are saved immediately through their own endpoints (not the Save button),
  // so only the image keys are merged back and unsaved text edits are kept.
  const applyAssets = (next) => {
    setSettings((s) => ({ ...s, logo_url: next.logo_url, hero_image_url: next.hero_image_url, gallery_json: next.gallery_json }));
    refreshMeta();
  };
  const uploadSite = async (slot, image) => {
    const res = await api('/admin/site-image', { method: 'POST', body: { slot, image } });
    applyAssets(res.settings);
    toast('Image saved', 'success');
  };
  const removeSite = async (slot, url) => {
    const res = await api('/admin/site-image', { method: 'DELETE', body: { slot, url } });
    applyAssets(res.settings);
  };
  const addGalleryPhoto = async (e) => {
    const files = Array.from(e.target.files || []);
    e.target.value = '';
    setGalleryBusy(true);
    try {
      for (const file of files) {
        const image = await fileToDataUrl(file, { maxSide: 1600, maxBytes: 1100 * 1024 });
        await uploadSite('gallery', image);
      }
    } catch (err) {
      toast(err.message, 'error');
    } finally {
      setGalleryBusy(false);
    }
  };
  let gallery = [];
  try {
    gallery = JSON.parse(settings?.gallery_json || '[]');
  } catch {
    gallery = [];
  }

  const save = async () => {
    setSaving(true);
    try {
      await api('/admin/settings', { method: 'PUT', body: settings });
      toast('Settings saved', 'success');
      refreshMeta();
    } catch (err) {
      toast(err.message, 'error');
    } finally {
      setSaving(false);
    }
  };

  if (!settings) return <Loading />;

  return (
    <div>
      <div className="row-between wrap gap-12 mb-16">
        <div>
          <h2>Settings</h2>
          <p className="text-sm text-muted mt-4">Branding, booking rules and payment policy.</p>
        </div>
        <Button variant="primary" loading={saving} onClick={save}>
          <Save size={15} /> Save changes
        </Button>
      </div>

      <div className="grid grid-2" style={{ alignItems: 'start' }}>
        <div className="stack gap-16">
          <Card className="card-pad">
            <div className="row gap-8 mb-12">
              <ImageIcon size={17} /> <h3>Branding &amp; photos</h3>
            </div>
            <p className="text-xs text-muted mb-12">Images upload and go live straight away; they do not need the Save button.</p>
            <div className="stack gap-16">
              <ImageUploader
                label="Logo"
                url={settings.logo_url}
                name={settings.business_name}
                aspect="1 / 1"
                type="image/png"
                maxSide={600}
                maxBytes={450 * 1024}
                hint="Square or wide PNG with a transparent background looks best. Without a logo the site shows an “NS” monogram."
                onUpload={(image) => uploadSite('logo', image)}
                onRemove={() => removeSite('logo')}
              />
              <ImageUploader
                label="Home page hero photo"
                url={settings.hero_image_url}
                name="Hero"
                aspect="16 / 9"
                maxSide={1920}
                maxBytes={1100 * 1024}
                hint="Wide photo of the salon, ideally 1920 px across. A dark overlay keeps the text readable."
                onUpload={(image) => uploadSite('hero', image)}
                onRemove={() => removeSite('hero')}
              />
              <div className="field">
                <span className="label">Gallery ({gallery.length}/8)</span>
                <div className="admin-gallery">
                  {gallery.map((url) => (
                    <Media key={url} url={url} name="Gallery photo">
                      <button type="button" className="icon-btn" style={{ background: 'var(--surface)', width: 28, height: 28 }} onClick={() => removeSite('gallery', url)} aria-label="Remove photo">
                        <Trash2 size={14} />
                      </button>
                    </Media>
                  ))}
                </div>
                <input ref={galleryInput} type="file" accept="image/jpeg,image/png,image/webp" multiple onChange={addGalleryPhoto} hidden />
                <div className="row gap-8 mt-8">
                  <Button variant="outline" size="sm" disabled={galleryBusy || gallery.length >= 8} onClick={() => galleryInput.current?.click()}>
                    <ImagePlus size={14} /> {galleryBusy ? 'Uploading…' : 'Add photos'}
                  </Button>
                </div>
                <span className="text-xs text-muted">Until photos are added, the home page shows tasteful placeholders.</span>
              </div>
            </div>
          </Card>

          <Card className="card-pad">
            <div className="row gap-8 mb-12">
              <Building2 size={17} /> <h3>Business profile</h3>
            </div>
            <div className="stack gap-12">
              <div className="grid grid-2">
                <Field label="Business name">
                  <Input value={settings.business_name} onChange={(e) => set('business_name', e.target.value)} />
                </Field>
                <Field label="Type">
                  <Input value={settings.business_type} onChange={(e) => set('business_type', e.target.value)} placeholder="Salon, clinic, studio…" />
                </Field>
              </div>
              <Field label="Tagline">
                <Input value={settings.tagline} onChange={(e) => set('tagline', e.target.value)} />
              </Field>
              <div className="grid grid-2">
                <Field label="Phone">
                  <Input value={settings.phone} onChange={(e) => set('phone', e.target.value)} />
                </Field>
                <Field label="Email">
                  <Input value={settings.email} onChange={(e) => set('email', e.target.value)} />
                </Field>
              </div>
              <Field label="Address">
                <Input value={settings.address} onChange={(e) => set('address', e.target.value)} />
              </Field>
              <Field label="Website">
                <Input value={settings.website} onChange={(e) => set('website', e.target.value)} />
              </Field>
              <Field label="Landline">
                <Input value={settings.landline || ''} onChange={(e) => set('landline', e.target.value)} />
              </Field>
              <Field label="WhatsApp number" hint="Digits only with country code, e.g. 923001234567">
                <Input value={settings.whatsapp || ''} onChange={(e) => set('whatsapp', e.target.value)} />
              </Field>
              <Field label="Instagram username">
                <Input value={settings.instagram || ''} onChange={(e) => set('instagram', e.target.value)} />
              </Field>
              <Field label="Opening hours (shown on the website)">
                <Input value={settings.hours_text || ''} onChange={(e) => set('hours_text', e.target.value)} />
              </Field>
            </div>
          </Card>

          <Card className="card-pad">
            <div className="row gap-8 mb-12">
              <CreditCard size={17} /> <h3>Money</h3>
            </div>
            <div className="grid grid-3">
              <Field label="Currency">
                <Select
                  value={settings.currency}
                  onChange={(e) => {
                    const c = CURRENCIES.find((x) => x.code === e.target.value);
                    setSettings((s) => ({ ...s, currency: c.code, currency_symbol: c.symbol }));
                  }}
                >
                  {CURRENCIES.map((c) => (
                    <option key={c.code} value={c.code}>
                      {c.code} ({c.symbol})
                    </option>
                  ))}
                </Select>
              </Field>
              <Field label="Symbol">
                <Input value={settings.currency_symbol} onChange={(e) => set('currency_symbol', e.target.value)} />
              </Field>
              <Field label="Tax %">
                <Input type="number" value={settings.tax_percent} onChange={(e) => set('tax_percent', Number(e.target.value))} />
              </Field>
              <Field label="Deposit %" hint="0 = charge full amount">
                <Input type="number" value={settings.deposit_percent} onChange={(e) => set('deposit_percent', Number(e.target.value))} />
              </Field>
            </div>
            <div className="divider" />
            <div className="row-between">
              <span className="text-sm">Online card payment</span>
              <Badge>Coming with payment gateway</Badge>
            </div>
            <label className="row-between mt-8">
              <span className="text-sm">Accept cash on arrival</span>
              <Switch checked={!!settings.allow_cash} onChange={(v) => set('allow_cash', v ? 1 : 0)} />
            </label>
          </Card>
        </div>

        <div className="stack gap-16">
          <Card className="card-pad">
            <div className="row gap-8 mb-12">
              <Clock size={17} /> <h3>Booking rules</h3>
            </div>
            <div className="grid grid-2">
              <Field label="Slot granularity (min)">
                <Input type="number" value={settings.slot_granularity_min} onChange={(e) => set('slot_granularity_min', Number(e.target.value))} />
              </Field>
              <Field label="Default buffer (min)">
                <Input type="number" value={settings.default_buffer_min} onChange={(e) => set('default_buffer_min', Number(e.target.value))} />
              </Field>
              <Field label="Minimum notice (hours)">
                <Input type="number" value={settings.min_lead_hours} onChange={(e) => set('min_lead_hours', Number(e.target.value))} />
              </Field>
              <Field label="Booking window (days)">
                <Input type="number" value={settings.max_advance_days} onChange={(e) => set('max_advance_days', Number(e.target.value))} />
              </Field>
              <Field label="Cancellation cutoff (hours)">
                <Input type="number" value={settings.cancellation_hours} onChange={(e) => set('cancellation_hours', Number(e.target.value))} />
              </Field>
              <Field label="Timezone">
                <Input value={settings.timezone} onChange={(e) => set('timezone', e.target.value)} />
              </Field>
            </div>
            <div className="divider" />
            <label className="row-between">
              <span className="text-sm">Auto-confirm bookings</span>
              <Switch checked={!!settings.auto_confirm} onChange={(v) => set('auto_confirm', v ? 1 : 0)} />
            </label>
            <label className="row-between mt-8">
              <span className="text-sm">Require manual approval</span>
              <Switch checked={!!settings.require_approval} onChange={(v) => set('require_approval', v ? 1 : 0)} />
            </label>
          </Card>

          <Card className="card-pad">
            <div className="row gap-8 mb-12">
              <BellRing size={17} /> <h3>Reminders</h3>
            </div>
            <label className="row-between">
              <span className="text-sm">24 hours before</span>
              <Switch checked={!!settings.remind_24h} onChange={(v) => set('remind_24h', v ? 1 : 0)} />
            </label>
            <label className="row-between mt-8">
              <span className="text-sm">2 hours before</span>
              <Switch checked={!!settings.remind_2h} onChange={(v) => set('remind_2h', v ? 1 : 0)} />
            </label>
            <p className="text-xs text-muted mt-12">
              Reminders are sent by email and SMS to customers who opted in. A background job checks every 10 minutes.
            </p>
          </Card>

          <Card className="card-pad">
            <div className="row gap-8 mb-12">
              <Plug size={17} /> <h3>Integrations</h3>
            </div>
            <div className="stack gap-8">
              <div className="row-between">
                <span className="text-sm">Email delivery</span>
                <Badge tone={capabilities?.email ? 'green' : 'amber'}>{capabilities?.email ? 'SMTP live' : 'Dev console'}</Badge>
              </div>
              <div className="row-between">
                <span className="text-sm">SMS / phone OTP</span>
                <Badge tone={capabilities?.sms ? 'green' : 'amber'}>{capabilities?.sms ? 'Twilio live' : 'Dev console'}</Badge>
              </div>
              <div className="row-between">
                <span className="text-sm">Card payments</span>
                <Badge tone="amber">Not enabled yet</Badge>
              </div>
              <div className="row-between">
                <span className="text-sm">Google sign-in</span>
                <Badge tone={capabilities?.google ? 'green' : 'amber'}>{capabilities?.google ? 'Enabled' : 'Not configured'}</Badge>
              </div>
            </div>
            <p className="text-xs text-muted mt-12">
              Add the matching keys to <b>server/.env</b> and restart the API to go live. Until then everything falls back to a
              safe simulated mode so the full flow stays testable.
            </p>
          </Card>
        </div>
      </div>

      <div className="mt-16">
        <Button variant="primary" size="lg" loading={saving} onClick={save}>
          <Save size={15} /> Save changes
        </Button>
      </div>
    </div>
  );
}
