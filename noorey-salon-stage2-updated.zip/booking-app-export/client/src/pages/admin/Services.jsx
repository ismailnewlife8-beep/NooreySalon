import { useEffect, useState } from 'react';
import { Plus, Pencil, Trash2, Clock, Users } from 'lucide-react';
import { api } from '../../lib/api';
import { useApp } from '../../context/AppContext';
import { Card, Button, Modal, Field, Input, Select, Textarea, Switch, Badge, Loading, Empty, Media, ImageUploader, cx } from '../../components/ui';
import { money, duration } from '../../lib/format';

const COLORS = ['#9C6B3F', '#B5651D', '#C98B6B', '#8A7155', '#A3835A', '#B8935A', '#7A5740', '#5B3F2E'];

const empty = {
  name: '', category: 'General', description: '', duration_min: 60, price: '', buffer_min: 10,
  deposit_cents: 0, color: '#B8935A', is_active: true, staffIds: [],
};

export default function AdminServices() {
  const { currency, toast } = useApp();
  const [services, setServices] = useState([]);
  const [staff, setStaff] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(null);

  const load = () => {
    setLoading(true);
    Promise.all([api('/services', { params: { all: '1' } }), api('/staff', { params: { all: '1' } })])
      .then(([s, st]) => {
        setServices(s.services);
        setStaff(st.staff);
      })
      .finally(() => setLoading(false));
  };

  useEffect(load, []);

  const toggleActive = async (s) => {
    await api(`/services/${s.id}`, { method: 'PUT', body: { ...s, is_active: !s.is_active } });
    load();
  };

  const remove = async (s) => {
    if (!window.confirm(`Delete “${s.name}”?`)) return;
    await api(`/services/${s.id}`, { method: 'DELETE' });
    toast('Service deleted', 'success');
    load();
  };

  return (
    <div>
      <div className="row-between wrap gap-12 mb-16">
        <div>
          <h2>Services</h2>
          <p className="text-sm text-muted mt-4">Prices, durations and who can deliver each treatment.</p>
        </div>
        <Button variant="primary" onClick={() => setEditing({ ...empty })}>
          <Plus size={15} /> Add service
        </Button>
      </div>

      {loading ? (
        <Loading />
      ) : services.length ? (
        <div className="grid grid-auto">
          {services.map((s) => (
            <Card key={s.id} style={{ opacity: s.is_active ? 1 : 0.62, overflow: 'hidden' }}>
              <Media url={s.image_url} name={s.name} category={s.category} className="service-media" />
              <div className="card-pad">
              <div className="row-between">
                <span className="text-xs text-muted">{s.image_url ? 'Photo added' : 'No photo yet'}</span>
                <Badge tone={s.is_active ? 'green' : 'amber'}>{s.is_active ? 'Live' : 'Hidden'}</Badge>
              </div>
              <h4 className="mt-12">{s.name}</h4>
              <div className="text-xs text-muted">{s.category}</div>
              <p className="text-sm text-muted mt-8" style={{ minHeight: 36 }}>{s.description}</p>
              <div className="row gap-12 text-sm text-muted mt-8">
                <span className="row gap-4">
                  <Clock size={13} /> {duration(s.duration_min)}
                </span>
                <span className="row gap-4">
                  <Users size={13} /> {s.staff?.length || 0}
                </span>
              </div>
              <div className="row-between mt-12">
                <span className="price">{money(s.price_cents, currency)}</span>
                <div className="row gap-6">
                  <Button size="sm" variant="ghost" onClick={() => setEditing({ ...s, price: (s.price_cents / 100).toFixed(2), staffIds: s.staff.map((x) => x.id) })}>
                    <Pencil size={13} />
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => remove(s)}>
                    <Trash2 size={13} />
                  </Button>
                </div>
              </div>
              <label className="row-between mt-12">
                <span className="text-xs text-muted">Visible to customers</span>
                <Switch checked={!!s.is_active} onChange={() => toggleActive(s)} />
              </label>
              </div>
            </Card>
          ))}
        </div>
      ) : (
        <Empty title="No services yet" hint="Add your first service to start taking bookings." />
      )}

      {editing && (
        <ServiceModal
          initial={editing}
          staff={staff}
          onPhotoChange={load}
          onClose={() => setEditing(null)}
          onSaved={() => {
            setEditing(null);
            load();
          }}
        />
      )}
    </div>
  );
}

function ServiceModal({ initial, staff, onClose, onSaved, onPhotoChange }) {
  const { toast } = useApp();
  const [form, setForm] = useState(initial);
  const [saving, setSaving] = useState(false);
  const isNew = !initial.id;

  const submit = async () => {
    setSaving(true);
    try {
      const payload = {
        ...form,
        price_cents: Math.round(Number(form.price || 0) * 100),
        duration_min: Number(form.duration_min),
        buffer_min: Number(form.buffer_min || 0),
        deposit_cents: Math.round(Number(form.deposit_cents || 0) * 100),
        staffIds: form.staffIds,
      };
      if (isNew) await api('/services', { method: 'POST', body: payload });
      else await api(`/services/${form.id}`, { method: 'PUT', body: payload });
      toast(isNew ? 'Service created' : 'Service updated', 'success');
      onSaved();
    } catch (err) {
      toast(err.message, 'error');
    } finally {
      setSaving(false);
    }
  };

  const toggleStaff = (id) =>
    setForm((f) => ({ ...f, staffIds: f.staffIds.includes(id) ? f.staffIds.filter((x) => x !== id) : [...f.staffIds, id] }));

  return (
    <Modal
      title={isNew ? 'Add service' : 'Edit service'}
      onClose={onClose}
      wide
      footer={
        <>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button variant="primary" loading={saving} onClick={submit}>
            {isNew ? 'Create' : 'Save changes'}
          </Button>
        </>
      }
    >
      <div className="stack gap-12">
        <ImageUploader
          label="Service photo"
          url={form.image_url}
          name={form.name}
          category={form.category}
          aspect="16 / 10"
          disabled={isNew}
          disabledHint="Save the service first, then edit it to add a photo."
          hint="Shown on the services list, home page and booking flow. JPG, PNG or WebP; large photos are resized automatically."
          onUpload={async (image) => {
            const res = await api(`/services/${form.id}/image`, { method: 'POST', body: { image } });
            setForm((f) => ({ ...f, image_url: res.service.image_url }));
            toast('Photo updated', 'success');
            onPhotoChange?.();
          }}
          onRemove={async () => {
            const res = await api(`/services/${form.id}/image`, { method: 'DELETE' });
            setForm((f) => ({ ...f, image_url: res.service.image_url }));
            onPhotoChange?.();
          }}
        />
        <div className="grid grid-2">
          <Field label="Name">
            <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Signature Haircut" />
          </Field>
          <Field label="Category">
            <Input value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} placeholder="Hair" />
          </Field>
        </div>
        <Field label="Description">
          <Textarea value={form.description || ''} onChange={(e) => setForm({ ...form, description: e.target.value })} />
        </Field>
        <div className="grid grid-3">
          <Field label="Duration (min)">
            <Input type="number" value={form.duration_min} onChange={(e) => setForm({ ...form, duration_min: e.target.value })} />
          </Field>
          <Field label="Price">
            <Input type="number" step="0.01" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} placeholder="6500" />
          </Field>
          <Field label="Buffer (min)" hint="Reset time after">
            <Input type="number" value={form.buffer_min} onChange={(e) => setForm({ ...form, buffer_min: e.target.value })} />
          </Field>
        </div>
        <div className="grid grid-2">
          <Field label="Deposit" hint="0 = no deposit">
            <Input type="number" step="0.01" value={form.deposit_cents || 0} onChange={(e) => setForm({ ...form, deposit_cents: e.target.value })} />
          </Field>
          <Field label="Colour">
            <div className="row gap-6">
              {COLORS.map((c) => (
                <button
                  key={c}
                  onClick={() => setForm({ ...form, color: c })}
                  style={{
                    width: 26, height: 26, borderRadius: 8, background: c, border: form.color === c ? '3px solid var(--text)' : '1px solid var(--border)',
                  }}
                  aria-label={c}
                />
              ))}
            </div>
          </Field>
        </div>
        <div>
          <div className="label mb-8">Specialists who can deliver this</div>
          <div className="grid grid-auto-sm">
            {staff.map((s) => (
              <button key={s.id} className={cx('staff-card', form.staffIds.includes(s.id) && 'selected')} onClick={() => toggleStaff(s.id)}>
                <span className="dot" style={{ background: s.color, width: 10, height: 10 }} />
                <span className="grow" style={{ textAlign: 'left' }}>{s.name}</span>
                {form.staffIds.includes(s.id) && <span style={{ color: 'var(--brand)' }}>✓</span>}
              </button>
            ))}
          </div>
          <p className="text-xs text-muted mt-8">Leave empty to allow every specialist.</p>
        </div>
        <label className="row-between">
          <span className="text-sm">Visible to customers</span>
          <Switch checked={!!form.is_active} onChange={(v) => setForm({ ...form, is_active: v })} />
        </label>
      </div>
    </Modal>
  );
}
