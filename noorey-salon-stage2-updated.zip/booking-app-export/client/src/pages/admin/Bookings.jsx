import { useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Plus, Search, UserPlus, Check, X, Ban } from 'lucide-react';
import { api } from '../../lib/api';
import { useApp } from '../../context/AppContext';
import {
  Card, Button, Input, Select, Field, Modal, Badge, Loading, Empty, Tabs, cx, Avatar, Spinner,
} from '../../components/ui';
import { money, minutesToTime, prettyDate, duration, STATUS_LABEL, STATUS_TONE, todayISO, addDaysISO } from '../../lib/format';

const FILTERS = [
  { value: 'all', label: 'All' },
  { value: 'pending', label: 'Pending' },
  { value: 'confirmed', label: 'Confirmed' },
  { value: 'completed', label: 'Completed' },
  { value: 'cancelled', label: 'Cancelled' },
  { value: 'no_show', label: 'No show' },
];

export default function AdminBookings() {
  const { currency, toast } = useApp();
  const [params, setParams] = useSearchParams();
  const [list, setList] = useState([]);
  const [services, setServices] = useState([]);
  const [staff, setStaff] = useState([]);
  const [loading, setLoading] = useState(true);
  const [status, setStatus] = useState('all');
  const [q, setQ] = useState('');
  const [date, setDate] = useState('');
  const [staffFilter, setStaffFilter] = useState('');
  const [open, setOpen] = useState(params.get('new') === '1');

  const load = () => {
    setLoading(true);
    api('/admin/bookings', { params: { status, q, date, staffId: staffFilter } })
      .then((d) => setList(d.bookings))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    api('/services', { params: { all: '1' } }).then((d) => setServices(d.services));
    api('/staff', { params: { all: '1' } }).then((d) => setStaff(d.staff));
  }, []);

  useEffect(() => {
    load();
    if (params.get('new') === '1') {
      setOpen(true);
      const next = new URLSearchParams(params);
      next.delete('new');
      setParams(next, { replace: true });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [status, staffFilter, date]);

  const act = async (id, status2) => {
    try {
      await api(`/admin/bookings/${id}/status`, { method: 'PATCH', body: { status: status2 } });
      toast('Updated', 'success');
      load();
    } catch (err) {
      toast(err.message, 'error');
    }
  };

  return (
    <div>
      <div className="row-between wrap gap-12 mb-16">
        <div>
          <h2>Bookings</h2>
          <p className="text-sm text-muted mt-4">{list.length} records · search by customer, code or service</p>
        </div>
        <Button variant="primary" onClick={() => setOpen(true)}>
          <Plus size={15} /> New booking
        </Button>
      </div>

      <Card className="card-pad mb-16">
        <div className="row gap-12 wrap">
          <div style={{ position: 'relative', flex: 1, minWidth: 220 }}>
            <Search size={16} style={{ position: 'absolute', left: 12, top: 13, color: 'var(--muted)' }} />
            <Input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && load()}
              placeholder="Search…"
              style={{ paddingLeft: 34 }}
            />
          </div>
          <div style={{ width: 160 }}>
            <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
          </div>
          <div style={{ width: 190 }}>
            <Select value={staffFilter} onChange={(e) => setStaffFilter(e.target.value)}>
              <option value="">All specialists</option>
              {staff.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </Select>
          </div>
          <Button variant="outline" onClick={load}>
            Apply
          </Button>
        </div>
        <div className="chip-row mt-16">
          {FILTERS.map((f) => (
            <button key={f.value} className={cx('chip', status === f.value && 'active')} onClick={() => setStatus(f.value)}>
              {f.label}
            </button>
          ))}
        </div>
      </Card>

      <Card style={{ padding: 0, overflow: 'hidden' }}>
        {loading ? (
          <div style={{ padding: 40 }}>
            <Loading />
          </div>
        ) : list.length ? (
          <div className="table-wrap">
            <table className="table">
              <thead>
                <tr>
                  <th>When</th>
                  <th>Customer</th>
                  <th>Service</th>
                  <th>Specialist</th>
                  <th>Total</th>
                  <th>Status</th>
                  <th />
                </tr>
              </thead>
              <tbody>
                {list.map((b) => (
                  <tr key={b.id}>
                    <td>
                      <div className="semibold">{prettyDate(b.date)}</div>
                      <div className="text-xs text-muted">
                        {minutesToTime(b.start_min)} · {duration(b.duration_min)}
                      </div>
                    </td>
                    <td>
                      <div className="row gap-8">
                        <Avatar name={b.customer_name} url={b.customer_avatar} size="sm" />
                        <div style={{ minWidth: 0 }}>
                          <div className="semibold truncate">{b.customer_name}</div>
                          <div className="text-xs text-muted truncate">{b.customer_email || b.customer_phone}</div>
                        </div>
                      </div>
                    </td>
                    <td>{b.service_name}</td>
                    <td>{b.staff_name || '—'}</td>
                    <td>
                      <div className="semibold">{money(b.total_cents, currency)}</div>
                      <div className="text-xs text-muted">
                        {b.payment_status === 'paid' ? 'Paid' : b.payment_method === 'cash' ? 'On arrival' : 'Unpaid'}
                      </div>
                    </td>
                    <td>
                      <Badge tone={STATUS_TONE[b.status]}>{STATUS_LABEL[b.status]}</Badge>
                    </td>
                    <td>
                      <div className="row gap-6" style={{ justifyContent: 'flex-end' }}>
                        {b.status === 'pending' && (
                          <Button size="sm" variant="soft" onClick={() => act(b.id, 'confirmed')}>
                            <Check size={13} /> Approve
                          </Button>
                        )}
                        {b.status === 'confirmed' && (
                          <Button size="sm" variant="outline" onClick={() => act(b.id, 'completed')}>
                            Complete
                          </Button>
                        )}
                        {!['cancelled', 'completed'].includes(b.status) && (
                          <Button size="sm" variant="danger" onClick={() => act(b.id, 'cancelled')}>
                            <Ban size={13} />
                          </Button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <Empty icon={Search} title="No bookings match" hint="Change the filters or create a walk-in booking." />
        )}
      </Card>

      {open && (
        <NewBookingModal
          services={services}
          staff={staff}
          onClose={() => setOpen(false)}
          onCreated={() => {
            setOpen(false);
            load();
          }}
        />
      )}
    </div>
  );
}

function NewBookingModal({ services, staff, onClose, onCreated }) {
  const { toast } = useApp();
  const [mode, setMode] = useState('existing');
  const [customerId, setCustomerId] = useState('');
  const [customers, setCustomers] = useState([]);
  const [form, setForm] = useState({ name: '', phone: '', email: '', notes: '' });
  const [serviceId, setServiceId] = useState('');
  const [staffId, setStaffId] = useState('');
  const [date, setDate] = useState(todayISO());
  const [slots, setSlots] = useState([]);
  const [startMin, setStartMin] = useState(null);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    api('/admin/customers').then((d) => setCustomers(d.customers.slice(0, 200)));
  }, []);

  useEffect(() => {
    if (!serviceId || !date) return;
    setLoading(true);
    setStartMin(null);
    api('/availability', { params: { serviceId, date, staffId } })
      .then((d) => setSlots(d.slots || []))
      .finally(() => setLoading(false));
  }, [serviceId, date, staffId]);

  const submit = async () => {
    setSaving(true);
    try {
      await api('/admin/bookings', {
        method: 'POST',
        body: {
          customerId: mode === 'existing' ? Number(customerId) : null,
          name: form.name,
          phone: form.phone,
          email: form.email,
          serviceId: Number(serviceId),
          staffId: staffId ? Number(staffId) : null,
          date,
          startMin,
          paymentMethod: 'cash',
          notes: form.notes || null,
        },
      });
      toast('Booking created', 'success');
      onCreated();
    } catch (err) {
      toast(err.message, 'error');
    } finally {
      setSaving(false);
    }
  };

  return (
    <Modal
      title="New booking"
      subtitle="Walk-in, phone or manual booking — no customer login needed"
      onClose={onClose}
      wide
      footer={
        <>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button variant="primary" loading={saving} disabled={!serviceId || startMin === null} onClick={submit}>
            Create booking
          </Button>
        </>
      }
    >
      <div className="stack gap-16">
        <div className="row gap-8">
          <button className={cx('chip', mode === 'existing' && 'active')} onClick={() => setMode('existing')}>
            Existing customer
          </button>
          <button className={cx('chip', mode === 'new' && 'active')} onClick={() => setMode('new')}>
            <UserPlus size={13} /> New customer
          </button>
        </div>

        {mode === 'existing' ? (
          <Field label="Customer">
            <Select value={customerId} onChange={(e) => setCustomerId(e.target.value)}>
              <option value="">Select a customer…</option>
              {customers.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name} · {c.email || c.phone}
                </option>
              ))}
            </Select>
          </Field>
        ) : (
          <div className="grid grid-3">
            <Field label="Name">
              <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
            </Field>
            <Field label="Phone">
              <Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
            </Field>
            <Field label="Email">
              <Input value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
            </Field>
          </div>
        )}

        <div className="grid grid-3">
          <Field label="Service">
            <Select value={serviceId} onChange={(e) => setServiceId(e.target.value)}>
              <option value="">Select…</option>
              {services.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} · {duration(s.duration_min)}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Specialist">
            <Select value={staffId} onChange={(e) => setStaffId(e.target.value)}>
              <option value="">Any available</option>
              {staff.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Date">
            <Input type="date" value={date} min={todayISO()} onChange={(e) => setDate(e.target.value)} />
          </Field>
        </div>

        <div>
          <div className="label mb-8">Time</div>
          {loading ? (
            <div className="center" style={{ padding: 20 }}>
              <Spinner />
            </div>
          ) : slots.length ? (
            <div className="slots">
              {slots.map((s) => (
                <button key={s.start} className={cx('slot', startMin === s.start && 'selected')} disabled={!s.available} onClick={() => setStartMin(s.start)}>
                  {s.time}
                </button>
              ))}
            </div>
          ) : (
            <p className="text-sm text-muted">Pick a service and date to see slots.</p>
          )}
        </div>

        <Field label="Notes (optional)">
          <Input value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} placeholder="Internal note…" />
        </Field>
      </div>
    </Modal>
  );
}
