import { useEffect, useState } from 'react';
import { Send, Bell, Mail, MessageSquare, CheckCircle2, AlertCircle } from 'lucide-react';
import { api } from '../../lib/api';
import { useApp } from '../../context/AppContext';
import { Card, Button, Field, Input, Select, Textarea, Badge, Loading, Empty, Tabs } from '../../components/ui';

const SEGMENTS = [
  { value: 'all', label: 'All customers' },
  { value: 'upcoming', label: 'Customers with upcoming bookings' },
  { value: 'vip', label: 'Top spenders' },
  { value: 'new', label: 'New customers (30 days)' },
];

export default function AdminNotifications() {
  const { capabilities, toast, business } = useApp();
  const [channel, setChannel] = useState('email');
  const [segment, setSegment] = useState('all');
  const [subject, setSubject] = useState('');
  const [body, setBody] = useState('');
  const [sending, setSending] = useState(false);
  const [log, setLog] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = () => api('/admin/notifications', { params: { limit: 60 } }).then((d) => setLog(d.notifications));

  useEffect(() => {
    load().finally(() => setLoading(false));
  }, []);

  const send = async () => {
    if (!body.trim()) return toast('Write a message first', 'error');
    setSending(true);
    try {
      const res = await api('/admin/notifications', { method: 'POST', body: { segment, channel, subject: subject || business?.business_name, body } });
      toast(`${res.sent} sent${res.failed ? `, ${res.failed} failed` : ''}`, res.failed ? 'error' : 'success');
      setBody('');
      setSubject('');
      load();
    } catch (err) {
      toast(err.message, 'error');
    } finally {
      setSending(false);
    }
  };

  return (
    <div>
      <div className="mb-16">
        <h2>Notifications</h2>
        <p className="text-sm text-muted mt-4">
          Automatic confirmations and reminders go out on their own — use this to message customers directly.
        </p>
      </div>

      <div className="grid" style={{ gridTemplateColumns: 'minmax(0, 1fr) minmax(320px, 1fr)', alignItems: 'start' }}>
        <Card className="card-pad">
          <div className="row-between mb-12">
            <h3>Compose</h3>
            <Tabs
              items={[
                { value: 'email', label: 'Email' },
                { value: 'sms', label: 'SMS' },
              ]}
              value={channel}
              onChange={setChannel}
            />
          </div>

          <div className="stack gap-12">
            <Field label="Audience">
              <Select value={segment} onChange={(e) => setSegment(e.target.value)}>
                {SEGMENTS.map((s) => (
                  <option key={s.value} value={s.value}>
                    {s.label}
                  </option>
                ))}
              </Select>
            </Field>
            {channel === 'email' && (
              <Field label="Subject">
                <Input value={subject} onChange={(e) => setSubject(e.target.value)} placeholder={business?.business_name} />
              </Field>
            )}
            <Field label="Message" hint={channel === 'sms' ? 'Keep it short — long messages get split and cost more.' : undefined}>
              <Textarea
                value={body}
                onChange={(e) => setBody(e.target.value)}
                rows={channel === 'sms' ? 3 : 6}
                placeholder={channel === 'sms' ? 'Reminder: we have a slot open tomorrow at 3pm. Reply to grab it!' : 'Hi there,\n\nWe just opened extra slots for next week…'}
              />
            </Field>
            <div className="row gap-8">
              <Button variant="primary" loading={sending} onClick={send}>
                <Send size={15} /> Send to {segment === 'all' ? 'all customers' : 'segment'}
              </Button>
              <span className="text-xs text-muted row gap-6">
                {channel === 'email' ? <Mail size={13} /> : <MessageSquare size={13} />}
                {channel === 'email'
                  ? capabilities?.email
                    ? 'SMTP configured'
                    : 'No email provider — logged to console'
                  : capabilities?.sms
                  ? 'Twilio configured'
                  : 'No SMS provider — logged to console'}
              </span>
            </div>
          </div>
        </Card>

        <Card className="card-pad">
          <div className="row-between mb-12">
            <h3>Delivery log</h3>
            <Badge tone="blue">{log.length}</Badge>
          </div>
          {loading ? (
            <Loading />
          ) : log.length ? (
            <div className="stack gap-8" style={{ maxHeight: 460, overflow: 'auto' }}>
              {log.map((n) => (
                <div key={n.id} style={{ border: '1px solid var(--border)', borderRadius: 10, padding: '8px 12px' }}>
                  <div className="row-between">
                    <span className="text-sm semibold truncate">{n.subject || n.channel.toUpperCase()}</span>
                    <span className="row gap-4" style={{ color: n.status === 'sent' ? 'var(--green)' : n.status === 'failed' ? 'var(--red)' : 'var(--muted)' }}>
                      {n.status === 'sent' ? <CheckCircle2 size={13} /> : n.status === 'failed' ? <AlertCircle size={13} /> : <Bell size={13} />}
                      <span className="text-xs">{n.status}</span>
                    </span>
                  </div>
                  <div className="text-xs text-muted truncate">
                    → {n.recipient || 'in-app'} · {n.provider || '—'}
                  </div>
                  <div className="text-xs mt-4" style={{ color: 'var(--text-2)', whiteSpace: 'pre-wrap' }}>{n.body}</div>
                </div>
              ))}
            </div>
          ) : (
            <Empty icon={Bell} title="Nothing sent yet" hint="Booking confirmations and reminders will appear here too." />
          )}
        </Card>
      </div>
    </div>
  );
}
