import { useEffect, useMemo, useState } from 'react';
import { Download, TrendingUp, Users, Percent } from 'lucide-react';
import { api } from '../../lib/api';
import { useApp } from '../../context/AppContext';
import { Card, Stat, Tabs, Loading, Empty, Button } from '../../components/ui';
import { RevenueChart, BarChartSimple, Donut, BarList } from '../../components/Charts';
import { money, todayISO, addDaysISO, prettyDate } from '../../lib/format';

const PRESETS = [
  { value: 7, label: '7 days' },
  { value: 30, label: '30 days' },
  { value: 90, label: '90 days' },
];

export default function AdminReports() {
  const { currency } = useApp();
  const [days, setDays] = useState(30);
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    api('/admin/reports', { params: { from: addDaysISO(todayISO(), -days + 1), to: todayISO() } })
      .then(setData)
      .finally(() => setLoading(false));
  }, [days]);

  const csv = useMemo(() => {
    if (!data) return '';
    const rows = [['Date', 'Bookings', 'Revenue', 'Cancelled']];
    for (const d of data.byDay) rows.push([d.date, d.bookings, d.revenue, d.cancelled]);
    return rows.map((r) => r.join(',')).join('\n');
  }, [data]);

  if (loading) return <Loading label="Crunching numbers…" />;
  if (!data) return <Empty title="No report data" />;

  const { totals, byDay, byService, byStaff, byPayment, byHour, newVsReturning, couponUsage } = data;

  return (
    <div>
      <div className="row-between wrap gap-12 mb-16">
        <div>
          <h2>Reports</h2>
          <p className="text-sm text-muted mt-4">
            {prettyDate(data.range.from)} → {prettyDate(data.range.to)}
          </p>
        </div>
        <div className="row gap-8">
          <Tabs items={PRESETS} value={days} onChange={setDays} />
          <Button
            variant="outline"
            onClick={() => {
              const blob = new Blob([csv], { type: 'text/csv' });
              const url = URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = `report-${data.range.from}-${data.range.to}.csv`;
              a.click();
              URL.revokeObjectURL(url);
            }}
          >
            <Download size={15} /> Export CSV
          </Button>
        </div>
      </div>

      <div className="grid grid-4 mb-24">
        <Stat label="Revenue" value={money(totals.revenue, currency)} hint={`${money(totals.collected, currency)} collected`} icon={TrendingUp} tone="green" />
        <Stat label="Bookings" value={totals.bookings} hint={`${totals.completed} completed`} icon={Users} />
        <Stat label="Avg ticket" value={money(totals.avg_ticket, currency)} hint={`${money(totals.discounts, currency)} discounted`} icon={TrendingUp} />
        <Stat label="Cancellation rate" value={`${totals.cancellation_rate}%`} hint={`${totals.no_shows} no-shows`} icon={Percent} tone="amber" />
      </div>

      <div className="grid" style={{ gridTemplateColumns: 'minmax(0, 1.6fr) minmax(260px, 1fr)' }}>
        <div className="stack gap-16">
          <Card className="card-pad">
            <h3 className="mb-12">Revenue over time</h3>
            <RevenueChart data={byDay} currency={currency} height={280} />
          </Card>

          <Card className="card-pad">
            <h3 className="mb-12">Revenue by service</h3>
            {byService.length ? (
              <BarChartSimple data={byService} dataKey="revenue" labelKey="name" currency={currency} height={Math.max(180, byService.length * 42)} />
            ) : (
              <Empty title="No data in this range" />
            )}
          </Card>

          <Card className="card-pad">
            <h3 className="mb-12">Busiest hours</h3>
            {byHour.length ? (
              <BarChartSimple data={byHour.map((h) => ({ ...h, name: `${h.hour}:00` }))} dataKey="bookings" labelKey="name" color="#f59e0b" height={Math.max(180, byHour.length * 34)} />
            ) : (
              <Empty title="No data" />
            )}
          </Card>
        </div>

        <div className="stack gap-16">
          <Card className="card-pad">
            <h3 className="mb-12">New vs returning</h3>
            <Donut data={newVsReturning.map((n) => ({ name: n.type, value: n.bookings }))} height={200} />
            <div className="stack gap-4 mt-12">
              {newVsReturning.map((n) => (
                <div key={n.type} className="kv">
                  <span style={{ textTransform: 'capitalize' }}>{n.type}</span>
                  <span className="semibold">
                    {n.bookings} · {money(n.revenue, currency)}
                  </span>
                </div>
              ))}
            </div>
          </Card>

          <Card className="card-pad">
            <h3 className="mb-12">Payment mix</h3>
            <BarList
              items={byPayment.map((p) => ({
                label: p.method === 'card' ? 'Card' : p.method === 'cash' ? 'Cash / on arrival' : 'Unset',
                value: p.revenue,
              }))}
              currency={currency}
            />
          </Card>

          <Card className="card-pad">
            <h3 className="mb-12">Specialist performance</h3>
            {byStaff.length ? (
              <div className="stack gap-8">
                {byStaff.map((s) => (
                  <div key={s.name} className="kv">
                    <span className="row gap-6">
                      <span className="dot" style={{ background: s.color }} /> {s.name}
                    </span>
                    <span className="semibold">
                      {s.bookings} · {money(s.revenue, currency)}
                    </span>
                  </div>
                ))}
              </div>
            ) : (
              <Empty title="No data" />
            )}
          </Card>

          <Card className="card-pad">
            <h3 className="mb-12">Coupon usage</h3>
            {couponUsage.length ? (
              <div className="stack gap-8">
                {couponUsage.map((c) => (
                  <div key={c.code} className="kv">
                    <span>{c.code}</span>
                    <span className="semibold">
                      {c.uses} · −{money(c.discount, currency)}
                    </span>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-muted">No coupons redeemed in this range.</p>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
}
