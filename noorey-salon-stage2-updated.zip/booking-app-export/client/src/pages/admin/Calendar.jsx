import { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronLeft, ChevronRight, CalendarDays, Plus, Clock, User, X } from 'lucide-react';
import { api } from '../../lib/api';
import { useApp } from '../../context/AppContext';
import { Card, Tabs, Button, Modal, Badge, Loading, Empty, Avatar, cx } from '../../components/ui';
import { minutesToTime, todayISO, addDaysISO, toDate, prettyDate, money, duration, STATUS_TONE, STATUS_LABEL } from '../../lib/format';
import { format } from 'date-fns';

const VIEWS = [
  { value: 'day', label: 'Day' },
  { value: 'week', label: 'Week' },
  { value: 'month', label: 'Month' },
];

const START_HOUR = 7;
const END_HOUR = 21;
const PX_PER_MIN = 0.95;
const HOUR_HEIGHT = 60 * PX_PER_MIN;

const mondayOf = (dateStr) => {
  const wd = toDate(dateStr).getUTCDay(); // 0 Sun
  return addDaysISO(dateStr, -((wd + 6) % 7));
};

function monthCells(monthStart) {
  const first = toDate(monthStart);
  const year = first.getUTCFullYear();
  const month = first.getUTCMonth();
  const startIdx = Math.floor(Date.UTC(year, month, 1) / 86400000);
  const offset = new Date(Date.UTC(year, month, 1)).getUTCDay();
  const daysInMonth = new Date(Date.UTC(year, month + 1, 0)).getUTCDate();
  const cells = Array(offset).fill(null);
  for (let d = 1; d <= daysInMonth; d += 1) cells.push(new Date((startIdx + d - 1) * 86400000).toISOString().slice(0, 10));
  while (cells.length % 7 !== 0) cells.push(null);
  return cells;
}

export default function AdminCalendar() {
  const { currency, toast } = useApp();
  const navigate = useNavigate();
  const today = todayISO();
  const [view, setView] = useState('week');
  const [anchor, setAnchor] = useState(today);
  const [items, setItems] = useState([]);
  const [staff, setStaff] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState(null);

  const range = useMemo(() => {
    if (view === 'day') return { from: anchor, to: anchor };
    if (view === 'week') {
      const start = mondayOf(anchor);
      return { from: start, to: addDaysISO(start, 6) };
    }
    const cells = monthCells(anchor.slice(0, 8) + '01').filter(Boolean);
    return { from: cells[0], to: cells[cells.length - 1] };
  }, [view, anchor]);

  useEffect(() => {
    setLoading(true);
    Promise.all([
      api('/admin/calendar', { params: range }),
      api('/staff', { params: { all: '1' } }),
    ])
      .then(([cal, st]) => {
        setItems(cal.appointments);
        setStaff(st.staff);
      })
      .finally(() => setLoading(false));
  }, [range.from, range.to]);

  const byDate = useMemo(() => {
    const map = {};
    for (const a of items) (map[a.date] = map[a.date] || []).push(a);
    return map;
  }, [items]);

  const move = (dir) => {
    if (view === 'day') setAnchor((d) => addDaysISO(d, dir));
    else if (view === 'week') setAnchor((d) => addDaysISO(d, dir * 7));
    else {
      const d = toDate(anchor.slice(0, 8) + '01');
      d.setUTCMonth(d.getUTCMonth() + dir);
      setAnchor(d.toISOString().slice(0, 10));
    }
  };

  const title =
    view === 'day'
      ? format(toDate(anchor), 'EEEE d MMMM yyyy')
      : view === 'week'
      ? `${format(toDate(range.from), 'd MMM')} – ${format(toDate(range.to), 'd MMM yyyy')}`
      : format(toDate(anchor.slice(0, 8) + '01'), 'MMMM yyyy');

  const setStatus = async (id, status) => {
    try {
      await api(`/admin/bookings/${id}/status`, { method: 'PATCH', body: { status } });
      toast('Status updated', 'success');
      setSelected(null);
      const cal = await api('/admin/calendar', { params: range });
      setItems(cal.appointments);
    } catch (err) {
      toast(err.message, 'error');
    }
  };

  const weekDays = useMemo(() => Array.from({ length: 7 }, (_, i) => addDaysISO(mondayOf(anchor), i)), [anchor]);
  const hours = useMemo(() => Array.from({ length: END_HOUR - START_HOUR + 1 }, (_, i) => START_HOUR + i), []);

  const Pill = ({ a, compact }) => {
    const top = (a.start_min - START_HOUR * 60) * PX_PER_MIN;
    const height = Math.max(20, (a.end_min - a.start_min) * PX_PER_MIN);
    return (
      <button
        className="appt-pill"
        style={{
          top,
          height,
          background: a.service_color || 'var(--brand)',
          opacity: a.status === 'cancelled' ? 0.45 : 1,
          textDecoration: a.status === 'cancelled' ? 'line-through' : 'none',
        }}
        onClick={() => setSelected(a)}
        title={`${a.service_name} · ${a.customer_name}`}
      >
        <b>{minutesToTime(a.start_min)}</b> {a.service_name}
        {!compact && <div style={{ opacity: 0.9 }}>{a.customer_name}</div>}
      </button>
    );
  };

  return (
    <div>
      <div className="row-between wrap gap-12 mb-16">
        <div>
          <h2>Calendar</h2>
          <p className="text-sm text-muted mt-4">{items.length} appointments in view</p>
        </div>
        <div className="row gap-8 wrap">
          <Tabs items={VIEWS} value={view} onChange={setView} />
          <div className="row gap-4">
            <button className="icon-btn" onClick={() => move(-1)} aria-label="Previous">
              <ChevronLeft size={18} />
            </button>
            <Button variant="outline" size="sm" onClick={() => setAnchor(today)}>
              Today
            </Button>
            <button className="icon-btn" onClick={() => move(1)} aria-label="Next">
              <ChevronRight size={18} />
            </button>
          </div>
          <Button variant="primary" onClick={() => navigate('/admin/bookings?new=1')}>
            <Plus size={15} /> New
          </Button>
        </div>
      </div>

      <Card className="card-pad" style={{ padding: 0, overflow: 'hidden' }}>
        <div className="row-between" style={{ padding: '12px 16px', borderBottom: '1px solid var(--border)' }}>
          <span className="semibold">{title}</span>
          <span className="text-xs text-muted row gap-6">
            <CalendarDays size={13} /> {view} view
          </span>
        </div>

        {loading ? (
          <div style={{ padding: 40 }}>
            <Loading />
          </div>
        ) : view === 'month' ? (
          <div style={{ padding: 12 }}>
            <div className="cal-grid">
              {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((d) => (
                <div key={d} className="cal-head">
                  {d}
                </div>
              ))}
              {monthCells(anchor.slice(0, 8) + '01').map((d, i) => {
                if (!d) return <div key={`e${i}`} className="month-cell other" />;
                const list = byDate[d] || [];
                return (
                  <div key={d} className={cx('month-cell', d === today && 'has-slots')} style={d === today ? { borderColor: 'var(--brand)' } : undefined}>
                    <div className="row-between">
                      <span className="text-sm semibold">{Number(d.slice(8))}</span>
                      {list.length > 0 && <span className="text-xs text-muted">{list.length}</span>}
                    </div>
                    {list.slice(0, 3).map((a) => (
                      <button key={a.id} className="month-chip" onClick={() => setSelected(a)}>
                        {minutesToTime(a.start_min)} {a.service_name}
                      </button>
                    ))}
                    {list.length > 3 && (
                      <button className="month-chip" style={{ background: 'transparent', color: 'var(--muted)' }} onClick={() => { setAnchor(d); setView('day'); }}>
                        +{list.length - 3} more
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        ) : (
          <div style={{ overflowX: 'auto' }}>
            <div className="week-grid">
              <div className="week-head" />
              {(view === 'week' ? weekDays : [anchor]).map((d) => (
                <div key={d} className={cx('week-head', d === today && 'today')}>
                  <div>{format(toDate(d), 'EEE')}</div>
                  <div style={{ fontSize: 18, fontWeight: 800 }}>{format(toDate(d), 'd')}</div>
                </div>
              ))}
              <div>
                {hours.map((h) => (
                  <div key={h} className="time-cell">
                    {h}:00
                  </div>
                ))}
              </div>
              {(view === 'week' ? weekDays : [anchor]).map((d) => (
                <div key={d} className="day-col" style={{ position: 'relative', height: hours.length * HOUR_HEIGHT }}>
                  {hours.map((h) => (
                    <div key={h} className="day-slot" style={{ height: HOUR_HEIGHT }} />
                  ))}
                  {(byDate[d] || []).map((a) => (
                    <Pill key={a.id} a={a} compact={view === 'week'} />
                  ))}
                </div>
              ))}
            </div>
          </div>
        )}
      </Card>

      <div className="grid grid-2 mt-16">
        <Card className="card-pad">
          <h3 className="mb-12">Team legend</h3>
          <div className="stack gap-8">
            {staff.map((s) => (
              <div key={s.id} className="row gap-8">
                <Avatar name={s.name} url={s.avatar_url} size="sm" color={s.color} />
                <div className="grow">
                  <div className="text-sm semibold">{s.name}</div>
                  <div className="text-xs text-muted">{s.title}</div>
                </div>
              </div>
            ))}
          </div>
        </Card>
        <Card className="card-pad">
          <h3 className="mb-12">Today at a glance</h3>
          {(byDate[today] || []).length ? (
            <div className="stack gap-8">
              {(byDate[today] || []).map((a) => (
                <div key={a.id} className="row-between">
                  <div className="row gap-8" style={{ minWidth: 0 }}>
                    <Clock size={14} color="var(--muted)" />
                    <span className="text-sm semibold">{minutesToTime(a.start_min)}</span>
                    <span className="text-sm truncate">{a.service_name}</span>
                  </div>
                  <span className="text-xs text-muted">{a.staff_name}</span>
                </div>
              ))}
            </div>
          ) : (
            <Empty title="Nothing today" />
          )}
        </Card>
      </div>

      {selected && (
        <Modal
          title={selected.service_name}
          subtitle={`${prettyDate(selected.date)} · ${minutesToTime(selected.start_min)}–${minutesToTime(selected.end_min)}`}
          onClose={() => setSelected(null)}
          footer={
            <>
              {selected.status === 'pending' && (
                <Button variant="primary" onClick={() => setStatus(selected.id, 'confirmed')}>
                  Approve
                </Button>
              )}
              {selected.status === 'confirmed' && (
                <Button variant="primary" onClick={() => setStatus(selected.id, 'completed')}>
                  Mark completed
                </Button>
              )}
              {!['cancelled', 'completed'].includes(selected.status) && (
                <Button variant="danger" onClick={() => setStatus(selected.id, 'cancelled')}>
                  Cancel booking
                </Button>
              )}
            </>
          }
        >
          <div className="stack gap-12">
            <div className="row gap-8">
              <Badge tone={STATUS_TONE[selected.status]}>{STATUS_LABEL[selected.status]}</Badge>
              <Badge tone="blue">{selected.code}</Badge>
              {selected.payment_status === 'paid' ? <Badge tone="green">Paid</Badge> : <Badge tone="amber">{selected.payment_method === 'cash' ? 'Pay on arrival' : 'Unpaid'}</Badge>}
            </div>
            <div className="kv">
              <span>Customer</span>
              <span className="semibold">{selected.customer_name}</span>
            </div>
            <div className="kv">
              <span>Contact</span>
              <span>{selected.customer_email || selected.customer_phone || '—'}</span>
            </div>
            <div className="kv">
              <span>Specialist</span>
              <span className="semibold">{selected.staff_name || 'Unassigned'}</span>
            </div>
            <div className="kv">
              <span>Duration</span>
              <span>{duration(selected.duration_min)}</span>
            </div>
            <div className="kv">
              <span>Total</span>
              <span className="semibold">{money(selected.total_cents, currency)}</span>
            </div>
            {selected.notes && (
              <div className="soft" style={{ padding: 12, borderRadius: 12 }}>
                <div className="text-xs text-muted">Notes</div>
                <div className="text-sm">{selected.notes}</div>
              </div>
            )}
          </div>
        </Modal>
      )}
    </div>
  );
}
