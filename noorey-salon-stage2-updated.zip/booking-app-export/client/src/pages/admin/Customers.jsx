import { useEffect, useState } from 'react';
import { Search, Mail, Phone, MessageSquare } from 'lucide-react';
import { api } from '../../lib/api';
import { useApp } from '../../context/AppContext';
import {
  Card, Button, Input, Modal, Badge, Loading, Empty, Avatar, Field, Textarea, Switch,
} from '../../components/ui';
import { money, prettyDate, minutesToTime, STATUS_TONE, STATUS_LABEL } from '../../lib/format';

export default function AdminCustomers() {
  const { currency, toast } = useApp();
  const [list, setList] = useState([]);
  const [q, setQ] = useState('');
  const [loading, setLoading] = useState(true);
  const [openId, setOpenId] = useState(null);

  const load = (query = q) => {
    setLoading(true);
    api('/admin/customers', { params: { q: query } })
      .then((d) => setList(d.customers))
      .finally(() => setLoading(false));
  };

  useEffect(() => load(''), []);

  return (
    <div>
      <div className="row-between wrap gap-12 mb-16">
        <div>
          <h2>Customers</h2>
          <p className="text-sm text-muted mt-4">{list.length} customers · visit history, spend and notes</p>
        </div>
        <div style={{ position: 'relative', width: 260 }}>
          <Search size={16} style={{ position: 'absolute', left: 12, top: 13, color: 'var(--muted)' }} />
          <Input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && load()}
            placeholder="Search name, email or phone…"
            style={{ paddingLeft: 34 }}
          />
        </div>
      </div>

      <Card style={{ padding: 0, overflow: 'hidden' }}>
        {loading ? (
          <div style={{ padding: 40 }}>
            <Loading />
          </div>
        ) : list.length ? (
          <div className="table-wrap">
            <table className="table">
              <thead>
                <tr>
                  <th>Customer</th>
                  <th>Contact</th>
                  <th>Visits</th>
                  <th>Spend</th>
                  <th>Last visit</th>
                  <th>Status</th>
                  <th />
                </tr>
              </thead>
              <tbody>
                {list.map((c) => (
                  <tr key={c.id} style={{ cursor: 'pointer' }} onClick={() => setOpenId(c.id)}>
                    <td>
                      <div className="row gap-8">
                        <Avatar name={c.name} url={c.avatar_url} size="sm" />
                        <div>
                          <div className="semibold">{c.name}</div>
                          <div className="text-xs text-muted">#{c.id}</div>
                        </div>
                      </div>
                    </td>
                    <td>
                      <div className="text-sm">{c.email || '—'}</div>
                      <div className="text-xs text-muted">{c.phone || '—'}</div>
                    </td>
                    <td className="semibold">{c.visits}</td>
                    <td className="semibold">{money(c.spend * 100, currency)}</td>
                    <td>{c.last_visit ? prettyDate(c.last_visit) : 'Never'}</td>
                    <td>
                      <Badge tone={c.is_active ? 'green' : 'red'}>{c.is_active ? 'Active' : 'Disabled'}</Badge>
                    </td>
                    <td>
                      <Button size="sm" variant="outline">
                        Open
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <Empty icon={Search} title="No customers found" />
        )}
      </Card>

      {openId && <CustomerModal id={openId} onClose={() => setOpenId(null)} onSaved={load} />}
    </div>
  );
}

function CustomerModal({ id, onClose, onSaved }) {
  const { currency, capabilities, toast } = useApp();
  const [data, setData] = useState(null);
  const [notes, setNotes] = useState('');
  const [isActive, setIsActive] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState({ subject: '', body: '' });

  useEffect(() => {
    api(`/admin/customers/${id}`).then((d) => {
      setData(d);
      setNotes(d.customer.notes || '');
      setIsActive(!!d.customer.is_active);
    });
  }, [id]);

  const save = async () => {
    setSaving(true);
    try {
      await api(`/admin/customers/${id}`, { method: 'PUT', body: { notes, is_active: isActive } });
      toast('Saved', 'success');
      onSaved();
    } finally {
      setSaving(false);
    }
  };

  const send = async () => {
    try {
      const res = await api('/admin/notifications', {
        method: 'POST',
        body: { userIds: [id], channel: 'email', subject: message.subject, body: message.body },
      });
      toast(res.failed ? `${res.sent} sent, ${res.failed} failed` : 'Message sent', res.failed ? 'error' : 'success');
      setMessage({ subject: '', body: '' });
    } catch (err) {
      toast(err.message, 'error');
    }
  };

  if (!data) return <Modal title="Customer" onClose={onClose}><Loading /></Modal>;

  const { customer, bookings, reviews } = data;

  return (
    <Modal title={customer.name} subtitle={customer.email || customer.phone} onClose={onClose} wide>
      <div className="grid grid-2" style={{ alignItems: 'start' }}>
        <div className="stack gap-16">
          <Card className="card-pad soft">
            <div className="grid grid-3">
              <div>
                <div className="text-xs text-muted">Visits</div>
                <div className="semibold">{bookings.length}</div>
              </div>
              <div>
                <div className="text-xs text-muted">Spend</div>
                <div className="semibold">
                  {money(bookings.filter((b) => b.status !== 'cancelled').reduce((s, b) => s + b.total_cents, 0), currency)}
                </div>
              </div>
              <div>
                <div className="text-xs text-muted">Reviews</div>
                <div className="semibold">{reviews.length}</div>
              </div>
            </div>
          </Card>

          <div>
            <h4 className="mb-8">History</h4>
            {bookings.length ? (
              <div className="stack gap-8">
                {bookings.slice(0, 12).map((b) => (
                  <div key={b.id} className="row-between" style={{ border: '1px solid var(--border)', borderRadius: 10, padding: '8px 12px' }}>
                    <div>
                      <div className="text-sm semibold">{b.service_name}</div>
                      <div className="text-xs text-muted">
                        {prettyDate(b.date)} · {minutesToTime(b.start_min)} · {b.staff_name || 'Unassigned'}
                      </div>
                    </div>
                    <div className="row gap-8">
                      <span className="text-sm">{money(b.total_cents, currency)}</span>
                      <Badge tone={STATUS_TONE[b.status]}>{STATUS_LABEL[b.status]}</Badge>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-muted">No bookings yet.</p>
            )}
          </div>
        </div>

        <div className="stack gap-16">
          <Card className="card-pad">
            <h4 className="mb-12">Internal notes</h4>
            <Field>
              <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Preferences, allergies, VIP…" />
            </Field>
            <label className="row-between mt-12">
              <span className="text-sm">Account active</span>
              <Switch checked={isActive} onChange={setIsActive} />
            </label>
            <Button variant="primary" size="sm" className="btn-block mt-12" loading={saving} onClick={save}>
              Save
            </Button>
          </Card>

          <Card className="card-pad">
            <h4 className="mb-12">Send a message</h4>
            <div className="row gap-6 mb-8 text-xs text-muted">
              <Mail size={13} /> {customer.email || 'no email'} · <Phone size={13} /> {customer.phone || 'no phone'}
            </div>
            <Field label="Subject">
              <Input value={message.subject} onChange={(e) => setMessage({ ...message, subject: e.target.value })} />
            </Field>
            <Field label="Message" className="mt-8">
              <Textarea value={message.body} onChange={(e) => setMessage({ ...message, body: e.target.value })} />
            </Field>
            <Button variant="primary" size="sm" className="btn-block mt-12" disabled={!message.body} onClick={send}>
              <MessageSquare size={14} /> Send
            </Button>
            {!capabilities?.email && (
              <p className="text-xs text-muted mt-8">No email provider configured — messages are logged to the server console.</p>
            )}
          </Card>
        </div>
      </div>
    </Modal>
  );
}
