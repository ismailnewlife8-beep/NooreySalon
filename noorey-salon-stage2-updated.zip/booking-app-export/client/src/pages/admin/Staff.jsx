import { useEffect, useState } from 'react';
import { Plus, Pencil, Trash2, Clock, CalendarOff, UserCog } from 'lucide-react';
import { api } from '../../lib/api';
import { useApp } from '../../context/AppContext';
import {
  Card, Button, Modal, Field, Input, Select, Textarea, Switch, Badge, Loading, Empty, Avatar, cx, Tabs,
} from '../../components/ui';
import { minutesToTime, timeToMinutes, todayISO, addDaysISO, prettyDate } from '../../lib/format';

const DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const COLORS = ['#9C6B3F', '#B5651D', '#C98B6B', '#8A7155', '#A3835A', '#B8935A', '#7A5740'];

const emptyStaff = { name: '', title: '', bio: '', email: '', phone: '', color: '#B8935A', is_active: true, serviceIds: [] };

export default function AdminStaff() {
  const { toast } = useApp();
  const [staff, setStaff] = useState([]);
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(null);
  const [scheduleFor, setScheduleFor] = useState(null);

  const load = () => {
    setLoading(true);
    Promise.all([api('/staff', { params: { all: '1' } }), api('/services', { params: { all: '1' } })])
      .then(([st, sv]) => {
        setStaff(st.staff);
        setServices(sv.services);
      })
      .finally(() => setLoading(false));
  };

  useEffect(load, []);

  const remove = async (s) => {
    if (!window.confirm(`Remove ${s.name} from the team?`)) return;
    await api(`/staff/${s.id}`, { method: 'DELETE' });
    toast('Staff member removed', 'success');
    load();
  };

  return (
    <div>
      <div className="row-between wrap gap-12 mb-16">
        <div>
          <h2>Staff & schedules</h2>
          <p className="text-sm text-muted mt-4">Individual working hours, breaks and time off drive real-time availability.</p>
        </div>
        <div className="row gap-8">
          <Button variant="outline" onClick={() => setScheduleFor({ id: null, name: 'Business defaults' })}>
            <Clock size={15} /> Business hours
          </Button>
          <Button variant="primary" onClick={() => setEditing({ ...emptyStaff })}>
            <Plus size={15} /> Add staff
          </Button>
        </div>
      </div>

      {loading ? (
        <Loading />
      ) : staff.length ? (
        <div className="grid grid-auto">
          {staff.map((s) => (
            <Card key={s.id} className="card-pad" style={{ opacity: s.is_active ? 1 : 0.62 }}>
              <div className="row gap-12">
                <Avatar name={s.name} url={s.avatar_url} size="lg" color={s.color} />
                <div className="grow" style={{ minWidth: 0 }}>
                  <div className="row gap-8">
                    <span className="semibold truncate">{s.name}</span>
                    {!s.is_active && <Badge tone="amber">Inactive</Badge>}
                  </div>
                  <div className="text-xs text-muted truncate">{s.title}</div>
                  <div className="text-xs text-muted mt-4 row gap-4">
                    ★ {Number(s.rating || 0).toFixed(1)}
                  </div>
                </div>
              </div>
              <p className="text-sm text-muted mt-12" style={{ minHeight: 34 }}>{s.bio}</p>
              <div className="text-xs text-muted mt-8 truncate">
                {s.services?.length ? s.services.map((x) => x.name).join(' · ') : 'No services assigned'}
              </div>
              <div className="row gap-6 mt-12">
                <Button size="sm" variant="soft" onClick={() => setScheduleFor(s)}>
                  <Clock size={13} /> Schedule
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => setEditing({ ...s, serviceIds: s.services?.map((x) => x.id) || [] })}
                >
                  <Pencil size={13} />
                </Button>
                <Button size="sm" variant="ghost" onClick={() => remove(s)}>
                  <Trash2 size={13} />
                </Button>
              </div>
            </Card>
          ))}
        </div>
      ) : (
        <Empty icon={UserCog} title="No staff yet" hint="Add your team to start publishing availability." />
      )}

      {editing && (
        <StaffModal
          initial={editing}
          services={services}
          onClose={() => setEditing(null)}
          onSaved={() => {
            setEditing(null);
            load();
          }}
        />
      )}
      {scheduleFor && <ScheduleModal staff={scheduleFor} onClose={() => setScheduleFor(null)} />}
    </div>
  );
}

function StaffModal({ initial, services, onClose, onSaved }) {
  const { toast } = useApp();
  const [form, setForm] = useState(initial);
  const [saving, setSaving] = useState(false);
  const isNew = !initial.id;

  const submit = async () => {
    setSaving(true);
    try {
      if (isNew) await api('/staff', { method: 'POST', body: form });
      else await api(`/staff/${form.id}`, { method: 'PUT', body: form });
      toast(isNew ? 'Team member added' : 'Saved', 'success');
      onSaved();
    } catch (err) {
      toast(err.message, 'error');
    } finally {
      setSaving(false);
    }
  };

  return (
    <Modal
      title={isNew ? 'Add staff member' : 'Edit staff member'}
      onClose={onClose}
      wide
      footer={
        <>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button variant="primary" loading={saving} onClick={submit}>
            {isNew ? 'Add' : 'Save changes'}
          </Button>
        </>
      }
    >
      <div className="stack gap-12">
        <div className="grid grid-2">
          <Field label="Name">
            <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          </Field>
          <Field label="Job title">
            <Input value={form.title || ''} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="Senior Stylist" />
          </Field>
          <Field label="Email">
            <Input value={form.email || ''} onChange={(e) => setForm({ ...form, email: e.target.value })} />
          </Field>
          <Field label="Phone">
            <Input value={form.phone || ''} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
          </Field>
        </div>
        <Field label="Bio">
          <Textarea value={form.bio || ''} onChange={(e) => setForm({ ...form, bio: e.target.value })} />
        </Field>
        <Field label="Colour">
          <div className="row gap-6">
            {COLORS.map((c) => (
              <button
                key={c}
                onClick={() => setForm({ ...form, color: c })}
                style={{ width: 26, height: 26, borderRadius: 8, background: c, border: form.color === c ? '3px solid var(--text)' : '1px solid var(--border)' }}
                aria-label={c}
              />
            ))}
          </div>
        </Field>
        <div>
          <div className="label mb-8">Services they can deliver</div>
          <div className="grid grid-auto-sm">
            {services.map((s) => (
              <button
                key={s.id}
                className={cx('staff-card', form.serviceIds.includes(s.id) && 'selected')}
                onClick={() =>
                  setForm((f) => ({
                    ...f,
                    serviceIds: f.serviceIds.includes(s.id) ? f.serviceIds.filter((x) => x !== s.id) : [...f.serviceIds, s.id],
                  }))
                }
              >
                <span className="dot" style={{ background: s.color, width: 10, height: 10 }} />
                <span className="grow" style={{ textAlign: 'left' }}>{s.name}</span>
                {form.serviceIds.includes(s.id) && <span style={{ color: 'var(--brand)' }}>✓</span>}
              </button>
            ))}
          </div>
        </div>
        <label className="row-between">
          <span className="text-sm">Active</span>
          <Switch checked={!!form.is_active} onChange={(v) => setForm({ ...form, is_active: v })} />
        </label>
      </div>
    </Modal>
  );
}

function ScheduleModal({ staff, onClose }) {
  const { toast } = useApp();
  const [tab, setTab] = useState('hours');
  const [hours, setHours] = useState([]);
  const [breaks, setBreaks] = useState([]);
  const [holidays, setHolidays] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const isBusiness = staff.id === null;

  useEffect(() => {
    const url = isBusiness ? '/staff/business/schedule' : `/staff/${staff.id}/schedule`;
    api(url)
      .then((d) => {
        const base = Array.from({ length: 7 }, (_, i) => ({ weekday: i, start_min: 540, end_min: 1080, is_off: false, id: null }));
        for (const h of d.working_hours) base[h.weekday] = { ...h, is_off: !!h.is_off, id: h.id };
        setHours(base);
        setBreaks(d.breaks.map((b) => ({ ...b })));
        setHolidays(d.holidays.map((h) => ({ ...h })));
      })
      .finally(() => setLoading(false));
  }, [staff.id, isBusiness]);

  const save = async () => {
    setSaving(true);
    try {
      const url = isBusiness ? '/staff/business/schedule' : `/staff/${staff.id}/schedule`;
      await api(url, {
        method: 'PUT',
        body: {
          working_hours: hours.map((h) => ({ weekday: h.weekday, start_min: Number(h.start_min), end_min: Number(h.end_min), is_off: !!h.is_off })),
          breaks: breaks.map((b) => ({ weekday: Number(b.weekday), start_min: Number(b.start_min), end_min: Number(b.end_min), label: b.label })),
          holidays: holidays.map((h) => ({ start_date: h.start_date, end_date: h.end_date, reason: h.reason })),
        },
      });
      toast('Schedule saved', 'success');
      onClose();
    } catch (err) {
      toast(err.message, 'error');
    } finally {
      setSaving(false);
    }
  };

  const updateDay = (i, patch) => setHours((h) => h.map((d, idx) => (idx === i ? { ...d, ...patch } : d)));

  return (
    <Modal
      title={`Schedule · ${staff.name}`}
      subtitle={isBusiness ? 'Used whenever a staff member has no personal rule for that weekday' : 'Overrides the business defaults'}
      onClose={onClose}
      wide
      footer={
        <>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button variant="primary" loading={saving} onClick={save}>
            Save schedule
          </Button>
        </>
      }
    >
      <Tabs
        items={[
          { value: 'hours', label: 'Working hours' },
          { value: 'breaks', label: 'Breaks' },
          { value: 'off', label: 'Time off' },
        ]}
        value={tab}
        onChange={setTab}
      />
      <div style={{ height: 16 }} />

      {loading ? (
        <Loading />
      ) : tab === 'hours' ? (
        <div className="stack gap-8">
          {hours.map((h, i) => (
            <div key={i} className="schedule-row" style={{ gridTemplateColumns: '110px 1fr 1fr 62px' }}>
              <span className="text-sm semibold">{DAYS[i].slice(0, 3)}</span>
              <Input
                type="time"
                value={minutesToTime(h.start_min)}
                disabled={h.is_off}
                onChange={(e) => updateDay(i, { start_min: timeToMinutes(e.target.value) })}
              />
              <Input
                type="time"
                value={minutesToTime(h.end_min)}
                disabled={h.is_off}
                onChange={(e) => updateDay(i, { end_min: timeToMinutes(e.target.value) })}
              />
              <label className="row gap-6" style={{ justifyContent: 'flex-end' }}>
                <span className="text-xs text-muted">Off</span>
                <Switch checked={!!h.is_off} onChange={(v) => updateDay(i, { is_off: v })} />
              </label>
            </div>
          ))}
        </div>
      ) : tab === 'breaks' ? (
        <div className="stack gap-12">
          {breaks.map((b, i) => (
            <div key={i} className="row gap-8 wrap">
              <div style={{ width: 130 }}>
                <Select value={b.weekday} onChange={(e) => setBreaks((bs) => bs.map((x, idx) => (idx === i ? { ...x, weekday: Number(e.target.value) } : x)))}>
                  {DAYS.map((d, idx) => (
                    <option key={d} value={idx}>
                      {d}
                    </option>
                  ))}
                </Select>
              </div>
              <Input type="time" value={minutesToTime(b.start_min)} style={{ width: 120 }} onChange={(e) => setBreaks((bs) => bs.map((x, idx) => (idx === i ? { ...x, start_min: timeToMinutes(e.target.value) } : x)))} />
              <Input type="time" value={minutesToTime(b.end_min)} style={{ width: 120 }} onChange={(e) => setBreaks((bs) => bs.map((x, idx) => (idx === i ? { ...x, end_min: timeToMinutes(e.target.value) } : x)))} />
              <Input value={b.label || ''} placeholder="Lunch" className="grow" style={{ minWidth: 120 }} onChange={(e) => setBreaks((bs) => bs.map((x, idx) => (idx === i ? { ...x, label: e.target.value } : x)))} />
              <Button size="sm" variant="ghost" onClick={() => setBreaks((bs) => bs.filter((_, idx) => idx !== i))}>
                <Trash2 size={14} />
              </Button>
            </div>
          ))}
          <Button
            variant="outline"
            size="sm"
            onClick={() => setBreaks((b) => [...b, { weekday: 1, start_min: 780, end_min: 840, label: 'Lunch' }])}
          >
            <Plus size={14} /> Add break
          </Button>
        </div>
      ) : (
        <div className="stack gap-12">
          {holidays.map((h, i) => (
            <div key={i} className="row gap-8 wrap">
              <Input type="date" value={h.start_date} style={{ width: 160 }} onChange={(e) => setHolidays((hs) => hs.map((x, idx) => (idx === i ? { ...x, start_date: e.target.value } : x)))} />
              <Input type="date" value={h.end_date} style={{ width: 160 }} onChange={(e) => setHolidays((hs) => hs.map((x, idx) => (idx === i ? { ...x, end_date: e.target.value } : x)))} />
              <Input value={h.reason || ''} placeholder="Reason" className="grow" style={{ minWidth: 140 }} onChange={(e) => setHolidays((hs) => hs.map((x, idx) => (idx === i ? { ...x, reason: e.target.value } : x)))} />
              <Button size="sm" variant="ghost" onClick={() => setHolidays((hs) => hs.filter((_, idx) => idx !== i))}>
                <Trash2 size={14} />
              </Button>
            </div>
          ))}
          <Button
            variant="outline"
            size="sm"
            onClick={() => setHolidays((h) => [...h, { start_date: todayISO(), end_date: addDaysISO(todayISO(), 1), reason: 'Time off' }])}
          >
            <CalendarOff size={14} /> Add time off
          </Button>
          {holidays.length > 0 && (
            <div className="stack gap-4 mt-8">
              {holidays.map((h, i) => (
                <div key={i} className="text-xs text-muted row gap-6">
                  <CalendarOff size={12} /> {prettyDate(h.start_date)} → {prettyDate(h.end_date)} · {h.reason}
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </Modal>
  );
}
