import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Mail, Smartphone, Bell, Lock, LogOut, Save, Camera, Trash2, MailCheck } from 'lucide-react';
import { api } from '../../lib/api';
import { useApp } from '../../context/AppContext';
import { Button, Card, Field, Input, Avatar, Switch, PageHead, Badge, Loading } from '../../components/ui';
import { money } from '../../lib/format';

export default function Profile() {
  const { user, setUser, currency, signOut, toast } = useApp();
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: '', email: '', phone: '', notify_email: true, notify_sms: true });
  const [pwd, setPwd] = useState({ currentPassword: '', newPassword: '' });
  const [summary, setSummary] = useState(null);
  const [saving, setSaving] = useState(false);
  const [savingPwd, setSavingPwd] = useState(false);
  const [error, setError] = useState('');
  const [photoBusy, setPhotoBusy] = useState(false);
  const fileRef = useRef(null);

  /** Resize to a 320px square JPEG in the browser so uploads stay small and fast. */
  const resizeImage = (file) =>
    new Promise((resolve, reject) => {
      const img = new Image();
      const url = URL.createObjectURL(file);
      img.onload = () => {
        const size = 320;
        const side = Math.min(img.width, img.height);
        const canvas = document.createElement('canvas');
        canvas.width = size;
        canvas.height = size;
        canvas.getContext('2d').drawImage(img, (img.width - side) / 2, (img.height - side) / 2, side, side, 0, 0, size, size);
        URL.revokeObjectURL(url);
        resolve(canvas.toDataURL('image/jpeg', 0.85));
      };
      img.onerror = () => {
        URL.revokeObjectURL(url);
        reject(new Error('Could not read that image'));
      };
      img.src = url;
    });

  const onPickPhoto = async (e) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    if (!/^image\//.test(file.type)) return toast('Please choose an image file', 'error');
    setPhotoBusy(true);
    try {
      const image = await resizeImage(file);
      const { user: updated } = await api('/profile/me/avatar', { method: 'POST', body: { image } });
      setUser(updated);
      toast('Profile photo updated', 'success');
    } catch (err) {
      toast(err.message, 'error');
    } finally {
      setPhotoBusy(false);
    }
  };

  const removePhoto = async () => {
    setPhotoBusy(true);
    try {
      const { user: updated } = await api('/profile/me/avatar', { method: 'DELETE' });
      setUser(updated);
      toast('Profile photo removed', 'success');
    } catch (err) {
      toast(err.message, 'error');
    } finally {
      setPhotoBusy(false);
    }
  };

  const resendVerification = async () => {
    try {
      await api('/auth/resend-verification', { method: 'POST' });
      toast('Confirmation email sent', 'success');
    } catch (err) {
      toast(err.message, 'error');
    }
  };

  useEffect(() => {
    if (user) setForm({ name: user.name || '', email: user.email || '', phone: user.phone || '', notify_email: !!user.notify_email, notify_sms: !!user.notify_sms });
    api('/profile/me/summary').then(setSummary).catch(() => {});
  }, [user]);

  if (!user) return <div className="page"><Loading /></div>;

  const save = async (e) => {
    e.preventDefault();
    setSaving(true);
    setError('');
    try {
      const { user: updated } = await api('/profile/me', { method: 'PUT', body: form });
      setUser(updated);
      toast('Profile updated', 'success');
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  };

  const changePassword = async (e) => {
    e.preventDefault();
    setSavingPwd(true);
    setError('');
    try {
      await api('/profile/me', { method: 'PUT', body: { currentPassword: pwd.currentPassword, newPassword: pwd.newPassword } });
      setPwd({ currentPassword: '', newPassword: '' });
      toast('Password updated', 'success');
    } catch (err) {
      setError(err.message);
    } finally {
      setSavingPwd(false);
    }
  };

  return (
    <div className="page page-narrow">
      <PageHead title="Your profile" subtitle="Keep your details current so reminders reach you." />

      <Card className="card-pad mb-16">
        <div className="row gap-16">
          <div className="stack gap-8" style={{ alignItems: 'center' }}>
            <span className="avatar avatar-xl" style={{ overflow: 'hidden' }}>
              {user.avatar_url ? <img src={user.avatar_url} alt={user.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : (user.name || '?').split(' ').map((w) => w[0]).slice(0, 2).join('').toUpperCase()}
            </span>
            <input ref={fileRef} type="file" accept="image/png,image/jpeg,image/webp" hidden onChange={onPickPhoto} />
            <div className="row gap-6">
              <Button variant="outline" size="sm" loading={photoBusy} onClick={() => fileRef.current?.click()}>
                <Camera size={14} /> {user.avatar_url ? 'Change' : 'Add photo'}
              </Button>
              {user.avatar_url && (
                <Button variant="ghost" size="sm" disabled={photoBusy} onClick={removePhoto} aria-label="Remove photo">
                  <Trash2 size={14} />
                </Button>
              )}
            </div>
          </div>
          <div className="grow">
            <div className="row gap-8">
              <h3>{user.name}</h3>
              <Badge tone={user.role === 'admin' ? 'purple' : 'blue'}>{user.role === 'admin' ? 'Administrator' : 'Customer'}</Badge>
            </div>
            <p className="text-sm text-muted mt-4">{user.email || user.phone}</p>
            {user.email && !user.email_verified && (
              <p className="text-xs mt-4" style={{ color: 'var(--amber)' }}>
                Email not confirmed yet.{' '}
                <button type="button" className="link-btn" onClick={resendVerification}>
                  <MailCheck size={12} /> Resend link
                </button>
              </p>
            )}
          </div>
          <Button variant="outline" onClick={() => { signOut(); navigate('/'); }}>
            <LogOut size={15} /> Sign out
          </Button>
        </div>
      </Card>

      {summary && (
        <div className="grid grid-4 mb-16">
          <Card className="card-pad center">
            <div className="stat-value">{summary.total}</div>
            <div className="text-xs text-muted">Bookings</div>
          </Card>
          <Card className="card-pad center">
            <div className="stat-value">{summary.upcoming}</div>
            <div className="text-xs text-muted">Upcoming</div>
          </Card>
          <Card className="card-pad center">
            <div className="stat-value">{summary.completed}</div>
            <div className="text-xs text-muted">Completed</div>
          </Card>
          <Card className="card-pad center">
            <div className="stat-value">{money(summary.lifetime_cents, currency).replace(/\.00$/, '')}</div>
            <div className="text-xs text-muted">Lifetime value</div>
          </Card>
        </div>
      )}

      <Card className="card-pad mb-16">
        <h3 className="mb-12">Contact details</h3>
        <form className="stack gap-12" onSubmit={save}>
          <div className="grid grid-2">
            <Field label="Full name">
              <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
            </Field>
            <Field label="Phone">
              <div style={{ position: 'relative' }}>
                <Smartphone size={15} style={{ position: 'absolute', left: 12, top: 13, color: 'var(--muted)' }} />
                <Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} style={{ paddingLeft: 34 }} />
              </div>
            </Field>
          </div>
          <Field label="Email">
            <div style={{ position: 'relative' }}>
              <Mail size={15} style={{ position: 'absolute', left: 12, top: 13, color: 'var(--muted)' }} />
              <Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} style={{ paddingLeft: 34 }} />
            </div>
          </Field>

          <div className="divider" />
          <div className="row gap-8">
            <Bell size={16} color="var(--muted)" />
            <span className="semibold">Reminders</span>
          </div>
          <label className="row-between">
            <span className="text-sm">Email reminders & confirmations</span>
            <Switch checked={form.notify_email} onChange={(v) => setForm({ ...form, notify_email: v })} />
          </label>
          <label className="row-between">
            <span className="text-sm">SMS reminders</span>
            <Switch checked={form.notify_sms} onChange={(v) => setForm({ ...form, notify_sms: v })} />
          </label>

          {error && <div className="field-error">{error}</div>}
          <div>
            <Button type="submit" variant="primary" loading={saving}>
              <Save size={15} /> Save changes
            </Button>
          </div>
        </form>
      </Card>

      <Card className="card-pad">
        <h3 className="mb-12">Password</h3>
        <form className="stack gap-12" onSubmit={changePassword}>
          <div className="grid grid-2">
            <Field label="Current password">
              <Input type="password" value={pwd.currentPassword} onChange={(e) => setPwd({ ...pwd, currentPassword: e.target.value })} />
            </Field>
            <Field label="New password" hint="At least 8 characters">
              <Input type="password" value={pwd.newPassword} onChange={(e) => setPwd({ ...pwd, newPassword: e.target.value })} />
            </Field>
          </div>
          <div>
            <Button type="submit" variant="outline" loading={savingPwd} disabled={!pwd.newPassword}>
              <Lock size={15} /> Update password
            </Button>
          </div>
        </form>
      </Card>
    </div>
  );
}
