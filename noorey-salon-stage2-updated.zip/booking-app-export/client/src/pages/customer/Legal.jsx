import { useApp } from '../../context/AppContext';

export function Privacy() {
  const { business } = useApp();
  const name = business?.business_name || 'Noorey Salon';
  return (
    <div className="page page-narrow legal">
      <span className="eyebrow">Legal</span>
      <h1 style={{ fontSize: 44 }}>Privacy policy</h1>
      <p>{name} (“we”, “us”) respects your privacy. This page explains what we collect when you use our online booking website and how we use it.</p>
      <h2>What we collect</h2>
      <ul>
        <li>Your name, email address and phone number when you create an account or make a booking.</li>
        <li>Your booking history, notes you add to a booking, and reviews you write.</li>
        <li>An optional profile photo, if you upload one.</li>
        <li>Your password is stored only as a one-way encrypted hash. We cannot see it.</li>
      </ul>
      <h2>How we use it</h2>
      <p>We use your details to confirm and manage your appointments, send reminders, respond to your messages and improve our service. We do not sell your information.</p>
      <h2>Payments</h2>
      <p>Payment is currently made at the salon. This website does not collect or store card or bank details.</p>
      <h2>Your choices</h2>
      <p>You can update your details or turn reminders off from your profile at any time. To delete your account, contact us at {business?.email}.</p>
      <h2>Contact</h2>
      <p>{name}, {business?.address}. {business?.phone} · {business?.email}</p>
    </div>
  );
}

export function Terms() {
  const { business, policy } = useApp();
  const hrs = policy?.cancellation_hours ?? 12;
  return (
    <div className="page page-narrow legal">
      <span className="eyebrow">Legal</span>
      <h1 style={{ fontSize: 44 }}>Terms &amp; cancellation</h1>
      <h2>Bookings</h2>
      <p>Appointments are subject to availability. Please arrive a few minutes early; late arrivals may need a shorter service or a new slot.</p>
      <h2>Cancellation &amp; rescheduling</h2>
      <p>You can cancel or reschedule free of charge up to {hrs} hours before your appointment from the “My bookings” page. For changes inside that window please call us on {business?.phone}.</p>
      <h2>Pricing &amp; payment</h2>
      <p>Prices shown are in {business?.currency || 'PKR'} and may vary with hair length or thickness, which your stylist will confirm before starting. Payment is taken at the salon.</p>
      <h2>No-shows</h2>
      <p>Repeated missed appointments without notice may limit future online booking.</p>
    </div>
  );
}
