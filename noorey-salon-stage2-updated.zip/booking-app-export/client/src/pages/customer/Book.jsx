import { useEffect, useMemo, useState } from 'react';
import { useNavigate, useParams, useLocation } from 'react-router-dom';
import { Check, Clock, Wallet, Tag, ChevronLeft, ChevronRight, CalendarX2, Info, Sparkles, PartyPopper, NotebookPen } from 'lucide-react';
import { api } from '../../lib/api';
import { useApp } from '../../context/AppContext';
import { Button, Card, Avatar, Badge, Loading, Empty, Input, Textarea, Media, cx, Spinner } from '../../components/ui';
import { money, duration, minutesToTime, prettyDate, longDate, todayISO, addDaysISO, toDate } from '../../lib/format';
import { format } from 'date-fns';

// Three steps: pick a service (skipped when you arrive from a service page), pick a time, confirm.
const STEPS = ['Service', 'Date & time', 'Confirm'];
const LAST_STEP = STEPS.length - 1;
const STORAGE_KEY = 'booking_draft';
const WEEKDAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

function monthCells(monthStart) {
  const first = toDate(monthStart);
  const year = first.getUTCFullYear();
  const month = first.getUTCMonth();
  const startIdx = Math.floor(Date.UTC(year, month, 1) / 86400000);
  const offset = new Date(Date.UTC(year, month, 1)).getUTCDay();
  const daysInMonth = new Date(Date.UTC(year, month + 1, 0)).getUTCDate();
  const cells = Array(offset).fill(null);
  for (let d = 1; d <= daysInMonth; d += 1) {
    cells.push(new Date((startIdx + d - 1) * 86400000).toISOString().slice(0, 10));
  }
  while (cells.length % 7 !== 0) cells.push(null);
  return cells;
}

export default function Book() {
  const { serviceId: paramServiceId } = useParams();
  const { user, currency, policy, toast } = useApp();
  const navigate = useNavigate();
  const location = useLocation();
  const fromService = paramServiceId ? Number(paramServiceId) : null;

  const [step, setStep] = useState(fromService ? 1 : 0);
  const [services, setServices] = useState([]);
  const [serviceId, setServiceId] = useState(fromService);
  const [staffId, setStaffId] = useState(null); // null = any available specialist
  const [date, setDate] = useState(null);
  const [startMin, setStartMin] = useState(null);
  const [monthStart, setMonthStart] = useState(() => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-01`;
  });
  const [category, setCategory] = useState('All');

  const [availability, setAvailability] = useState(null);
  const [rangeDays, setRangeDays] = useState([]);
  const [loadingSlots, setLoadingSlots] = useState(false);

  const [notes, setNotes] = useState('');
  const [showNotes, setShowNotes] = useState(false);
  const [showCoupon, setShowCoupon] = useState(false);
  const [coupon, setCoupon] = useState('');
  const [couponInfo, setCouponInfo] = useState(null);
  const [couponError, setCouponError] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [booking, setBooking] = useState(null);
  const [booting, setBooting] = useState(true);

  const service = useMemo(() => services.find((s) => s.id === serviceId) || null, [services, serviceId]);
  const today = todayISO();
  const maxDate = addDaysISO(today, Number(policy?.max_advance_days || 60));

  // load services + restore an in-progress selection (e.g. after signing in)
  useEffect(() => {
    api('/services')
      .then((d) => {
        setServices(d.services);
        let draft = null;
        try {
          draft = JSON.parse(sessionStorage.getItem(STORAGE_KEY) || 'null');
        } catch {
          draft = null;
        }
        // a draft only applies when it is for the same service we arrived with (or none was given)
        if (draft?.serviceId && (!fromService || draft.serviceId === fromService)) {
          setServiceId(draft.serviceId);
          setStaffId(draft.staffId || null);
          if (draft.date) setDate(draft.date);
          if (draft.startMin !== null && draft.startMin !== undefined) setStartMin(draft.startMin);
          const wanted = Math.min(Number(draft.step) || 0, LAST_STEP);
          setStep(wanted === LAST_STEP && (!draft.date || draft.startMin == null) ? 1 : Math.max(wanted, 1));
        }
      })
      .finally(() => setBooting(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!serviceId) return;
    sessionStorage.setItem(STORAGE_KEY, JSON.stringify({ serviceId, staffId, date, startMin, step }));
  }, [serviceId, staffId, date, startMin, step]);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [step]);

  // an unknown / hidden service id in the URL falls back to the service list
  useEffect(() => {
    if (!booting && serviceId && !services.some((s) => s.id === serviceId)) {
      setServiceId(null);
      setStep(0);
    }
  }, [booting, services, serviceId]);

  // availability for the selected day + a per-day summary for the visible month
  useEffect(() => {
    if (!serviceId || !date) {
      setAvailability(null);
      return;
    }
    setLoadingSlots(true);
    api('/availability', { params: { serviceId, date, staffId: staffId || '' } })
      .then(setAvailability)
      .catch(() => setAvailability(null))
      .finally(() => setLoadingSlots(false));
  }, [serviceId, date, staffId]);

  useEffect(() => {
    if (!serviceId) return;
    const cells = monthCells(monthStart).filter(Boolean);
    api('/availability/range', { params: { serviceId, from: cells[0], to: cells[cells.length - 1], staffId: staffId || '' } })
      .then((d) => setRangeDays(d.days))
      .catch(() => setRangeDays([]));
  }, [serviceId, monthStart, staffId]);

  const dayCount = useMemo(() => Object.fromEntries(rangeDays.map((d) => [d.date, d])), [rangeDays]);

  // fewer clicks: open the first day that has free slots, so times are visible straight away
  useEffect(() => {
    if (step !== 1 || date || !rangeDays.length) return;
    const first = rangeDays.find((d) => d.count > 0 && !d.closed && d.date >= today && d.date <= maxDate);
    if (first) setDate(first.date);
  }, [step, date, rangeDays, today, maxDate]);

  const groupedSlots = useMemo(() => {
    const slots = availability?.slots || [];
    return {
      Morning: slots.filter((s) => s.start < 720),
      Afternoon: slots.filter((s) => s.start >= 720 && s.start < 1020),
      Evening: slots.filter((s) => s.start >= 1020),
    };
  }, [availability]);

  const price = service?.price_cents || 0;
  const discount = couponInfo?.discount_cents || 0;
  const tax = Math.round(((price - discount) * Number(policy?.tax_percent || 0)) / 100);
  const total = Math.max(0, price - discount + tax);
  const staffName = staffId ? service?.staff?.find((s) => s.id === staffId)?.name : 'Any available specialist';

  const pickService = (s) => {
    if (s.id !== serviceId) {
      setServiceId(s.id);
      setStaffId(null);
      setDate(null);
      setStartMin(null);
      setCouponInfo(null);
    }
    setStep(1); // one tap moves on
  };

  const pickStaff = (id) => {
    setStaffId(id);
    setStartMin(null);
  };

  const pickSlot = (s) => {
    setStartMin(s.start);
    setStep(LAST_STEP); // one tap moves on to the confirmation
  };

  const applyCoupon = async () => {
    setCouponError('');
    setCouponInfo(null);
    if (!coupon.trim()) return;
    try {
      const res = await api('/coupons/validate', { method: 'POST', body: { code: coupon, serviceId, amountCents: price } });
      setCouponInfo(res);
      toast(`Promo applied — ${money(res.discount_cents, currency)} off`, 'success');
    } catch (err) {
      setCouponError(err.message);
    }
  };

  const submit = async () => {
    if (!user) {
      navigate('/login', { state: { from: location.pathname } });
      return;
    }
    setSubmitting(true);
    try {
      const res = await api('/bookings', {
        method: 'POST',
        body: {
          serviceId,
          staffId: staffId || null,
          date,
          startMin,
          paymentMethod: 'cash', // pay at the salon; online card payment is not enabled yet
          couponCode: couponInfo ? coupon : null,
          notes: notes.trim() || null,
        },
      });
      setBooking(res.booking);
      sessionStorage.removeItem(STORAGE_KEY);
      toast('Booking confirmed', 'success');
    } catch (err) {
      toast(err.message, 'error');
    } finally {
      setSubmitting(false);
    }
  };

  if (booting) return <div className="page"><Loading /></div>;

  // ---------------------------------------------------------------- success
  if (booking) {
    return (
      <div className="page page-narrow">
        <Card className="card-pad center" style={{ padding: 36 }}>
          <span className="brand-mark" style={{ width: 56, height: 56, borderRadius: '50%', margin: '0 auto', color: 'var(--gold-soft)' }}>
            <PartyPopper size={26} />
          </span>
          <h2 className="mt-16">You’re booked</h2>
          <p className="text-muted mt-8">
            {longDate(booking.date)} at {minutesToTime(booking.start_min)}
            {booking.staff_name ? ` with ${booking.staff_name}` : ''}
          </p>
          <div className="mt-16">
            <Badge tone="blue">Code {booking.code}</Badge>
          </div>
          <div className="grid grid-2 mt-24" style={{ textAlign: 'left' }}>
            <div className="kv"><span>Service</span><span className="semibold">{booking.service_name}</span></div>
            <div className="kv"><span>Duration</span><span className="semibold">{duration(booking.duration_min)}</span></div>
            <div className="kv"><span>Total</span><span className="semibold">{money(booking.total_cents, currency)}</span></div>
            <div className="kv"><span>Payment</span><span className="semibold">Pay at the salon</span></div>
          </div>
          <div className="row gap-8 wrap mt-24" style={{ justifyContent: 'center' }}>
            <Button variant="primary" onClick={() => navigate(`/bookings/${booking.id}`)}>View booking</Button>
            <Button variant="outline" onClick={() => navigate('/services')}>Book another</Button>
          </div>
        </Card>
      </div>
    );
  }

  const categories = ['All', ...new Set(services.map((s) => s.category))];
  const visibleServices = category === 'All' ? services : services.filter((s) => s.category === category);
  const cells = monthCells(monthStart);
  const selectedSlot = availability?.slots?.find((s) => s.start === startMin);

  const confirmLabel = user ? 'Confirm booking' : 'Sign in & confirm';

  return (
    <div className="page">
      <div className="stepper mb-24">
        {STEPS.map((label, i) => (
          <div key={label} className="row gap-6">
            <button
              type="button"
              className={cx('step', i === step && 'active', i < step && 'done')}
              disabled={i >= step}
              onClick={() => setStep(i)}
              style={{ background: 'none', border: 'none', padding: 0, cursor: i < step ? 'pointer' : 'default' }}
            >
              <span className="step-num">{i < step ? <Check size={14} /> : i + 1}</span>
              <span>{label}</span>
            </button>
            {i < STEPS.length - 1 && <span className="step-line" />}
          </div>
        ))}
      </div>

      <div className={cx('grid', step > 0 ? 'split-book' : '')} style={step === 0 ? undefined : { alignItems: 'start' }}>
        {/* ------------------------------------------------ main column */}
        <div className="stack gap-16" style={{ minWidth: 0 }}>
          {step === 0 && (
            <Card className="card-pad">
              <h3>Choose a service</h3>
              <p className="text-sm text-muted mt-4 mb-16">Tap a treatment to continue. Prices and durations are fixed up front.</p>
              <div className="chip-row mb-16">
                {categories.map((c) => (
                  <button key={c} className={cx('chip', category === c && 'active')} onClick={() => setCategory(c)}>
                    {c}
                  </button>
                ))}
              </div>
              <div className="stack gap-8">
                {visibleServices.map((s) => (
                  <button key={s.id} className={cx('svc-row', serviceId === s.id && 'selected')} onClick={() => pickService(s)}>
                    <Media url={s.image_url} name={s.name} category={s.category} className="svc-thumb" />
                    <div className="grow" style={{ textAlign: 'left', minWidth: 0 }}>
                      <div className="semibold">{s.name}</div>
                      <div className="text-xs text-muted">
                        {s.category} · {duration(s.duration_min)}
                      </div>
                    </div>
                    <span className="price" style={{ fontSize: 16 }}>{money(s.price_cents, currency)}</span>
                    <ChevronRight size={16} color="var(--muted-2)" />
                  </button>
                ))}
              </div>
            </Card>
          )}

          {step === 1 && service && (
            <>
              <Card className="card-pad">
                <div className="row gap-12">
                  <Media url={service.image_url} name={service.name} category={service.category} className="svc-thumb" />
                  <div className="grow" style={{ minWidth: 0 }}>
                    <div className="semibold">{service.name}</div>
                    <div className="text-xs text-muted">
                      {duration(service.duration_min)} · {money(service.price_cents, currency)}
                    </div>
                  </div>
                  <button className="link-btn" onClick={() => setStep(0)}>Change</button>
                </div>
                <div className="divider" />
                <div className="label mb-8">Specialist</div>
                <div className="chip-row">
                  <button className={cx('chip chip-staff', staffId === null && 'active')} onClick={() => pickStaff(null)}>
                    <Sparkles size={14} /> Any available
                  </button>
                  {service.staff?.map((s) => (
                    <button key={s.id} className={cx('chip chip-staff', staffId === s.id && 'active')} onClick={() => pickStaff(s.id)}>
                      <Avatar name={s.name} url={s.avatar_url} size="sm" />
                      {s.name.split(' ')[0]}
                    </button>
                  ))}
                </div>
              </Card>

              <Card className="card-pad">
                <div className="row-between mb-12">
                  <h3>Pick a date</h3>
                  <div className="row gap-4">
                    <button
                      className="icon-btn"
                      onClick={() => {
                        const d = toDate(monthStart);
                        d.setUTCMonth(d.getUTCMonth() - 1);
                        setMonthStart(d.toISOString().slice(0, 10));
                      }}
                      aria-label="Previous month"
                    >
                      <ChevronLeft size={18} />
                    </button>
                    <span className="text-sm semibold" style={{ minWidth: 118, textAlign: 'center' }}>
                      {format(toDate(monthStart), 'MMMM yyyy')}
                    </span>
                    <button
                      className="icon-btn"
                      onClick={() => {
                        const d = toDate(monthStart);
                        d.setUTCMonth(d.getUTCMonth() + 1);
                        setMonthStart(d.toISOString().slice(0, 10));
                      }}
                      aria-label="Next month"
                    >
                      <ChevronRight size={18} />
                    </button>
                  </div>
                </div>
                <div className="cal-grid">
                  {WEEKDAYS.map((w) => (
                    <div key={w} className="cal-head">{w}</div>
                  ))}
                  {cells.map((d, i) => {
                    if (!d) return <span key={`e${i}`} />;
                    const info = dayCount[d];
                    const disabled = d < today || d > maxDate || (info && info.closed);
                    return (
                      <button
                        key={d}
                        className={cx('cal-day', date === d && 'selected', info && info.count > 0 && !disabled && 'has-slots')}
                        disabled={disabled}
                        onClick={() => {
                          setDate(d);
                          setStartMin(null);
                        }}
                      >
                        {Number(d.slice(8))}
                        {info && info.count > 0 && !disabled && <span className="dot" />}
                      </button>
                    );
                  })}
                </div>
                <p className="text-xs text-muted mt-12 row gap-6">
                  <Info size={13} /> Dots show days with free slots. Book up to {policy?.max_advance_days || 60} days ahead, with at least {policy?.min_lead_hours || 2}h notice.
                </p>
              </Card>

              <Card className="card-pad">
                <div className="row-between">
                  <h3>Choose a time</h3>
                  {date && <span className="text-sm text-muted">{prettyDate(date)}</span>}
                </div>
                {!date ? (
                  <Empty icon={Clock} title="Select a date first" hint="Free slots for that day will appear here." />
                ) : loadingSlots ? (
                  <div className="center" style={{ padding: 28 }}><Spinner /></div>
                ) : availability?.closed ? (
                  <Empty icon={CalendarX2} title="Closed on this day" hint={availability.reason || 'Try another date.'} />
                ) : (
                  Object.entries(groupedSlots).map(([label, slots]) =>
                    slots.length ? (
                      <div key={label}>
                        <div className="slot-group-title">
                          {label} · {slots.filter((s) => s.available).length} free
                        </div>
                        <div className="slots">
                          {slots.map((s) => (
                            <button
                              key={s.start}
                              className={cx('slot', startMin === s.start && 'selected')}
                              disabled={!s.available}
                              title={s.reason || ''}
                              onClick={() => pickSlot(s)}
                            >
                              {s.time}
                            </button>
                          ))}
                        </div>
                      </div>
                    ) : null
                  )
                )}
              </Card>
            </>
          )}

          {step === LAST_STEP && service && (
            <>
              <Card className="card-pad">
                <h3>Review &amp; confirm</h3>
                <div className="row gap-12 mt-16">
                  <Media url={service.image_url} name={service.name} category={service.category} className="svc-thumb" />
                  <div className="grow" style={{ minWidth: 0 }}>
                    <div className="semibold">{service.name}</div>
                    <div className="text-xs text-muted">{duration(service.duration_min)}</div>
                  </div>
                  <span className="price">{money(service.price_cents, currency)}</span>
                </div>
                <div className="divider" />
                <div className="kv"><span>Date</span><span className="semibold">{date ? longDate(date) : '—'}</span></div>
                <div className="kv">
                  <span>Time</span>
                  <span className="semibold">
                    {startMin !== null ? `${minutesToTime(startMin)} – ${minutesToTime(startMin + service.duration_min)}` : '—'}
                  </span>
                </div>
                <div className="kv">
                  <span>Specialist</span>
                  <span className="semibold">
                    {staffName}
                    {staffId === null && selectedSlot?.staffIds?.length > 1 ? ` (${selectedSlot.staffIds.length} free)` : ''}
                  </span>
                </div>
                <div className="kv">
                  <span>Booking for</span>
                  <span className="semibold">{user ? `${user.name}` : 'Sign in on confirm'}</span>
                </div>
                <button className="link-btn mt-12" onClick={() => setStep(1)}>Change date, time or specialist</button>
              </Card>

              <Card className="card-pad">
                <div className="row gap-12">
                  <span className="brand-mark" style={{ background: 'var(--brand-50)', color: 'var(--gold)', boxShadow: 'none' }}>
                    <Wallet size={17} />
                  </span>
                  <div className="grow">
                    <div className="semibold">Pay at the salon</div>
                    <div className="text-xs text-muted">Nothing to pay online. Settle the bill after your visit.</div>
                  </div>
                  <Check size={18} color="var(--green)" />
                </div>
              </Card>

              <Card className="card-pad">
                <div className="stack gap-12">
                  {!showNotes ? (
                    <button className="link-btn row gap-6" onClick={() => setShowNotes(true)}>
                      <NotebookPen size={14} /> Add a note for the team (optional)
                    </button>
                  ) : (
                    <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Allergies, preferences, anything we should know…" />
                  )}
                  {!showCoupon ? (
                    <button className="link-btn row gap-6" onClick={() => setShowCoupon(true)}>
                      <Tag size={14} /> Have a promo code?
                    </button>
                  ) : (
                    <div>
                      <div className="row gap-6">
                        <div className="grow">
                          <Input value={coupon} onChange={(e) => setCoupon(e.target.value.toUpperCase())} placeholder="Promo code" />
                        </div>
                        <Button variant="outline" onClick={applyCoupon}>Apply</Button>
                      </div>
                      {couponError && <div className="field-error mt-4">{couponError}</div>}
                      {couponInfo && <div className="text-xs mt-4" style={{ color: 'var(--green)' }}>{money(couponInfo.discount_cents, currency)} off applied</div>}
                    </div>
                  )}
                </div>
              </Card>
            </>
          )}
        </div>

        {/* ------------------------------------------------ summary */}
        {step > 0 && (
          <div>
            <Card className="card-pad sticky-card">
              <h4>Booking summary</h4>
              <div className="mt-12 stack gap-12">
                <div>
                  <div className="text-xs text-muted">Service</div>
                  <div className="semibold">{service?.name || 'Not selected'}</div>
                  {service && <div className="text-xs text-muted">{duration(service.duration_min)}</div>}
                </div>
                <div>
                  <div className="text-xs text-muted">Specialist</div>
                  <div className="semibold">{staffName}</div>
                </div>
                <div>
                  <div className="text-xs text-muted">Date &amp; time</div>
                  <div className="semibold">
                    {date ? `${prettyDate(date)}${startMin !== null ? ` · ${minutesToTime(startMin)}` : ''}` : 'Not selected'}
                  </div>
                </div>
              </div>

              <div className="divider" />
              <div className="kv"><span>Subtotal</span><span>{money(price, currency)}</span></div>
              {discount > 0 && (
                <div className="kv">
                  <span>Discount {couponInfo?.code && `(${couponInfo.code})`}</span>
                  <span style={{ color: 'var(--green)' }}>−{money(discount, currency)}</span>
                </div>
              )}
              {tax > 0 && (
                <div className="kv"><span>Tax ({policy?.tax_percent}%)</span><span>{money(tax, currency)}</span></div>
              )}
              <div className="kv"><span className="semibold">Total, pay at salon</span><span className="semibold">{money(total, currency)}</span></div>

              {step === LAST_STEP ? (
                <Button variant="primary" size="lg" className="btn-block mt-16 only-desktop" loading={submitting} disabled={date === null || startMin === null} onClick={submit}>
                  {confirmLabel}
                </Button>
              ) : (
                <p className="text-xs text-muted mt-12">Tap a time to continue.</p>
              )}
              <p className="text-xs text-muted mt-8 center">
                Free cancellation up to {policy?.cancellation_hours || 12}h before your slot.
              </p>
            </Card>
          </div>
        )}
      </div>

      {step === LAST_STEP && service && (
        <div className="book-bar only-mobile">
          <div>
            <div className="text-xs text-muted">Total, pay at salon</div>
            <div className="price">{money(total, currency)}</div>
          </div>
          <Button variant="primary" size="lg" loading={submitting} disabled={date === null || startMin === null} onClick={submit}>
            {confirmLabel}
          </Button>
        </div>
      )}
    </div>
  );
}
