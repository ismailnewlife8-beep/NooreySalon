import { useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Search, SlidersHorizontal } from 'lucide-react';
import { api } from '../../lib/api';
import { useApp } from '../../context/AppContext';
import { Input, Loading, Empty, Select, cx } from '../../components/ui';
import ServiceCard from '../../components/ServiceCard';

const SORTS = [
  { value: 'popular', label: 'Most popular' },
  { value: 'price-asc', label: 'Price: low to high' },
  { value: 'price-desc', label: 'Price: high to low' },
  { value: 'duration', label: 'Shortest first' },
];

export default function Services() {
  const { currency } = useApp();
  const [params, setParams] = useSearchParams();
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState(params.get('q') || '');
  const [category, setCategory] = useState('All');
  const [sort, setSort] = useState('popular');

  useEffect(() => {
    api('/services').then((d) => setServices(d.services)).finally(() => setLoading(false));
  }, []);

  const categories = useMemo(() => ['All', ...new Set(services.map((s) => s.category))], [services]);

  const filtered = useMemo(() => {
    let list = services;
    if (category !== 'All') list = list.filter((s) => s.category === category);
    const needle = q.trim().toLowerCase();
    if (needle) {
      list = list.filter(
        (s) => s.name.toLowerCase().includes(needle) || (s.description || '').toLowerCase().includes(needle) || s.category.toLowerCase().includes(needle)
      );
    }
    const arr = [...list];
    if (sort === 'price-asc') arr.sort((a, b) => a.price_cents - b.price_cents);
    if (sort === 'price-desc') arr.sort((a, b) => b.price_cents - a.price_cents);
    if (sort === 'duration') arr.sort((a, b) => a.duration_min - b.duration_min);
    if (sort === 'popular') arr.sort((a, b) => b.review_count - a.review_count || a.sort_order - b.sort_order);
    return arr;
  }, [services, category, q, sort]);

  return (
    <div className="page">
      <div className="section-head">
        <div>
          <h2>Our services</h2>
          <p className="text-sm text-muted mt-4">{services.length} treatments · transparent pricing, no surprises.</p>
        </div>
      </div>

      <div className="row gap-12 wrap mb-16">
        <div style={{ position: 'relative', flex: 1, minWidth: 240 }}>
          <Search size={16} style={{ position: 'absolute', left: 12, top: 13, color: 'var(--muted)' }} />
          <Input
            value={q}
            onChange={(e) => {
              setQ(e.target.value);
              const next = new URLSearchParams(params);
              if (e.target.value) next.set('q', e.target.value);
              else next.delete('q');
              setParams(next, { replace: true });
            }}
            placeholder="Search services…"
            style={{ paddingLeft: 34 }}
          />
        </div>
        <div style={{ width: 200 }}>
          <Select value={sort} onChange={(e) => setSort(e.target.value)}>
            {SORTS.map((s) => (
              <option key={s.value} value={s.value}>
                {s.label}
              </option>
            ))}
          </Select>
        </div>
      </div>

      <div className="chip-row mb-24">
        {categories.map((c) => (
          <button key={c} className={cx('chip', category === c && 'active')} onClick={() => setCategory(c)}>
            {c}
          </button>
        ))}
      </div>

      {loading ? (
        <Loading />
      ) : filtered.length ? (
        <div className="grid grid-auto">
          {filtered.map((s) => (
            <ServiceCard key={s.id} service={s} currency={currency} />
          ))}
        </div>
      ) : (
        <Empty
          icon={SlidersHorizontal}
          title="No services match those filters"
          hint="Try clearing the search or picking another category."
        />
      )}
    </div>
  );
}
