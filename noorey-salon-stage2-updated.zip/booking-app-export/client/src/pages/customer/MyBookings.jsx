import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { CalendarPlus, Star, CalendarClock, History } from 'lucide-react';
import { api } from '../../lib/api';
import { useApp } from '../../context/AppContext';
import { Button, Card, Tabs, Loading, Empty, PageHead, Stat } from '../../components/ui';
import BookingCard from '../../components/BookingCard';

const TABS = [
  { value: 'upcoming', label: 'Upcoming' },
  { value: 'past', label: 'History' },
];

export default function MyBookings() {
  const { user, currency, toast } = useApp();
  const navigate = useNavigate();
  const [tab, setTab] = useState('upcoming');
  const [list, setList] = useState([]);
  const [summary, setSummary] = useState(null);
  const [loading, setLoading] = useState(true);

  const load = (scope) => {
    setLoading(true);
    api('/bookings/mine', { params: { scope } })
      .then((d) => setList(d.bookings))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    load(tab);
    api('/profile/me/summary').then(setSummary).catch(() => {});
  }, [tab]);

  const cancel = async (b) => {
    if (!window.confirm(`Cancel ${b.service_name} on ${b.date}?`)) return;
    try {
      await api(`/bookings/${b.id}/cancel`, { method: 'POST', body: { reason: 'Cancelled by customer' } });
      toast('Booking cancelled', 'success');
      load(tab);
    } catch (err) {
      toast(err.message, 'error');
    }
  };

  return (
    <div className="page">
      <PageHead
        title="My bookings"
        subtitle={`Signed in as ${user?.email || user?.phone}`}
        actions={
          <Button variant="primary" onClick={() => navigate('/services')}>
            <CalendarPlus size={15} /> New booking
          </Button>
        }
      />

      <div className="grid grid-4 mb-24">
        <Stat label="Upcoming" value={summary?.upcoming ?? '—'} icon={CalendarClock} />
        <Stat label="Completed" value={summary?.completed ?? '—'} icon={History} tone="green" />
        <Stat label="Cancelled" value={summary?.cancelled ?? '—'} icon={CalendarClock} tone="amber" />
        <Stat label="Lifetime spend" value={summary ? `${currency}${(summary.lifetime_cents / 100).toFixed(0)}` : '—'} icon={Star} />
      </div>

      <div className="row-between mb-16">
        <Tabs items={TABS} value={tab} onChange={setTab} />
        <span className="text-sm text-muted">{list.length} booking{list.length === 1 ? '' : 's'}</span>
      </div>

      {loading ? (
        <Loading />
      ) : list.length ? (
        <div className="stack gap-12">
          {list.map((b) => (
            <BookingCard key={b.id} booking={b} currency={currency} onOpen={() => navigate(`/bookings/${b.id}`)}>
              {tab === 'upcoming' && (
                <>
                  <Button variant="outline" size="sm" onClick={() => navigate(`/bookings/${b.id}?reschedule=1`)}>
                    Reschedule
                  </Button>
                  <Button variant="danger" size="sm" onClick={() => cancel(b)}>
                    Cancel
                  </Button>
                </>
              )}
              {tab === 'past' && b.status === 'completed' && !b.review_id && (
                <Button variant="soft" size="sm" onClick={() => navigate(`/bookings/${b.id}?review=1`)}>
                  <Star size={13} /> Review
                </Button>
              )}
            </BookingCard>
          ))}
        </div>
      ) : (
        <Card className="card-pad">
          <Empty
            icon={tab === 'upcoming' ? CalendarClock : History}
            title={tab === 'upcoming' ? 'No upcoming appointments' : 'No past appointments yet'}
            hint={tab === 'upcoming' ? 'Book something nice for yourself — it takes a minute.' : 'Your completed visits will show up here.'}
            action={<Button variant="primary" onClick={() => navigate('/services')}>Browse services</Button>}
          />
        </Card>
      )}
    </div>
  );
}
