import { useEffect, useMemo, useState } from 'react';
import { useParams, useNavigate, useSearchParams } from 'react-router-dom';
import {
  ArrowLeft, Clock, User, CreditCard, CalendarClock, XCircle, Star, Info, Hash, Wallet,
} from 'lucide-react';
import { api } from '../../lib/api';
import { useApp } from '../../context/AppContext';
import {
  Button, Card, Badge, Loading, Empty, Modal, Avatar, Field, Textarea, StarInput, Confirm, cx, Tabs, Spinner,
} from '../../components/ui';
import {
  money, duration, minutesToTime, longDate, todayISO, addDaysISO, toDate, prettyDate,
  STATUS_LABEL, STATUS_TONE,
} from '../../lib/format';
import { format } from 'date-fns';

function monthCells(monthStart) {
  const first = toDate(monthStart);
  const year = first.getUTCFullYear();
  const month = first.getUTCMonth();
  const startIdx = Math.floor(Date.UTC(year, month, 1) / 86400000);
  const offset = new Date(Date.UTC(year, month, 1)).getUTCDay();
  const daysInMonth = new Date(Date.UTC(year, month + 1, 0)).getUTCDate();
  const cells = Array(offset).fill(null);
  for (let d = 1; d <= daysInMonth; d += 1) cells.push(new Date((startIdx + d - 1) * 86400000).toISOString().slice(0, 10));
  while (cells.length % 7 !== 0) cells.push(null);
  return cells;
}

export default function BookingDetail() {
  const { id } = useParams();
  const [params, setParams] = useSearchParams();
  const { currency, policy, capabilities, toast } = useApp();
  const navigate = useNavigate();

  const [booking, setBooking] = useState(null);
  const [loading, setLoading] = useState(true);
  const [rescheduling, setRescheduling] = useState(params.get('reschedule') === '1');
  const [reviewing, setReviewing] = useState(params.get('review') === '1');
  const [confirmCancel, setConfirmCancel] = useState(false);
  const [busy, setBusy] = useState(false);

  // reschedule state
  const [rDate, setRDate] = useState(null);
  const [rSlot, setRSlot] = useState(null);
  const [rMonth, setRMonth] = useState(() => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-01`;
  });
  const [rAvailability, setRAvailability] = useState(null);
  const [rLoading, setRLoading] = useState(false);

  // review state
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState('');

  const load = () => api(`/bookings/${id}`).then((d) => setBooking(d.booking));
  useEffect(() => {
    load().catch(() => setBooking(null)).finally(() => setLoading(false));
  }, [id]);

  useEffect(() => {
    if (!rescheduling || !booking || !rDate) return;
    setRLoading(true);
    api('/availability', {
      params: { serviceId: booking.service_id, date: rDate, staffId: booking.staff_id || '', ignoreAppointmentId: booking.id },
    })
      .then(setRAvailability)
      .finally(() => setRLoading(false));
  }, [rescheduling, booking, rDate]);

  const today = todayISO();
  const maxDate = addDaysISO(today, Number(policy?.max_advance_days || 60));
  const cells = useMemo(() => monthCells(rMonth), [rMonth]);

  const doReschedule = async () => {
    setBusy(true);
    try {
      await api(`/bookings/${id}/reschedule`, { method: 'POST', body: { date: rDate, startMin: rSlot, staffId: booking.staff_id } });
      toast('Booking moved', 'success');
      setRescheduling(false);
      setParams({});
      await load();
    } catch (err) {
      toast(err.message, 'error');
    } finally {
      setBusy(false);
    }
  };

  const doCancel = async () => {
    setBusy(true);
    try {
      await api(`/bookings/${id}/cancel`, { method: 'POST', body: { reason: 'Cancelled by customer' } });
      toast('Booking cancelled', 'success');
      setConfirmCancel(false);
      await load();
    } catch (err) {
      toast(err.message, 'error');
    } finally {
      setBusy(false);
    }
  };

  const doReview = async () => {
    setBusy(true);
    try {
      await api('/reviews', { method: 'POST', body: { appointmentId: booking.id, rating, comment } });
      toast('Thanks for the review!', 'success');
      setReviewing(false);
      setParams({});
      await load();
    } catch (err) {
      toast(err.message, 'error');
    } finally {
      setBusy(false);
    }
  };

  if (loading) return <div className="page"><Loading /></div>;
  if (!booking) return <div className="page"><Empty title="Booking not found" /></div>;

  const cancellable = ['pending', 'confirmed'].includes(booking.status);
  const canReview = ['completed'].includes(booking.status) && !booking.review_id;
  const owed = Math.max(0, booking.total_cents - booking.paid_cents);

  return (
    <div className="page page-narrow">
      <button className="link-btn row gap-4 mb-16" onClick={() => navigate('/bookings')} style={{ color: 'var(--muted)' }}>
        <ArrowLeft size={14} /> All bookings
      </button>

      <Card className="card-pad">
        <div className="row-between wrap gap-12">
          <div>
            <div className="row gap-8">
              <Badge tone={STATUS_TONE[booking.status]}>{STATUS_LABEL[booking.status]}</Badge>
              <Badge tone="blue">{booking.code}</Badge>
            </div>
            <h2 className="mt-8">{booking.service_name}</h2>
            <p className="text-sm text-muted mt-4">{longDate(booking.date)}</p>
          </div>
          <div className="center">
            <div className="price">{money(booking.total_cents, currency)}</div>
            <div className="text-xs text-muted">{duration(booking.duration_min)}</div>
          </div>
        </div>

        <div className="divider" />

        <div className="grid grid-2">
          <div className="row gap-8">
            <Clock size={16} color="var(--muted)" />
            <div>
              <div className="text-xs text-muted">Time</div>
              <div className="semibold">
                {minutesToTime(booking.start_min)} – {minutesToTime(booking.end_min)}
              </div>
            </div>
          </div>
          <div className="row gap-8">
            <User size={16} color="var(--muted)" />
            <div>
              <div className="text-xs text-muted">Specialist</div>
              <div className="semibold">{booking.staff_name || 'Assigned on arrival'}</div>
            </div>
          </div>
          <div className="row gap-8">
            <CreditCard size={16} color="var(--muted)" />
            <div>
              <div className="text-xs text-muted">Payment</div>
              <div className="semibold">
                {booking.payment_status === 'paid'
                  ? 'Paid by card'
                  : booking.payment_status === 'refunded'
                  ? 'Refunded'
                  : booking.payment_method === 'cash'
                  ? 'Pay on arrival'
                  : `${money(owed, currency)} outstanding`}
              </div>
            </div>
          </div>
          <div className="row gap-8">
            <Hash size={16} color="var(--muted)" />
            <div>
              <div className="text-xs text-muted">Booked</div>
              <div className="semibold">{new Date(booking.created_at).toLocaleString()}</div>
            </div>
          </div>
        </div>

        {booking.notes && (
          <div className="soft mt-16" style={{ padding: 12, borderRadius: 12 }}>
            <div className="text-xs text-muted">Your notes</div>
            <div className="text-sm">{booking.notes}</div>
          </div>
        )}

        <div className="row gap-8 wrap mt-24">
          {cancellable && (
            <Button variant="outline" onClick={() => setRescheduling(true)}>
              <CalendarClock size={15} /> Reschedule
            </Button>
          )}
          {cancellable && (
            <Button variant="danger" onClick={() => setConfirmCancel(true)}>
              <XCircle size={15} /> Cancel booking
            </Button>
          )}
          {canReview && (
            <Button variant="primary" onClick={() => setReviewing(true)}>
              <Star size={15} /> Leave a review
            </Button>
          )}
        </div>

        {booking.status === 'cancelled' && booking.cancel_reason && (
          <p className="text-sm mt-16" style={{ color: 'var(--red)' }}>
            {booking.cancel_reason}
          </p>
        )}
        {cancellable && (
          <p className="text-xs text-muted mt-16 row gap-6">
            <Info size={13} /> Free cancellation up to {policy?.cancellation_hours || 24}h before your appointment.
          </p>
        )}
      </Card>

      {/* ---------------------------------------------------------- reschedule */}
      {rescheduling && (
        <Modal
          title="Reschedule"
          subtitle={`${booking.service_name} · currently ${prettyDate(booking.date)} ${minutesToTime(booking.start_min)}`}
          onClose={() => setRescheduling(false)}
          wide
          footer={
            <>
              <Button variant="outline" onClick={() => setRescheduling(false)}>
                Cancel
              </Button>
              <Button variant="primary" disabled={!rDate || rSlot === null} loading={busy} onClick={doReschedule}>
                Move booking
              </Button>
            </>
          }
        >
          <div className="grid grid-2" style={{ alignItems: 'start' }}>
            <div>
              <div className="row-between mb-8">
                <span className="semibold">{format(toDate(rMonth), 'MMMM yyyy')}</span>
                <div className="row gap-4">
                  <button
                    className="icon-btn"
                    onClick={() => {
                      const d = toDate(rMonth);
                      d.setUTCMonth(d.getUTCMonth() - 1);
                      setRMonth(d.toISOString().slice(0, 10));
                    }}
                  >
                    ‹
                  </button>
                  <button
                    className="icon-btn"
                    onClick={() => {
                      const d = toDate(rMonth);
                      d.setUTCMonth(d.getUTCMonth() + 1);
                      setRMonth(d.toISOString().slice(0, 10));
                    }}
                  >
                    ›
                  </button>
                </div>
              </div>
              <div className="cal-grid">
                {['S', 'M', 'T', 'W', 'T', 'F', 'S'].map((w, i) => (
                  <div key={i} className="cal-head">
                    {w}
                  </div>
                ))}
                {cells.map((d, i) => {
                  if (!d) return <span key={`e${i}`} />;
                  return (
                    <button
                      key={d}
                      className={cx('cal-day', rDate === d && 'selected')}
                      disabled={d < today || d > maxDate}
                      onClick={() => {
                        setRDate(d);
                        setRSlot(null);
                      }}
                    >
                      {Number(d.slice(8))}
                    </button>
                  );
                })}
              </div>
            </div>
            <div>
              <div className="semibold mb-8">Available times</div>
              {!rDate ? (
                <p className="text-sm text-muted">Pick a date first.</p>
              ) : rLoading ? (
                <div className="center" style={{ padding: 24 }}>
                  <Spinner />
                </div>
              ) : rAvailability?.slots?.length ? (
                <div className="slots">
                  {rAvailability.slots.map((s) => (
                    <button
                      key={s.start}
                      className={cx('slot', rSlot === s.start && 'selected')}
                      disabled={!s.available}
                      onClick={() => setRSlot(s.start)}
                    >
                      {s.time}
                    </button>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted">Closed that day — try another date.</p>
              )}
            </div>
          </div>
        </Modal>
      )}

      {/* ---------------------------------------------------------- review */}
      {reviewing && (
        <Modal
          title="How was it?"
          subtitle={`${booking.service_name}${booking.staff_name ? ` with ${booking.staff_name}` : ''}`}
          onClose={() => setReviewing(false)}
          footer={
            <>
              <Button variant="outline" onClick={() => setReviewing(false)}>
                Not now
              </Button>
              <Button variant="primary" loading={busy} onClick={doReview}>
                Submit review
              </Button>
            </>
          }
        >
          <div className="center stack gap-12">
            <StarInput value={rating} onChange={setRating} />
            <div className="text-sm text-muted">{['Poor', 'Below average', 'Okay', 'Great', 'Excellent'][rating - 1]}</div>
          </div>
          <Field label="Tell us more (optional)" className="mt-16">
            <Textarea value={comment} onChange={(e) => setComment(e.target.value)} placeholder="What stood out?" />
          </Field>
        </Modal>
      )}

      <Confirm
        open={confirmCancel}
        title="Cancel this booking?"
        message={`${booking.service_name} on ${longDate(booking.date)} at ${minutesToTime(booking.start_min)} will be released for other customers.`}
        confirmLabel="Cancel booking"
        danger
        loading={busy}
        onConfirm={doCancel}
        onCancel={() => setConfirmCancel(false)}
      />
    </div>
  );
}
