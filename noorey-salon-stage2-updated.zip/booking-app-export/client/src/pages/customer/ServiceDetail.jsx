import { useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { Clock, Users, ArrowLeft, Star, Check } from 'lucide-react';
import { api } from '../../lib/api';
import { useApp } from '../../context/AppContext';
import { Button, Card, Avatar, Badge, Stars, Loading, Empty, Media } from '../../components/ui';
import { money, duration } from '../../lib/format';

export default function ServiceDetail() {
  const { id } = useParams();
  const { currency } = useApp();
  const navigate = useNavigate();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    api(`/services/${id}`)
      .then(setData)
      .finally(() => setLoading(false));
  }, [id]);

  if (loading) return <div className="page"><Loading /></div>;
  if (!data?.service) return <div className="page"><Empty title="Service not found" /></div>;

  const { service, reviews } = data;

  return (
    <div className="page">
      <button className="link-btn row gap-4 mb-16" onClick={() => navigate(-1)} style={{ color: 'var(--muted)' }}>
        <ArrowLeft size={14} /> Back
      </button>

      <div className="grid split-2-1">
        <div className="stack gap-16">
          <Card style={{ overflow: 'hidden' }}>
            <Media url={service.image_url} name={service.name} category={service.category} className="detail-media" />
            <div className="card-pad">
            <div className="row-between wrap gap-12">
              <div>
                <Badge tone="blue">{service.category}</Badge>
                <h2 className="mt-8">{service.name}</h2>
              </div>
              <div className="price">{money(service.price_cents, currency)}</div>
            </div>
            <p className="text-sm mt-12" style={{ color: 'var(--text-2)' }}>
              {service.description}
            </p>
            <div className="row gap-24 wrap mt-16">
              <span className="row gap-6 text-sm text-muted">
                <Clock size={16} /> {duration(service.duration_min)}
              </span>
              {service.buffer_min > 0 && (
                <span className="row gap-6 text-sm text-muted">
                  <Check size={16} /> {service.buffer_min} min reset time
                </span>
              )}
              {service.review_count > 0 && (
                <span className="row gap-6 text-sm text-muted">
                  <Star size={16} /> {service.rating} · {service.review_count} reviews
                </span>
              )}
            </div>
            </div>
          </Card>

          <Card className="card-pad">
            <h3>Who can do this</h3>
            <p className="text-sm text-muted mt-4 mb-12">Pick a specialist, or let us assign whoever is free.</p>
            {service.staff?.length ? (
              <div className="grid grid-auto-sm">
                {service.staff.map((s) => (
                  <div key={s.id} className="staff-card" style={{ cursor: 'default' }}>
                    <Avatar name={s.name} url={s.avatar_url} color={s.color} />
                    <div style={{ minWidth: 0 }}>
                      <div className="semibold truncate">{s.name}</div>
                      <div className="text-xs text-muted truncate">{s.title}</div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-muted">Any available specialist.</p>
            )}
          </Card>

          <Card className="card-pad">
            <div className="row-between mb-12">
              <h3>Reviews</h3>
              {reviews.length > 0 && <Stars value={service.rating} />}
            </div>
            {reviews.length ? (
              <div className="stack gap-16">
                {reviews.map((r) => (
                  <div key={r.id}>
                    <div className="row gap-8">
                      <Avatar name={r.customer_name} url={r.customer_avatar} size="sm" />
                      <div className="grow">
                        <div className="text-sm semibold">{r.customer_name}</div>
                        <div className="text-xs text-muted">{new Date(r.created_at).toLocaleDateString()}</div>
                      </div>
                      <Stars value={r.rating} size={12} />
                    </div>
                    <p className="text-sm mt-8" style={{ color: 'var(--text-2)' }}>
                      {r.comment}
                    </p>
                    {r.reply && (
                      <div className="soft mt-8" style={{ padding: '8px 12px', borderRadius: 10, fontSize: 13 }}>
                        <b>Team reply:</b> {r.reply}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <Empty icon={Star} title="No reviews yet" hint="Be the first to review this service." />
            )}
          </Card>
        </div>

        <div>
          <Card className="card-pad sticky-card">
            <h4>Book this service</h4>
            <p className="text-sm text-muted mt-4 mb-16">
              Pick a time that suits you and pay at the salon.
            </p>
            <div className="kv">
              <span>Price</span>
              <span className="semibold">{money(service.price_cents, currency)}</span>
            </div>
            <div className="kv">
              <span>Duration</span>
              <span className="semibold">{duration(service.duration_min)}</span>
            </div>
            <div className="kv">
              <span>Specialists</span>
              <span className="semibold">{service.staff?.length || 'Any'}</span>
            </div>
            <Button variant="primary" size="lg" className="btn-block mt-16" onClick={() => navigate(`/book/${service.id}`)}>
              Choose a time
            </Button>
            <Link to="/services" className="btn btn-ghost btn-block mt-8">
              Compare services
            </Link>
          </Card>
        </div>
      </div>
    </div>
  );
}
