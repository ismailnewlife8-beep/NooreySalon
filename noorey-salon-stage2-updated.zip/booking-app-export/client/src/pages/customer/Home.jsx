import { useEffect, useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ArrowRight, Sparkles, CalendarCheck, Wallet, Scissors, Palette, Hand, Flower2 } from 'lucide-react';
import { api } from '../../lib/api';
import { useApp } from '../../context/AppContext';
import { Button, Card, Stars, Loading, Empty, Media } from '../../components/ui';
import ServiceCard from '../../components/ServiceCard';
import HeroSlider from '../../components/HeroSlider';
import { money } from '../../lib/format';

const STEPS = [
  { icon: Sparkles, title: 'Choose your service', text: 'Browse hair, makeup, nails, skin and spa with clear prices and durations.' },
  { icon: CalendarCheck, title: 'Pick your time', text: 'See open slots from our specialists’ calendars and take the one that suits you.' },
  { icon: Wallet, title: 'Pay at the salon', text: 'Confirm online in under a minute and settle the bill when you visit.' },
];

const CATS = [
  { name: 'Hair', icon: Scissors },
  { name: 'Makeup', icon: Palette },
  { name: 'Nails', icon: Hand },
  { name: 'Skin', icon: Sparkles },
  { name: 'Spa', icon: Flower2 },
];

// Shown until the salon uploads its own photos (Admin > Settings > Branding).
const GALLERY_PLACEHOLDERS = ['Makeup', 'Hair', 'Nails', 'Skin', 'Spa', 'Hair'];

export default function Home() {
  const { business, policy, currency } = useApp();
  const navigate = useNavigate();
  const [services, setServices] = useState([]);
  const [staff, setStaff] = useState([]);
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const [s, st, r] = await Promise.all([api('/services'), api('/staff'), api('/reviews')]);
        setServices(s.services);
        setStaff(st.staff);
        setReviews(r.reviews);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const popular = useMemo(
    () => [...services].sort((a, b) => b.review_count - a.review_count || a.sort_order - b.sort_order).slice(0, 6),
    [services]
  );

  const gallery = business?.gallery || [];

  return (
    <div className="page">
      <HeroSlider business={business} />

      <section className="mt-32">
        <div className="center" style={{ marginBottom: 20 }}>
          <span className="eyebrow">Our services</span>
          <h2 style={{ marginTop: 6 }}>Crafted for you</h2>
        </div>
        <div className="cat-grid">
          {CATS.map((c) => (
            <Link key={c.name} to={`/services?q=${c.name}`} className="cat-tile">
              <c.icon size={26} color="var(--gold)" />
              <div className="serif" style={{ marginTop: 10 }}>{c.name}</div>
            </Link>
          ))}
        </div>
      </section>

      <section className="mt-32">
        <div className="section-head">
          <div>
            <h2>Signature treatments</h2>
            <p className="text-sm text-muted mt-4">Clear pricing and real durations.</p>
          </div>
          <Link to="/services" className="link-btn row gap-4">
            View all <ArrowRight size={14} />
          </Link>
        </div>
        {loading ? (
          <Loading />
        ) : popular.length ? (
          <div className="grid grid-auto">
            {popular.map((s) => (
              <ServiceCard key={s.id} service={s} currency={currency} />
            ))}
          </div>
        ) : (
          <Empty title="No services published yet" />
        )}
      </section>

      <section className="mt-32">
        <div className="center" style={{ marginBottom: 20 }}>
          <span className="eyebrow">The salon</span>
          <h2 style={{ marginTop: 6 }}>A look inside</h2>
        </div>
        <div className="gallery">
          {gallery.length
            ? gallery.map((url, i) => (
                <Media key={url} url={url} name={`${business?.business_name || 'Salon'} photo ${i + 1}`} className={i === 0 ? 'gallery-tile gallery-big' : 'gallery-tile'} />
              ))
            : GALLERY_PLACEHOLDERS.map((cat, i) => (
                <Media key={i} category={cat} className={i === 0 ? 'gallery-tile gallery-big' : 'gallery-tile'} />
              ))}
        </div>
      </section>

      {staff.length > 0 && (
        <section className="mt-32">
          <div className="center" style={{ marginBottom: 20 }}>
            <span className="eyebrow">Our team</span>
            <h2 style={{ marginTop: 6 }}>Meet the specialists</h2>
          </div>
          <div className="team-grid">
            {staff.slice(0, 5).map((s) => (
              <Card key={s.id} className="team-card card-hover">
                <Media url={s.avatar_url} name={s.name} className="team-photo" />
                <div className="team-body">
                  <div className="serif" style={{ fontSize: 21 }}>{s.name}</div>
                  <div className="text-xs text-muted">{s.title}</div>
                  {s.rating > 0 && (
                    <div className="mt-4">
                      <Stars value={s.rating} size={12} />
                    </div>
                  )}
                </div>
              </Card>
            ))}
          </div>
        </section>
      )}

      <section className="mt-32">
        <div className="center">
          <span className="eyebrow">Simple</span>
          <h2 style={{ marginTop: 6 }}>How booking works</h2>
        </div>
        <div className="grid grid-3 mt-16">
          {STEPS.map((s, i) => (
            <Card key={i} className="card-pad">
              <span className="brand-mark" style={{ background: 'var(--brand-50)', color: 'var(--gold)', boxShadow: 'none' }}>
                <s.icon size={18} />
              </span>
              <h4 className="mt-12">{s.title}</h4>
              <p className="text-sm text-muted mt-4">{s.text}</p>
            </Card>
          ))}
        </div>
      </section>

      {reviews.length > 0 && (
        <section className="mt-32">
          <div className="section-head">
            <div>
              <h2>Guest feedback</h2>
              <p className="text-sm text-muted mt-4">Recent reviews from our guests.</p>
            </div>
          </div>
          <div className="grid grid-auto">
            {reviews.slice(0, 6).map((r) => (
              <Card key={r.id} className="card-pad">
                <Stars value={r.rating} />
                <p className="text-sm mt-8" style={{ color: 'var(--text-2)' }}>
                  “{r.comment}”
                </p>
                <div className="text-xs mt-12">
                  <div className="semibold">{r.customer_name}</div>
                  <div className="text-muted">{r.service_name}</div>
                </div>
              </Card>
            ))}
          </div>
        </section>
      )}

      <section className="mt-32">
        <Card className="card-pad cta-card">
          <div className="row-between wrap gap-16">
            <div>
              <h3 style={{ color: '#fff7ea', fontFamily: 'var(--serif)', fontSize: 30 }}>Ready for your appointment?</h3>
              <p style={{ color: 'rgba(255,244,228,0.9)' }} className="text-sm mt-4">
                {services.length ? `Services from ${money(Math.min(...services.map((s) => s.price_cents)), currency)} · ` : ''}
                free cancellation up to {policy?.cancellation_hours || 12} hours before.
              </p>
            </div>
            <Button size="lg" className="btn-gold" onClick={() => navigate('/book')}>
              Book now <ArrowRight size={16} />
            </Button>
          </div>
        </Card>
      </section>
    </div>
  );
}
