import { useEffect, useState } from 'react';
import { Link, useSearchParams, useNavigate } from 'react-router-dom';
import { Mail, Lock, CheckCircle2, XCircle } from 'lucide-react';
import { api } from '../../lib/api';
import { useApp } from '../../context/AppContext';
import { Button, Card, Field, Input, Loading } from '../../components/ui';

export function ForgotPassword() {
  const [email, setEmail] = useState('');
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(null);
  const [error, setError] = useState('');

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      setDone(await api('/auth/forgot-password', { method: 'POST', body: { email } }));
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="page page-narrow">
      <Card className="card-pad" style={{ maxWidth: 460, margin: '0 auto', padding: 26 }}>
        <h2>Forgot your password?</h2>
        <p className="text-sm text-muted mt-4 mb-16">Enter your email and we will send you a link to choose a new one.</p>
        {done ? (
          <div className="stack gap-12">
            <div className="row gap-8"><CheckCircle2 color="var(--green)" size={18} /> <span className="text-sm">{done.message}</span></div>
            {done.devLink && (
              <div className="text-xs text-muted" style={{ wordBreak: 'break-all' }}>
                Demo mode (no email provider connected): <a className="link-btn" href={done.devLink}>open reset link</a>
              </div>
            )}
            <Link to="/login" className="link-btn">Back to sign in</Link>
          </div>
        ) : (
          <form className="stack gap-12" onSubmit={submit}>
            <Field label="Email">
              <div style={{ position: 'relative' }}>
                <Mail size={16} style={{ position: 'absolute', left: 12, top: 13, color: 'var(--muted)' }} />
                <Input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" style={{ paddingLeft: 34 }} />
              </div>
            </Field>
            {error && <div className="field-error">{error}</div>}
            <Button type="submit" variant="primary" size="lg" loading={busy} className="btn-block">Send reset link</Button>
            <Link to="/login" className="link-btn" style={{ textAlign: 'center' }}>Back to sign in</Link>
          </form>
        )}
      </Card>
    </div>
  );
}

export function ResetPassword() {
  const [params] = useSearchParams();
  const token = params.get('token') || '';
  const navigate = useNavigate();
  const { toast } = useApp();
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      await api('/auth/reset-password', { method: 'POST', body: { token, password } });
      toast('Password updated. Please sign in.', 'success');
      navigate('/login', { replace: true });
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="page page-narrow">
      <Card className="card-pad" style={{ maxWidth: 460, margin: '0 auto', padding: 26 }}>
        <h2>Choose a new password</h2>
        <form className="stack gap-12 mt-16" onSubmit={submit}>
          <Field label="New password" hint="At least 8 characters">
            <div style={{ position: 'relative' }}>
              <Lock size={16} style={{ position: 'absolute', left: 12, top: 13, color: 'var(--muted)' }} />
              <Input type="password" required minLength={8} value={password} onChange={(e) => setPassword(e.target.value)} style={{ paddingLeft: 34 }} />
            </div>
          </Field>
          {error && <div className="field-error">{error}</div>}
          <Button type="submit" variant="primary" size="lg" loading={busy} disabled={!token} className="btn-block">Update password</Button>
          {!token && <div className="field-error">This link is missing its token. Please request a new reset email.</div>}
        </form>
      </Card>
    </div>
  );
}

export function VerifyEmail() {
  const [params] = useSearchParams();
  const [state, setState] = useState('loading');
  const { user, setUser } = useApp();

  useEffect(() => {
    api('/auth/verify-email', { method: 'POST', body: { token: params.get('token') } })
      .then(() => {
        setState('ok');
        if (user) setUser({ ...user, email_verified: 1 });
      })
      .catch(() => setState('bad'));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="page page-narrow">
      <Card className="card-pad center" style={{ maxWidth: 460, margin: '0 auto', padding: 32 }}>
        {state === 'loading' && <Loading />}
        {state === 'ok' && (<><CheckCircle2 size={40} color="var(--green)" /><h2 className="mt-12">Email confirmed</h2><p className="text-sm text-muted mt-4">Thank you! Your email address is verified.</p></>)}
        {state === 'bad' && (<><XCircle size={40} color="var(--red)" /><h2 className="mt-12">Link expired</h2><p className="text-sm text-muted mt-4">Sign in and use “Resend link” on your profile page.</p></>)}
        <div className="mt-16"><Link to="/" className="link-btn">Go to home</Link></div>
      </Card>
    </div>
  );
}
