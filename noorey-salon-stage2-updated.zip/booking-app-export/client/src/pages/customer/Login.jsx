import { useEffect, useRef, useState } from 'react';
import { useNavigate, useLocation, Link } from 'react-router-dom';
import { Mail, Lock, Smartphone, ShieldCheck, ArrowRight } from 'lucide-react';
import { api } from '../../lib/api';
import { useApp } from '../../context/AppContext';
import { Button, Card, Field, Input, Tabs, Badge, cx } from '../../components/ui';

const TABS = [
  { value: 'password', label: 'Email' },
  { value: 'otp', label: 'Phone OTP' },
];

export default function Login() {
  const { signIn, capabilities, toast } = useApp();
  const navigate = useNavigate();
  const location = useLocation();
  const from = location.state?.from || '/';

  const [mode, setMode] = useState('password');
  const [isRegister, setIsRegister] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // password flow
  const [form, setForm] = useState({ name: '', email: '', phone: '', password: '' });

  // otp flow
  const [otpPhone, setOtpPhone] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [otpCode, setOtpCode] = useState('');
  const [devCode, setDevCode] = useState('');
  const [otpMsg, setOtpMsg] = useState('');

  const googleRef = useRef(null);
  const googleReady = capabilities?.google && capabilities?.googleClientId;

  useEffect(() => {
    if (!googleReady || !window.google?.accounts?.id) return;
    window.google.accounts.id.initialize({
      client_id: capabilities.googleClientId,
      callback: async (resp) => {
        try {
          setLoading(true);
          const { token, user } = await api('/auth/google', { method: 'POST', body: { credential: resp.credential } });
          await signIn(token, user);
          toast('Signed in with Google', 'success');
          navigate(from, { replace: true });
        } catch (err) {
          setError(err.message);
        } finally {
          setLoading(false);
        }
      },
    });
    if (googleRef.current) {
      window.google.accounts.id.renderButton(googleRef.current, {
        theme: document.documentElement.getAttribute('data-theme') === 'dark' ? 'filled_black' : 'outline',
        size: 'large',
        width: 320,
        text: 'continue_with',
        shape: 'pill',
      });
    }
  }, [googleReady, capabilities?.googleClientId, from, navigate, signIn, toast]);

  const submitPassword = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const path = isRegister ? '/auth/register' : '/auth/login';
      const body = isRegister
        ? { name: form.name, email: form.email, phone: form.phone, password: form.password }
        : { email: form.email, password: form.password };
      const { token, user } = await api(path, { method: 'POST', body });
      await signIn(token, user);
      toast(isRegister ? 'Account created — welcome!' : 'Welcome back', 'success');
      navigate(from, { replace: true });
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const requestOtp = async (e) => {
    e?.preventDefault();
    setError('');
    setLoading(true);
    try {
      const res = await api('/auth/otp/request', { method: 'POST', body: { phone: otpPhone } });
      setOtpSent(true);
      setDevCode(res.devCode || '');
      setOtpMsg(res.hint || `We sent a 6-digit code by ${res.channel}.`);
      toast('Verification code sent', 'success');
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const verifyOtp = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const { token, user } = await api('/auth/otp/verify', { method: 'POST', body: { phone: otpPhone, code: otpCode } });
      await signIn(token, user);
      toast('You are signed in', 'success');
      navigate(from, { replace: true });
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="page page-narrow">
      <div className="grid" style={{ gridTemplateColumns: 'minmax(0, 1fr)', maxWidth: 460, margin: '0 auto' }}>
        <Card className="card-pad" style={{ padding: 24 }}>
          <h2 style={{ marginBottom: 4 }}>{isRegister ? 'Create your account' : 'Welcome back'}</h2>
          <p className="text-sm text-muted mb-16">
            {isRegister ? 'One account for booking, rescheduling and reviews.' : 'Sign in to manage your appointments.'}
          </p>

          {capabilities?.google && (
            <>
              <div ref={googleRef} className="center" style={{ minHeight: 44 }} />
              {!googleReady && <p className="text-xs text-muted center mt-4">Google sign-in loading…</p>}
              <div className="row gap-12 mt-16 mb-16" style={{ color: 'var(--muted-2)' }}>
                <div className="divider grow" style={{ margin: 0 }} />
                <span className="text-xs">or</span>
                <div className="divider grow" style={{ margin: 0 }} />
              </div>
            </>
          )}

          <Tabs items={TABS} value={mode} onChange={setMode} />
          <div style={{ height: 16 }} />

          {mode === 'password' ? (
            <form className="stack gap-12" onSubmit={submitPassword}>
              {isRegister && (
                <Field label="Full name">
                  <Input
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    placeholder="Your full name"
                    required
                  />
                </Field>
              )}
              <Field label="Email">
                <div style={{ position: 'relative' }}>
                  <Mail size={16} style={{ position: 'absolute', left: 12, top: 13, color: 'var(--muted)' }} />
                  <Input
                    type="email"
                    value={form.email}
                    onChange={(e) => setForm({ ...form, email: e.target.value })}
                    placeholder="you@example.com"
                    style={{ paddingLeft: 34 }}
                    required
                  />
                </div>
              </Field>
              {isRegister && (
                <Field label="Phone (optional)" hint="Used for SMS reminders">
                  <div style={{ position: 'relative' }}>
                    <Smartphone size={16} style={{ position: 'absolute', left: 12, top: 13, color: 'var(--muted)' }} />
                    <Input
                      value={form.phone}
                      onChange={(e) => setForm({ ...form, phone: e.target.value })}
                      placeholder="0300 1234567"
                      style={{ paddingLeft: 34 }}
                    />
                  </div>
                </Field>
              )}
              <Field label="Password" hint={isRegister ? 'At least 8 characters' : undefined}>
                <div style={{ position: 'relative' }}>
                  <Lock size={16} style={{ position: 'absolute', left: 12, top: 13, color: 'var(--muted)' }} />
                  <Input
                    type="password"
                    value={form.password}
                    onChange={(e) => setForm({ ...form, password: e.target.value })}
                    placeholder="••••••••"
                    style={{ paddingLeft: 34 }}
                    minLength={isRegister ? 8 : undefined}
                    required
                  />
                </div>
              </Field>
              {!isRegister && (
                <div style={{ textAlign: 'right', marginTop: -4 }}>
                  <Link to="/forgot-password" className="link-btn">Forgot password?</Link>
                </div>
              )}

              {error && <div className="field-error">{error}</div>}

              <Button type="submit" variant="primary" size="lg" loading={loading} className="btn-block">
                {isRegister ? 'Create account' : 'Sign in'} <ArrowRight size={16} />
              </Button>
            </form>
          ) : (
            <form className="stack gap-12" onSubmit={otpSent ? verifyOtp : requestOtp}>
              <Field label="Phone number">
                <div style={{ position: 'relative' }}>
                  <Smartphone size={16} style={{ position: 'absolute', left: 12, top: 13, color: 'var(--muted)' }} />
                  <Input
                    value={otpPhone}
                    onChange={(e) => setOtpPhone(e.target.value)}
                    placeholder="0300 1234567"
                    style={{ paddingLeft: 34 }}
                    required
                  />
                </div>
              </Field>

              {otpSent && (
                <Field label="6-digit code" hint={otpMsg}>
                  <div style={{ position: 'relative' }}>
                    <ShieldCheck size={16} style={{ position: 'absolute', left: 12, top: 13, color: 'var(--muted)' }} />
                    <Input
                      value={otpCode}
                      onChange={(e) => setOtpCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                      placeholder="123456"
                      inputMode="numeric"
                      autoFocus
                      style={{ paddingLeft: 34, letterSpacing: 4, fontWeight: 700 }}
                      required
                    />
                  </div>
                </Field>
              )}

              {devCode && (
                <div className={cx('badge', 'badge-amber')} style={{ alignSelf: 'flex-start' }}>
                  Dev mode code: <b>{devCode}</b>
                </div>
              )}
              {error && <div className="field-error">{error}</div>}

              <Button type="submit" variant="primary" size="lg" loading={loading} className="btn-block">
                {otpSent ? 'Verify & continue' : 'Send code'}
              </Button>
              {otpSent && (
                <Button type="button" variant="ghost" size="sm" onClick={() => { setOtpSent(false); setDevCode(''); }}>
                  Use a different number
                </Button>
              )}
            </form>
          )}

          <div className="divider" />
          <div className="row-between">
            <span className="text-sm text-muted">{isRegister ? 'Already have an account?' : 'New here?'}</span>
            <Button variant="ghost" size="sm" onClick={() => { setIsRegister((v) => !v); setError(''); }}>
              {isRegister ? 'Sign in instead' : 'Create an account'}
            </Button>
          </div>
        </Card>

      </div>
    </div>
  );
}
