import { Link } from 'react-router-dom';
import { Compass } from 'lucide-react';

export default function NotFound() {
  return (
    <div className="page page-narrow" style={{ paddingTop: 64 }}>
      <div className="card card-pad center" style={{ padding: 48 }}>
        <span className="brand-mark" style={{ width: 52, height: 52, borderRadius: 16, margin: '0 auto' }}>
          <Compass size={24} />
        </span>
        <h2 className="mt-16">Page not found</h2>
        <p className="text-muted mt-8">The link may be outdated, or the page moved.</p>
        <div className="row gap-8 mt-24" style={{ justifyContent: 'center' }}>
          <Link to="/" className="btn btn-primary">
            Back home
          </Link>
          <Link to="/services" className="btn btn-outline">
            Browse services
          </Link>
        </div>
      </div>
    </div>
  );
}
