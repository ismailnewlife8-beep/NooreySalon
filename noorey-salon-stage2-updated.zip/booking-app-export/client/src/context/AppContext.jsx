import { createContext, useContext, useEffect, useMemo, useState, useCallback } from 'react';
import { api, getToken, setToken } from '../lib/api';

const AppContext = createContext(null);
export const useApp = () => useContext(AppContext);

const THEME_KEY = 'booking_theme';

export function AppProvider({ children }) {
  const [user, setUser] = useState(null);
  const [meta, setMeta] = useState(null);
  const [booting, setBooting] = useState(true);
  const [theme, setTheme] = useState(() => localStorage.getItem(THEME_KEY) || 'light');
  const [toasts, setToasts] = useState([]);

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem(THEME_KEY, theme);
  }, [theme]);

  const toast = useCallback((message, type = 'info') => {
    const id = Math.random().toString(36).slice(2);
    setToasts((t) => [...t, { id, message, type }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 4200);
  }, []);

  const dismissToast = (id) => setToasts((t) => t.filter((x) => x.id !== id));

  useEffect(() => {
    (async () => {
      try {
        const m = await api('/meta');
        setMeta(m);
      } catch {
        /* offline */
      }
      if (getToken()) {
        try {
          const { user: u } = await api('/auth/me');
          setUser(u);
        } catch {
          setToken(null);
        }
      }
      setBooting(false);
    })();
  }, []);

  const signIn = useCallback(async (token, nextUser) => {
    setToken(token);
    const { user: u } = await api('/auth/me').catch(() => ({ user: nextUser }));
    setUser(u || nextUser);
    return u || nextUser;
  }, []);

  const signOut = useCallback(() => {
    setToken(null);
    setUser(null);
  }, []);

  const refreshMeta = useCallback(async () => {
    try {
      setMeta(await api('/meta'));
    } catch {
      /* ignore */
    }
  }, []);

  const currency = meta?.business?.currency_symbol || '$';
  const value = useMemo(
    () => ({
      user,
      setUser,
      meta,
      business: meta?.business,
      policy: meta?.policy,
      capabilities: meta?.capabilities,
      currency,
      theme,
      toggleTheme: () => setTheme((t) => (t === 'dark' ? 'light' : 'dark')),
      booting,
      signIn,
      signOut,
      toast,
      toasts,
      dismissToast,
      refreshMeta,
    }),
    [user, meta, theme, booting, signIn, signOut, toast, toasts, refreshMeta, currency]
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}
